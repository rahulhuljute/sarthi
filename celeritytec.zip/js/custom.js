
var $j = jQuery.noConflict();

$j(document).ready(function() {
	"use strict";

	});
