import React, { PureComponent } from 'react';
import {
  SelectField,
  Grid, Cell, TextField, Checkbox, Button
} from 'react-md';
import './protocolFilter.css';
import filterInputFileds from '../../sampleData/protocolFilterInputs';

export default class ProtocolFilter extends PureComponent {
	//state = { };
	renderFilterFiled = (item) =>{
		let filterInput = '';
		if(item.inputType == 'textfield'){
			return <TextField id={item.key} key={item.key} placeholder={item.placeholder} className="md-cell md-cell--bottom" />;
		}else if(item.inputType == 'selectField'){
			return 	<SelectField
				label={item.displayName}
				id={item.key} 
				key={item.key}
				className="md-cell md-cell-12 md-cell--stretch"
				menuItems={item.options}
				position={SelectField.Positions.TOP}
				simplifiedMenu={true}
				helpOnFocus={false}/>
		}else if(item.inputType == 'checkboxGroup'){
			let checkBoxes = [];
			item.options.map((ele) => (
				checkBoxes.push(<Checkbox
				  id={ele.key}
				  name='checkbox{ele.key}[]'
				  label={ele.displayName}
				  value={ele.key}
				/>)
			));
			return (
				<div className="md-cell">
					<div>{item.displayName}</div>
					<div>{checkBoxes}</div>	
				</div>	
			)
		}
	}
	render() {
		return (
		<div className="protocol-filter-container">
			<h4>Filter</h4>
			<div className="md-grid">
				<div className="md-cell md-cell--12">
					{filterInputFileds.map((item)=>(
						<div className="md-cell md-cell--12 field-container">
							{this.renderFilterFiled(item)}					
						</div>
					))}
					<div className="buttons__group">
					    <Button flat primary swapTheming className="reset-btn">Reset</Button>
						<Button flat secondary swapTheming className="save-btn">Save</Button>
					</div>
				</div>
			</div>
		</div>)
	}
}