export default [
			{'key':'protocol', 'displayName':'Protocol', 'inputType':'textfield', 'placeholder':'Protocol#'},
			{'key':'lop', 'displayName':'LOP', 'inputType':'selectField', 'options':['LOP 1', 'LOP 2', 'LOP 3']},
			{'key':'pioStatus', 'displayName':'PIO Status', 'inputType':'selectField', 'options':['PIO Status 1', 'PIO Status 2', 'PIO Status 3']},			
			{'key':'indStatus', 'displayName':'IND Status', 'inputType':'selectField', 'options':['IND Status 1', 'IND Status 2', 'IND Status 3']},		
			{'key':'phase', 'displayName':'Phase', 'inputType':'textfield', 'placeholder':'Phase'},			
			{'key':'disease', 'displayName':'Disease', 'inputType':'textfield', 'placeholder':'Disease'},			
			{'key':'nct', 'displayName':'NCT', 'inputType':'textfield', 'placeholder':'NCT'},		
			{'key':'reviewInfo', 'displayName':'Review Info:', 'inputType':'checkboxGroup', 'options':[
				{'key':'cirbReviewed', 'displayName':'CIRB Reviewed', 'inputType':'checkbox'},
				{'key':'cirbOnly', 'displayName':'CIRB Only', 'inputType':'checkbox'},
				{'key':'crPostAccrual', 'displayName':'CR PostAccrual', 'inputType':'checkbox'},
			]},
			{'key':'integrations', 'displayName':'Integrations:', 'inputType':'checkboxGroup', 'options':[
				{'key':'open', 'displayName':'Open', 'inputType':'checkbox'},
				{'key':'rave', 'displayName':'Rave', 'inputType':'checkbox'},
				{'key':'triad', 'displayName':'Triad', 'inputType':'checkbox'},
			]}
];