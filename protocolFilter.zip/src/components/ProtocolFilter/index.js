import React, { PureComponent } from 'react';
import {
  SelectField,
  Grid, Cell, TextField
} from 'react-md';
import './protocolFilter.css';
import filterInputFileds from '../../sampleData/protocolFilterInputs';

export default class ProtocolFilter extends PureComponent {
	//state = { };
	renderFilterFiled = (item) =>{
		let filterInput = '';
		if(item.inputType == 'textfield'){
			return <TextField id={item.key} key={item.key} placeholder={item.placeholder} className="md-cell md-cell--bottom" />;
		}else if(item.inputType == 'selectField'){
			return 	<SelectField
				label={item.displayName}
				id={item.key} 
				key={item.key}
				className="md-cell md-cell--bottom"
				menuItems={item.options}
				position={SelectField.Positions.TOP}
				simplifiedMenu={false}
				helpOnFocus={false}/>
		}else if(item.inputType == 'selectField'){
			
		}
	}
	render() {
		return (
		<div className="protocol-filter-container">
			<h4>Filter Protocol</h4>
			<div className="protocol-filter">
			{filterInputFileds.map((item)=>(
				<div className="row">
					{this.renderFilterFiled(item)}					
				</div>
			))}
			</div>		
		</div>)
	}
}