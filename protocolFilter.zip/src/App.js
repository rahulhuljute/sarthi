import React, { Component } from 'react';
import { NavigationDrawer, Button, FontIcon, Cell } from 'react-md';
import logo from './logo.svg';
import './App.css';
import ProtocolFilter from './components/ProtocolFilter/index.js';

class App extends Component {
  render() {
    return (
        <div className="App">
			<ProtocolFilter/>
        </div>
    );
  }
}

export default App;
