import React, { Component } from 'react';
import ProtocolFilter from './components/DynamicForm';
import './App.css';

class App extends Component {
  state = {
    data: [
      {id: 1, name:"a", age:29, qualification:"B.Com",rating:3,gender:"male",
          city:"Kerala",skills:["reactjs","angular","vuejs"]},
      {id: 2, name:"b", age:35, qualification:"B.Sc",rating:5,gender:"female",
          city:"Mumbai",skills:["reactjs","angular"]},
      {id: 3, name:"c", age:42, qualification:"B.E",rating:3,gender:"female",
        city:"Bangalore",skills:["reactjs"]},
    ],
    current: {}
  }

  onSubmit = (model) => {
    let data = [];
    if (model.id) {
      data = this.state.data.filter((d) => {
        return d.id != model.id
      });
    } else {
      model.id = +new Date();
      data = this.state.data.slice();
    }
    
    this.setState({
      data: [model, ...data]
    });
  }

  onEdit = (id) => {
    let record = this.state.data.find((d) => {
      return d.id == id;
    });
    alert(JSON.stringify(record));
    this.setState({
      current: record
    })
  }

  render() {
    
    return (
      <div className="App">
        <ProtocolFilter className="form"
          title = "Protocol Filter"
          defaultValues = {this.state.current}
          model={[
			{key: "search", label: "Search Keyword", props: {required: true}},
            {key: "name", label: "Protocol Number", props: {required: true}},
            {key: "age",label: "Age", type: "number"},
            {key: "rating",label: "Rating", type: "number", props:{min:0,max:5}},
            {key: "gender",label: "Gender", type:"radio",options:[
              {key:"male",label:"Male",name:"gender",value:"male"},
              {key:"female",label:"Female",name: "gender",value:"female"}
            ]},
            {key: "qualification",label: "Qualification"},
            {key: "city",label:"City", type:"select", value: "Kerala", options: [
                {key:"mumbai",label:"Mumbai",value:"Mumbai"},
                {key:"bangalore",label:"Bangalore",value:"Bangalore"},
                {key:"kerala",label:"Kerala",value:"Kerala"},
            ]},
            {key: "skills",label:"Skills", type:"checkbox", options: [
                {key:"reactjs",label:"ReactJS",value:"reactjs"},
                {key:"angular",label:"Angular",value:"angular"},
                {key:"vuejs",label:"VueJS",value:"vuejs"},
            ]},
            {key: "state",label:"State", type:"select", value: "Maharashtra", options: [
                {key:"mumbai",label:"Mumbai",value:"Mumbai"},
                {key:"bangalore",label:"Bangalore",value:"Bangalore"},
                {key:"kerala",label:"Kerala",value:"Kerala"},
            ]},			

          ]}
          onSubmit = {(model) => {this.onSubmit(model)}} 
        />

      </div>
    );
  }
}

export default App;
