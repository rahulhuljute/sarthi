export default [
			{'key':'protocol', 'displayName':'Protocol', 'inputType':'textfield', 'placeholder':'#Protocol'},
			{'key':'lop', 'displayName':'LOP', 'inputType':'selectField', 'options':['test']},
			{'key':'pioStatus', 'displayName':'PIO Status', 'inputType':'selectField', 'options':['test']},			
			{'key':'indStatus', 'displayName':'IND Status', 'inputType':'selectField', 'options':['test']},		
			{'key':'phase', 'displayName':'Phase', 'inputType':'textfield', 'placeholder':'Phase'},			
			{'key':'disease', 'displayName':'Disease', 'inputType':'textfield', 'placeholder':'Disease'},			
			{'key':'nct', 'displayName':'NCT', 'inputType':'textfield', 'placeholder':'NCT'},		
			{'key':'reviewInfo', 'displayName':'Review Info:', 'inputType':'checkboxGroup', 'options':[
				{'key':'cirbReviewed', 'displayName':'CIRB Reviewed', 'inputType':'checkbox'},
				{'key':'cirbOnly', 'displayName':'CIRB Only', 'inputType':'checkbox'},
				{'key':'crPostAccrual', 'displayName':'CR PostAccrual', 'inputType':'checkbox'},
			]},
			{'key':'integrations', 'displayName':'Integrations:', 'inputType':'checkboxGroup', 'options':[
				{'key':'open', 'displayName':'Open', 'inputType':'checkbox'},
				{'key':'rave', 'displayName':'Rave', 'inputType':'checkbox'},
				{'key':'triad', 'displayName':'Triad', 'inputType':'checkbox'},
			]}
];