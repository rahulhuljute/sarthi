import React from 'react';
import { upperFirst } from 'lodash/string';
import {
  DataTable,
  TableHeader,
  TableBody,
  TableRow,
  TableColumn,
  EditDialogColumn,
  SelectFieldColumn,
  Grid, Cell
} from 'react-md';

import desserts from '../../sampleData/desserts';
import protocols from '../../sampleData/protocols';

const headers = Object.keys(desserts[0]).map((name, i) => ({
  key: name,
  name: upperFirst(name),
  numeric: i > 1,
  selectColumnHeader: i === 1,
}));

const types = desserts.reduce((list, dessert) => {
  if (list.indexOf(dessert.type) === -1) {
    list.unshift(dessert.type);
  }

  return list;
}, ['Other']);
let list = [];
const ProtocolColumn = protocols.map((item) => {
	if(Object.keys(item)[0] === 'selectedProtocol'){
		item.selectedProtocol.map((data)=>{
			list.push(<div className="md-cell md-cell-4">	
				<Cell size={12}>{data.protocol}</Cell>
				<Cell size={12}>{data.siteRegistrations}</Cell>
				<Cell size={12}>{data.patientEnrollments}</Cell>
			</div>);				  
		})
	}else if(Object.keys(item)[0] === 'protocolToCompare'){
		item.protocolToCompare.map((data)=>{
			list.push(<div className="md-cell md-cell-4">	
				<Cell size={12}>{data.protocol}</Cell>
				<Cell size={12}>{data.siteRegistrations}</Cell>
				<Cell size={12}>{data.patientEnrollments}</Cell>
			</div>)				  
		})
	}
});
const ProtocolComparisonTable = () => (
<div>
  <DataTable baseId="plain">
    <TableHeader>
      <TableRow>
        {headers.map(({ name, ...props }, i) => <TableColumn {...props} grow={i === 0}>{name}</TableColumn>)}
      </TableRow>
    </TableHeader>
    <TableBody>
      {desserts.map(({ name, type, calories, fat, carbs, protein, sodium, calcium, iron }) => (
        <TableRow key={name}>
          <EditDialogColumn defaultValue={name} label="Name" placeholder="Yummy food" />
          <SelectFieldColumn menuItems={types} defaultValue={type} />
          <TableColumn numeric>{calories}</TableColumn>
          <TableColumn numeric>{fat}</TableColumn>
          <TableColumn numeric>{carbs}</TableColumn>
          <TableColumn numeric>{protein}</TableColumn>
          <TableColumn numeric>{sodium}</TableColumn>
          <TableColumn numeric>{calcium}</TableColumn>
          <TableColumn numeric>{iron}</TableColumn>
        </TableRow>
      ))}
    </TableBody>
  </DataTable>  
<h1>Grid Example</h1>

<Grid className="grid-example">
  {list}
</Grid>
 </div>
);
export default ProtocolComparisonTable;