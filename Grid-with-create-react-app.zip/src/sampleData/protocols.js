export default [{
		'selectedProtocol':[{
			'protocol':'A041202',
			'siteRegistrations':825,
			'patientEnrollments':547,
		}]
	},{
		'protocolToCompare':[{
		'protocol':'A041202',
		'siteRegistrations':825,
		'patientEnrollments':547,
	}]
}];