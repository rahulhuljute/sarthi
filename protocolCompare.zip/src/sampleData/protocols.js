export default [{
		'comparingCriteria':[
			{'key':'protocol', 'displayName':'Criteria'},
			{'key':'siteRegistrations', 'displayName':'Number Of CTPE Sites Registered'},
			{'key':'patientEnrollments', 'displayName':'Paitent Enrollment'},
			{'key':'status', 'displayName':'Status'},
			{'key':'fundingSources', 'displayName':'Funding Sources'},
			{'key':'currentPass', 'displayName':'Current PASS'},
			{'key':'passChange1', 'displayName':'Funding Sources'},
			{'key':'passChange2', 'displayName':'Funding Sources'},
			{'key':'passChange3', 'displayName':'Funding Sources'}
		]},
		{'selectedProtocol':{
			'protocol':'A041202',
			'siteRegistrations':825,
			'patientEnrollments':547,
			'status':'Closed to Accrual',
			'fundingSources':'DCTD-DCP, DCP',
			'currentPass':'61',
			'passChange1':'-12',
			'passChange2':'-8',
			'passChange3':'-6'			
		}},{
		'protocolToCompare':{'E1912':{
			'protocol':'E1912',
			'siteRegistrations':817,
			'patientEnrollments':529,
			'status':'Closed to Accrual',
			'fundingSources':'DCTD-DCP, DCP, Industry',
			'currentPass':'82',
			'passChange1':'+3',
			'passChange2':'+4',
			'passChange3':'+4'		
		},'A041203':{
			'protocol':'A041202',
			'siteRegistrations':825,
			'patientEnrollments':547,
			'status':'Status',
			'fundingSources':'Funding Sources',
			'currentPass':'Current PASS',
			'passChange1':'',
			'passChange2':'',
			'passChange3':''		
		}}
		
}];