import React from 'react';
import './protocolComparision.css';
import {
  SelectField,
  Grid, Cell
} from 'react-md';
import protocols from '../../sampleData/protocols';

let criteria = protocols[0].comparingCriteria;
let selectedProtocol = protocols[1].selectedProtocol;
let protocolToCompare = protocols[2].protocolToCompare['E1912'];
let getSelectFiled = () => {
	return "E1912 "
}
const ProtocolComparisonTable = () => (
	<div>  
		<h1>Protocol Comparison</h1>
		<div className="protocol-comparison-grid">	
			{criteria.map((item)=>(
				<Grid className="protocol-comparison-row">		
					<Cell key={"selected_" + item.key} size={4}>{selectedProtocol[item.key]}</Cell>
					<Cell key={"compareCriteria_" + item.key} size={4}>{item.displayName}</Cell>
					<Cell key={"protocoltocompare_" + item.key} size={4}>{(item.key==="protocol")?getSelectFiled():protocolToCompare[item.key]}</Cell>				
				</Grid>			
			))}
		</div>		
	 </div>
);
export default ProtocolComparisonTable;