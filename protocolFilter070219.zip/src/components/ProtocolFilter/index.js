import React, { PureComponent } from 'react';
import {
  SelectField,
  Grid, Cell, TextField, Checkbox, Button
} from 'react-md';
import './protocolFilter.css';
import filterInputFileds from '../../sampleData/protocolFilterInputs';

export default class ProtocolFilter extends PureComponent {
	state = {'filterValues':{}};
	handleChange = (value, index, event, details) => {
		this.setFilterStateValue(details.id, value);
	};	
	handleInputChange = (value, e) => {
		this.setFilterStateValue(e.target.id, value);
	};
	setFilterStateValue = (key, value) =>{ 
		let fieldsData = {};
			fieldsData[key] = value;
		this.setState((state, props) => ({
			filterValues:{
		  	...state.filterValues,	
          	...fieldsData}
		  }));
	};
	resetFilter = () =>{
		console.log('---------Value reset -----------');		
		this.setState({filterValues:{}});
	}
	saveFilter = () =>{
		console.log('---------Value Saved -----------');
		console.log(this.state.filterValues);
	}
	renderFilterFiled = (item) =>{
		let filterInput = '';
		if(item.inputType == 'textfield'){
			return <TextField id={item.key} key={item.key} value={(this.state.filterValues[item.key]!==undefined?this.state.filterValues[item.key]:'')} placeholder={item.placeholder} onChange = {this.handleInputChange} className="md-cell md-cell--bottom"/>;
		}else if(item.inputType == 'selectField'){
			return 	<SelectField
				label={item.displayName}
				id={item.key} 
				key={item.key}
				onChange = {this.handleChange}
				value={(this.state.filterValues[item.key]!==undefined?this.state.filterValues[item.key]:'')}
				className="md-cell md-cell-12 md-cell--stretch"
				menuItems={item.options}
				position={SelectField.Positions.TOP}
				simplifiedMenu={true}
				helpOnFocus={false}/>
		}else if(item.inputType == 'checkboxGroup'){
			let checkBoxes = [];
			item.options.map((ele) => (
				checkBoxes.push(<Checkbox
				  id={ele.key}
				  label={ele.displayName}
				  checked={(this.state.filterValues[ele.key]!==undefined?this.state.filterValues[ele.key]:false)}
				  value={ele.key}
				  onChange = {this.handleInputChange}
				/>)
			));
			return (
				<div className="md-cell">
					<div>{item.displayName}</div>
					<div>{checkBoxes}</div>	
				</div>	
			)
		}
	}
	render() {
		return (
		<div className="protocol-filter-container">
			<h4>Filter</h4>
			<div className="md-grid">
				<div className="md-cell md-cell--12">
					{filterInputFileds.map((item)=>(
						<div className="md-cell md-cell--12 field-container">
							{this.renderFilterFiled(item)}					
						</div>
					))}
					<div className="buttons__group">
					    <Button flat primary swapTheming className="reset-btn" onClick={this.resetFilter}>Reset</Button>
						<Button flat secondary swapTheming className="save-btn" onClick={this.saveFilter}>Save</Button>
					</div>
				</div>
			</div>
		</div>)
	}
}