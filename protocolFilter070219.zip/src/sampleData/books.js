export default [{
  title: 'The Flight',
  author: 'Scott Masterson',
}, {
  title: 'Room of Plates',
  author: 'Ali Conners',
}, {
  title: 'The Sleek Boot',
  author: 'Sandra Adams',
}, {
  title: 'Night Hunting',
  author: 'Janet Perkins',
}, {
  title: 'Rain and Coffee',
  author: 'Peter Calsson',
}, {
  title: 'Ocean View',
  author: 'Trevor Hansen',
}, {
  title: 'Lovers on the Roof',
  author: 'Britta Holt',
}, {
  title: 'Lessons from Delhi',
  author: 'Mary Johnson',
}, {
  title: 'Mountaineers',
  author: 'Abbey Christensen',
}, {
  title: 'Plains in the Night',
  author: 'David Park',
}, {
  title: 'Dear Olivia',
  author: 'Slyvia S\u00f8rensen',
}, {
  title: 'Driving Lessons',
  author: 'Halimer Carver',
}];
