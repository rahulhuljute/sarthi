import React, { Component }  from 'react';
import PropTypes from 'prop-types';
import { SVGIcon, Paper, TextField, SelectField } from 'react-md';
import arrowDropDown from './icons/arrow_drop_down.svg';

class ProtocolFilter extends Component{
  constructor(props){
    super(props);
    this.state = {
      'input_1':""
    }
  }
  handleChange = (event) => {
      console.log(event);
  };  
  render(){   
    const icon = <SVGIcon use={arrowDropDown.url} />;
    return (
      <Paper
        key="protocolFilter"
        zDepth={2}
        className="papers md-grid"
      >
        <h3 className="md-cell md-cell--12 md-mt-20">Protocol Filter</h3>
            <TextField
              id="input_1"
              label="Multiline text field"
              placeholder="Some placeholder"
              className="md-cell md-cell--10"
            />
            <TextField
              id="input_2"
              label="Multiline text field"
              placeholder="Some placeholder"
              className="md-cell md-cell--10"
            />
            <SelectField
            id="select-field-1"
            label="Numbers"
            placeholder="Placeholder"
            className="md-cell md-cell--10"
            menuItems={[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]}
            simplifiedMenu={false}
            />
            <SelectField
              id="select-field-2"
              label="Numbers 2"
              placeholder="Placeholder"
              className="md-cell md-cell--10"
              menuItems={[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]}
              simplifiedMenu={false}
            />               
      </Paper>
    );
  }
}

export default ProtocolFilter;