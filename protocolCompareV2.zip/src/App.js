import React, { Component } from 'react';
import { NavigationDrawer, Button, FontIcon, Cell } from 'react-md';
import logo from './logo.svg';
import './App.css';
import ProtocolComparisonTable from './components/ProtocolComparison/index.js';

class App extends Component {
  render() {
    return (
        <div className="App">
			<ProtocolComparisonTable/>
        </div>
    );
  }
}

export default App;
