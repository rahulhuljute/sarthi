import React, { PureComponent } from 'react';
import './protocolComparision.css';
import {
  SelectField,
  Grid, Cell
} from 'react-md';
import protocols from '../../sampleData/protocols';

export default class ProtocolComparisonTable extends PureComponent {
	state = { value:'E1912', 
		criteria: protocols[0]['comparingCriteria'], 
		selectedProtocol:protocols[1]['selectedProtocol'], 
		protocolToCompare:protocols[2]['protocolToCompare']
	};

	handleChange = (value, index, event, details) => {
		if(this.state.value !== value){
			this.setState({ value });	
		}
	};
	getSelectFiled = () => {
		return 	<SelectField
				id="select-protocol"
                defaultValue={'E1912'}
				className="md-cell md-cell-12"
				onChange={this.handleChange}
				menuItems={Object.keys(this.state.protocolToCompare)}
				position={SelectField.Positions.TOP}
				simplifiedMenu={false}
				helpOnFocus={false}/>
	}
	render() {
		const { value, criteria,selectedProtocol, protocolToCompare  } = this.state;
		return (
		<div>  
			<h1>Protocol Comparison</h1>
			<div className="protocol-comparison-grid">	
				{criteria.map((item)=>(
					<Grid className="protocol-comparison-row">		
						<Cell key={"selected_" + item.key} size={4}>{selectedProtocol[item.key]}</Cell>
						<Cell key={"compareCriteria_" + item.key} size={4}>{item.displayName}</Cell>
						<Cell key={"protocoltocompare_" + item.key} size={4}>{(item.key==="protocol")?this.getSelectFiled():protocolToCompare[this.state.value][item.key]}</Cell>				
					</Grid>			
				))}
			</div>		
		</div>)
	}
}