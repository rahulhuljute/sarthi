export default [{
		'comparingCriteria':[
			{'key':'protocol', 'displayName':'Criteria'},
			{'key':'siteRegistrations', 'displayName':'Number Of CTPE Sites Registered'},
			{'key':'patientEnrollments', 'displayName':'Paitent Enrollment'},
			{'key':'status', 'displayName':'Status'},
			{'key':'fundingSources', 'displayName':'Funding Sources'},
			{'key':'currentPass', 'displayName':'Current PASS'},
			{'key':'passChange1', 'displayName':'Pass Change 1'},
			{'key':'passChange2', 'displayName':'Pass Change 2'},
			{'key':'passChange3', 'displayName':'Pass Change 3'}
		]},
		{'selectedProtocol':{
			'protocol':'A041202',
			'siteRegistrations':825,
			'patientEnrollments':547,
			'status':'Closed to Accrual',
			'fundingSources':'DCTD-DCP, DCP',
			'currentPass':'61',
			'passChange1':'-12',
			'passChange2':'-8',
			'passChange3':'-6'			
		}},{
		'protocolToCompare':{'E1912':{
			'protocol':'E1912',
			'siteRegistrations':817,
			'patientEnrollments':529,
			'status':'Closed to Accrual',
			'fundingSources':'DCTD-DCP, DCP, Industry',
			'currentPass':'82',
			'passChange1':'+3',
			'passChange2':'+4',
			'passChange3':'+4'		
		},'S1505':{
			'protocol':'S1505',
			'siteRegistrations':825,
			'patientEnrollments':557,
			'status':'Closed to Accrual',
			'fundingSources':'DCTD-DCP, DCP',
			'currentPass':'83',
			'passChange1':'+2',
			'passChange2':'+5',
			'passChange3':'+1'		
		}}
		
}];