import React from 'react';
import PropTypes from 'prop-types';
import { SVGIcon, SelectField, SelectionControl, Checkbox, Switch } from 'react-md';

import arrowDropDown from './icons/arrow_drop_down.svg';

const NUMBER_ITEMS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const STRING_ITEMS = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten'];
const OBJECT_ITEMS = [{
  label: 'Apples',
  value: 'A',
}, {
  label: 'Bananas',
  value: 'B',
}, {
  label: 'Cherries',
  value: 'C',
}, {
  label: 'Durian',
  value: 'D',
}, {
  label: 'Elderberry',
  value: 'E',
}];

const icon = <SVGIcon use={arrowDropDown.url} />;

const Filter = ({ simplifiedMenu }) => (
  <div className="md-grid md-text-left">
    <h4 className="md-cell md-cell--12">Filter Option1</h4>
    <SelectField
      id="select-field-1"
      label="Numbers"
      placeholder="Placeholder"
      className="md-cell md-cell--12"
      menuItems={NUMBER_ITEMS}
      simplifiedMenu={simplifiedMenu}
    />
    <SelectField
      id="select-field-2"
      label="Strings"
      placeholder="Placeholder"
      className="md-cell md-cell--12"
      menuItems={STRING_ITEMS}
      simplifiedMenu={simplifiedMenu}
    />
    <SelectField
      id="select-field-3"
      label="Objects"
      placeholder="Placeholder"
      className="md-cell md-cell--12"
      menuItems={OBJECT_ITEMS}
      simplifiedMenu={simplifiedMenu}
    />
	<h4 className="md-cell md-cell--12">Filter Option2</h4>
	<SelectionControl
      id="checkbox-read-documentation-page"
      name="simple-checkboxes[]"
      label="Open SelectionControl documentation page"
      type="checkbox"
      value="documentation"
      defaultChecked
    />
  </div>
);

Filter.propTypes = {
  simplifiedMenu: PropTypes.bool,
};

export default Filter;