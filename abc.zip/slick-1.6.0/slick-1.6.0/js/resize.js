//onResize: function(wait4AdLoadCount) {
function onResize() {
	var page = jQuery('#wrap'),
		minItemsInView = 1.07,
		width = jQuery(window).width(),
		items = 1,
		checkFooter = false;
	//wait4AdLoadCount = (wait4AdLoadCount)?wait4AdLoadCount:0;
	//
	//wait4AdLoadCount = (wait4AdLoadCount)?wait4AdLoadCount:0;
	//var wHeight = jQuery(window).height();
	//var headerHeight = jQuery('header').height();
	//var footerHeight = jQuery('footer').height();

	setDefaults = function(item) {
		var hPrimary = this.tileDefaults.hPrimary,
			header = this.tileDefaults.header,
			hSecondary = this.tileDefaults.hSecondary,
			//height = this.tileDefaults.height,
			optimalWidth = this.tileDefaults.optimalWidth,
			titleWidth = this.tileDefaults.titleWidth,
			titleHt = this.tileDefaults.titleHt,
			totalHeight = this.tileDefaults.totalHeight;
			contentMargin = this.tileDefaults.contentMargin;

		jQuery('#wrap').height(totalHeight+header);
		item.find('.carousel-row-item ').height(totalHeight);
		item.find('.carousel-row-item .maintitle').height(titleHt);
		// for single we need to add 6 to account for no margin between images
		item.find('.carousel-row-item .image_container').height(hPrimary+hSecondary);
	};	
	
	this.windowWidth = width;
	if (width < 767) {
		//return this.onResizeSmall();
	}

	// This is tied to the CSS media query which changes the page layout
	if (width < 600) {
		checkFooter = true;
	}

	// // Two items on medium screens
	// if (width > 768) {
	//     items = 2;
	// }

	// // 3 items on big screens
	// if (width > 1100) {
	//     items = 3;
	// }

	//items = parseInt(width / 716, 10) + 1;
	items = width / 395;

	// Calculate the width of an item
	width = parseInt(width / items, 10);

	// Calculate the height of an item
	// var heightOriginal = page.height() - 10;
	var heightOriginal = jQuery(window).height();
	// TODO - we need to get the window height minus the header and footer height

	//var heightOriginal = wHeight - headerHeight - footerHeight - 10;
	var header =  jQuery('header').height();
	var footer = jQuery('#legal').outerHeight();
	var height = heightOriginal;

	// If we have too much vertical space (portrait mode), correct this behavior by making the tiles larger
	if (heightOriginal > width * 1.5) {
		items -= 1;
		if (items < minItemsInView) {
			items = minItemsInView;
		}
		width = parseInt(this.windowWidth / items, 10);
	} else if (items < minItemsInView) {
		items = minItemsInView;
		width = parseInt(this.windowWidth / items, 10);
	}
	
	if (height < 32) {
		height = 32;
	}
	if (width < 32) {
		width = 32;
	}
	// we are using the .page element height which does not include the footer so we don't need to subtract it
	if (checkFooter) {
		var footerHeight = jQuery('footer').is(':visible') ? jQuery('footer #legal').height() : 0;
		heightOriginal -= footerHeight;
		height -= footerHeight;
	}

	var thresholdHeight = 0.2 * heightOriginal;
	if (thresholdHeight > 180) {
		thresholdHeight = 180;
	}
	if ((heightOriginal - height) < thresholdHeight) {
		var delta = thresholdHeight - (heightOriginal - height);
		height -= delta;
	}

	// allowed height is the allowed maximum height of the main image
	var secondaryTilePercentage = 0.45,
		allowedHeight = height;

	if (allowedHeight < 100) {
		allowedHeight = 100;
	}
	allowedHeight *= 1.0 - secondaryTilePercentage; // Assume the secondary tiles takes up around 33%

	// Calculate the optimal width required to show this image scaled at the allwed height
	var optimalWidth = 640 * allowedHeight / 360;
	var hPrimary, hSecondary, spacing;

	// If the optimal width is greater than the tile width, then just use the tile width 
	if (optimalWidth > (width - 10)) {
		optimalWidth = (width - 10);
	}
	hPrimary = optimalWidth * 360 / 640;
	hSecondary = hPrimary * secondaryTilePercentage;

	optimalWidth = parseInt(optimalWidth, 10);
	hPrimary = parseInt(hPrimary, 10);
	hSecondary = parseInt(hSecondary, 10);
	spacing = parseInt((width - optimalWidth) / 2, 10);


	//spacing = parseInt((width - optimalWidth) / 2, 10);
	//
	// height - total height of bottom is 292px so if the total height is less than 292 + 50 (title)
	// we need to do some recalculating of image size
	// 384 + 250=634
	// they do not want the red title to be more than 250px height
	//var titleHeight = 220;

	var titleH = heightOriginal - hPrimary - hSecondary - header - footer;
	var maxtitleHt = 0.4 * (heightOriginal);
	var titleHt = (titleH > maxtitleHt) ? parseInt(maxtitleHt, 10) : titleH; // Can't have a header bigger than the bottom
	//titleHt = ( titleHt < 100)?100:titleHt; // Need room for 300x50 ad + 50px of text
	var totalHeight =  heightOriginal - header - footer;;
	var titleWidth = optimalWidth;
	var contentMargin = 0;

	// Calculate the tile width and height
	this.tileWidth = optimalWidth + 10;
	this.tileHeight = heightOriginal;

	//if(wait4AdLoadCount !== 0){
	//page.pageCarousel("updateSize");
	//}

	// when it is coming back through for the ad call, it is recalculation the tile width but is not applying 
	// that value to the carousel tiles (carousel-row-item)

	this.tileDefaults = {
		header:header,
		footer:footer,
		height: height,
		hPrimary: hPrimary,
		hSecondary: hSecondary,
		optimalWidth: optimalWidth,
		titleWidth: titleWidth,
		titleHt: titleHt,
		contentMargin: contentMargin,
		totalHeight: totalHeight
	};
	this.setDefaults(page);
}
 onResize();
function windowResize() {
    onResize();
}

jQuery(window).resize(function () {
	if (this.resizeTO)
		clearTimeout(this.resizeTO);
	this.resizeTO = setTimeout(function () {
		windowResize();
	}, 500);
});
