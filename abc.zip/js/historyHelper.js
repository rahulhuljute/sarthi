(function(window) {
    var HistoryHelper = window.HistoryHelper = {};

    function normalizeUrlHelper(options) {
        var url = options.path;
        if (url.charAt(url.length - 1) === '/') {
            url = url + 'index.html';
        }
        return url;
    }

    function isSameOrigin(url) {
        // keeping this old code for now
        //var loc = window.location,
            //a = document.createElement('a');

        //a.href = url;
        //if(window.tnVars.isAndroid && !window.tnVars.isAndroidChrome){
           // alert('a.hostname: ' + a.hostname + '\nloc.hostname: ' + loc.hostname + '\na.port: ' + a.port + '; loc.port: ' + loc.port + '\na.protocol: ' + a.protocol + '\nloc.protocol: ' + loc.protocol);
        //}
        /*
        return a.hostname === loc.hostname &&
               a.port === loc.port &&
               a.protocol === loc.protocol;
        */
        var regExp = new RegExp("//" + location.host + "($|/)");
        var isSameOrigin = (url.substring(0,4) === "http") ? regExp.test(url) : true;
        return isSameOrigin;
    }

    $.extend(HistoryHelper, {
        isCurrentPageModal: false,
        wasPrevPageModal: false,
        closeModalDataDefault: {
            myUrl: '/',
            isModal: false,
            pageId: 'page-landing'
        },
        getPageUrl: function(theUrl) {
            var href = window.location.href,
                rtrnUrl = (theUrl && theUrl.length > 0) ? theUrl : href;
            rtrnUrl = (rtrnUrl.lastIndexOf(window.location.host) >= 0) ? rtrnUrl.substr(rtrnUrl.indexOf(window.location.host) + window.location.host.length) : rtrnUrl;
            rtrnUrl = normalizeUrlHelper({
                "path": rtrnUrl
            });
            return rtrnUrl;
        },


        init: function(modal, pageId) {
            var that = this;
            if (!that.initialized) {
                var historyJS_Obj = History.getState(),
                    weSaveContextForThisPage = (historyJS_Obj.data.index !== undefined) ? historyJS_Obj.data.index : false;
                
                //TODO: this grabs the current page title, but still may need improvement for modals    
                var curTitle = document.title;

                if (weSaveContextForThisPage === false) { // It is a History page we saved context for -- Do not update it
                    History.replaceState({
                        myUrl: that.getPageUrl(),
                        index: 0,
                        isModal: modal,
                        pageId: pageId
                    }, curTitle, historyJS_Obj.url); // TODO: fix title
                }
                History.Adapter.bind(window, 'statechange', function() {
                    HistoryHelper.historyStateChangeHandler();
                });

                that.setDefaultCloseModalData();
                that.initialized = true;
            }
        },
        setDefaultCloseModalData: function(){
            var that = this;
            var historyJS_Obj = History.getState();
            var url = historyJS_Obj.data.myUrl;

            if(url.indexOf('/shows/list.html') !== -1){
                History.closeModalData = {
                    myUrl: '/shows/list.html',
                    isModal: false,
                    pageId: 'page-shows-list'
                };
            } else if(url.indexOf('/shows/') !== -1){
                History.closeModalData = {
                    myUrl: '/shows/index.html',
                    isModal: false,
                    pageId: 'page-shows'
                };
            } else if(url.indexOf('/movies/') !== -1){
                History.closeModalData = {
                    myUrl: '/movies/index.html',
                    isModal: false,
                    pageId: 'page-movies'
                };
            } else if(!historyJS_Obj.data.isModal) {
                History.closeModalData = historyJS_Obj.data;
            } else {
                History.closeModalData = that.closeModalDataDefault;
            }
            console.log('cm 1: ' + History.closeModalData.myUrl);
        },
        historyStateChangeHandler: function() {
            //TODO: Test Use case: Reload page and then hit back to previous bookmark.  unshift to history array
            var that = this,
                historyJS_Obj = History.getState(),
                historyJSDataIndex = (historyJS_Obj.data.index !== undefined) ? historyJS_Obj.data.index : -1,
                historyJSDataIsModal = (historyJS_Obj.data.isModal !== undefined) ? historyJS_Obj.data.isModal : false,
                pageUrlTmp = historyJS_Obj.data.myUrl ? historyJS_Obj.data.myUrl : historyJS_Obj.url,
                pageUrl = that.getPageUrl(pageUrlTmp),
                theHash = (historyJS_Obj.hash)?decodeURI(historyJS_Obj.hash):'';

            //console.error("CHANGE", pageUrl, historyJS_Obj.data.pageId);
            if (historyJSDataIndex >= 0) { // It is a History page we saved context for and need to handle
                if (that.locationBarUrlWeKnow !== pageUrl) { // Ignore state changed with the same url
                    that.locationBarUrlWeKnow = pageUrl;
                    if(historyJSDataIsModal === false){
                        History.closeModalData = historyJS_Obj.data;
                        console.log('cm 1: ' + History.closeModalData.myUrl);
                    }
                    that.wasPrevPageModal = that.isCurrentPageModal;
                    that.isCurrentPageModal = historyJSDataIsModal;
                    Tn.parseHistoryPage(pageUrl, historyJS_Obj.data);
                }
            } else if(isSameOrigin(pageUrl) && (theHash.indexOf('|gigya') >= 0)){
                // We always should be managing the url but gigya is writing to the has tag sometimes ( see 'My Profile' on mobile and '|gigyaMobileDialog')
                console.log('gigya captured statechange.  do no work here');
            } else {
                // It not one of our managed pages so just send them there
                // It turns out that the loading of a page we don't manage made the UI look stalled, 
                // so instead of allowing the user to click around as if nothing happend, throw up our pjax splash
                Tn.showPjaxSplash(true);
                location.href = pageUrl;
            }
        },

        /**
            This function adds or replaces states in the history stack after we have entered into a modal state.  Four scenarios
            1 - Going forward to a modal from a page
            2 - Going back to a modal from a page 
            3 - Going forward to a page from a modal
            4 - Going back to a page from a modal
            - Going back to a modal from a off site link // TODO 
         */
        /*
             new requirements
             - back and forward buttons should work like regular pages; back and forth to pages as the user loaded them
             - modals should stay the same as now; click the close button and it goes back to the last non modal page
             ? - if close a modal then click the back button, does it go to the modal that was just closed?
             -- we are going to always need to pushState to save in History, but we need to track the modal state separately
                 to keep the close button functionality

        */
        changeStateHelper: function(options) {
            var that = this,
                nextPageUrl = that.getPageUrl(options.nextPageUrl),
                historyJSNextData = {},
                historyJS_Obj = History.getState(),
                historyJSDataIndex = (historyJS_Obj.data.index !== undefined) ? historyJS_Obj.data.index : 0,
                didHistoryStateChange = false,
                defaultTitle = window.siteDefaults.defaultTitle;

            //if(window.tnVars.isAndroid && !window.tnVars.isAndroidChrome){
                //alert( "locationBarUrlWeKnow: " + that.locationBarUrlWeKnow + "\nisSameOrigin(nextPageUrl): " + isSameOrigin(nextPageUrl) + "\nnextPageUrl: " + nextPageUrl );
            //}
            

            if (that.locationBarUrlWeKnow !== nextPageUrl) {
                didHistoryStateChange = true;
                historyJSNextData['index'] = historyJSDataIndex + 1;
                historyJSNextData['myUrl'] = nextPageUrl;
                historyJSNextData['isModal'] = options.isModalLinkClick ? true : false;
                historyJSNextData['pageId'] = options.pageId;
                
                //closeModalData
                if(!historyJSNextData['isModal']){
                    History.closeModalData = historyJSNextData;
                    console.log('cm 2: ' + History.closeModalData.myUrl);
                }
                
                if(!isSameOrigin(nextPageUrl)){
                    location.href = nextPageUrl;
                } else if (that.isCurrentPageModal && options.isModalLinkClick) {
                    //History.replaceState(historyJSNextData, defaultTitle, nextPageUrl);
                    History.pushState(historyJSNextData, defaultTitle, nextPageUrl);
                } else if (options.isModalLinkClick) {
                    History.pushState(historyJSNextData, "n/a", nextPageUrl);
                } else {
                    History.pushState(historyJSNextData, defaultTitle, nextPageUrl);
                }
            }

            return didHistoryStateChange;
        },

        set: function(param, value) {
            if (param !== undefined && param.length > 0) {
                this[param] = value;
            } else {
                console.log("Can't set invalid param");
            }
        },

        get: function(param) {
            var returnVal;
            if (param && param.length > 0) {
                returnVal = this[param];
            } else {
                console.log("Can't get invalid param");
            }
            return returnVal;
        }
    });

    HistoryHelper.locationBarUrlWeKnow = HistoryHelper.getPageUrl();

})(window);
