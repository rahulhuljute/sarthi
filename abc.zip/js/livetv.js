$.extend(Tn, {
    liveTVRefreshInterval: 1000 * 60 * 5, // 5 minute refresh interval
    liveCarouselTimer: null,
    refreshTVPage: function() {
        if (Tn.liveTVRefreshTimer) {
            clearTimeout(Tn.liveTVRefreshTimer);
            Tn.liveTVRefreshTimer = null;
        }

        var tvpage = $('#page-livetv .carousel-row-item');
        var onNowSections = $('.check-for-on-now');

        // Check to see if the live tv page is loaded
        if (tvpage.length !== 2 && onNowSections.length === 0) {
            Tn.liveTVRefreshTimer = setTimeout(Tn.refreshTVPage, Tn.liveTVRefreshInterval);
            return;
        }

        $.ajax({
            url: '/' + window.siteDefaults.liveLoc + '/',
            dataType: 'text'
        }).done(function(data) {
            data = $.parseHTML("<div>" + data.match(/<body[^>]*>([\s\S.]*)<\/body>/i)[0] + "</div>", document, false);
            var page = $(data).find('#page-livetv .carousel .item');
            if (page.length !== 2) {
                console.error("live tv page not found");
            } else {
                // console.error("Live TV Page Refresh Success!!!", page.length);
                var car = $(data).find('#page-livetv .carousel');
                var flowJson = Tn.getLiveTvFlowData( car );
                console.log('refresh flow json');
                //console.log(flowJson);
                if(tvpage.length === 2){

                    tvpage.each(function(index, val) {
                        var oldP = $(val);
                        var newP = $(page.get(index));


                        var onNowStartTime = newP.find('[data-id="vars"]').attr('onNowGuideStartTimeLong');
                        var loc = newP.find('[data-id="vars"]').attr('location');
                        var progType = newP.find('[data-id="vars"]').attr('programType');
                        var onNowTitleId = newP.find('[data-id="vars"]').attr('onNowTitleId');
                        var isPremiereText = '';
                        // we only want the premiere info for episodes
                        if(progType === 'E' || progType === 'EA'){
                            var isPremiere = Tn.findIsPremiere(flowJson, onNowStartTime, loc);
                            isPremiereText = isPremiere ? 'New' : isPremiereText;
                        }

                        // upNextStartTimeLong comes in as the eastern time even for the pacific live tile
                        var nextStartTimeLg = newP.find('[data-id="vars"]').attr('upNextStartTimeLong');
                        var tz = loc === 'eastern' ? 'America/New_York' : 'America/Los_Angeles';

                        var adjustedNextStartTm = Tn.getAdjustedStartTime(nextStartTimeLg, tz);
                        //console.log('adjustedNextStartTm: ' + adjustedNextStartTm);

                        if(adjustedNextStartTm === ''){
                            adjustedNextStartTm = newP.find('[data-id="vars"]').attr('upNextStartTime');
                        }
                        console.log('refreshTVPage: ' + 'loc: ' + loc + '; time: ' + adjustedNextStartTm);

                        // for movies, we will have the rating next to the title and no subtitle row
                        // the .oneline class on the text-wrapper will hide the subtitle element and
                        // will add top margin to the h2 so the background gradient will keep the same height

                        var tvRating = '<span class="rating">' + newP.find('[data-id="vars"]').attr('rating') + '</span>';
                        var title = newP.find('[data-id="title"]').text();
                        var subText = newP.find('[data-id="vars"]').attr('subText');
                        var textWrapperClass = subText === '' ? 'oneline' : '';

                        title = progType === 'FF' ? title + ' ' + tvRating : title;
                        subText = progType !== 'FF' ? subText + ' ' + tvRating : subText;

                        var oldSubText = oldP.find('.subtitle').text();
                        if(oldSubText.length === 0 && subText.length > 0){
                            oldP.find('.text-wrapper').removeClass('oneline');
                        }



                        oldP.find('.time').text(adjustedNextStartTm);
                        oldP.find('.upnext').text(newP.find('[data-id="vars"]').attr('upNext'));
                        oldP.find('.text-wrapper').addClass(textWrapperClass);
                        oldP.find('.title').html(title);
                        oldP.find('.subtitle').html(subText);
                        oldP.find('.availexpire').text(isPremiereText);

                        var newImageSrc = newP.find('img').attr('data-standard'),
                            tmpRetinaImg = newP.find('img').attr('data-retina'),
                            useRetinaImg = tnVars.useRetinaImg();
                        if(!newImageSrc || (useRetinaImg && tmpRetinaImg)){
                            newImageSrc = tmpRetinaImg;
                        }
                        var updateCB = (function(oldPage){
                                return function updateImage(theImageSrc){
                                    oldPage.find('.liveimg').attr('src', theImageSrc);
                                };
                            }(oldP));

                        if(progType === 'FF' && (!newImageSrc || newImageSrc.length == 0)){
                            Tn.fixMovieImages(onNowTitleId, updateCB);
                        } else {
                            updateCB(newImageSrc);
                        }
                        
                    });
                }
                if(onNowSections.length !== 0){

                    var newpageE = $(page).find('[data-id="vars"][location="eastern"]');
                    var titleE = newpageE.parent().find('[data-id="title"]').text();
                    var newpageW = $(page).find('[data-id="vars"][location="pacific"]');
                    var titleW = newpageW.parent().find('[data-id="title"]').text();
                    //console.log(newpageE);
                    //console.log(newpageW);
                    onNowSections.each(function(i, elem){
                        var $elem = $(elem);
                        var compareKey = $elem.attr('data-key');
                        var compareVal = $elem.attr('data-key-value');
                        var valE = newpageE.attr(compareKey);
                        var valW = newpageW.attr(compareKey);

                        // NOTE - East is the default if it matches both E and W
                        if(valE === compareVal){
                            console.log('it is on now east: ' + titleE);
                            if( $elem.find('.on-now-overlay').length === 0){
                                Tn.writeOnNowOverlay($elem, 'eastern');
                            }
                        } else if(valW === compareVal){
                            console.log('it is on now west: ' + titleW);
                            if( $elem.find('.on-now-overlay').length === 0){
                                Tn.writeOnNowOverlay($elem, 'pacific');
                            }
                        } else {
                            $elem.find('.on-now-overlay').remove();
                        }
                    });

                    
                }
                
            }
        }).fail(function() {
            console.error("Failed to load live tv page");
        }).always(function() {
            Tn.liveTVRefreshTimer = setTimeout(Tn.refreshTVPage, Tn.liveTVRefreshInterval);
        });
    },

    fixMovieImages: function(movieTitleId, cbHelper){
        $.ajax({
            url: '/service/api/v3/movies/' + movieTitleId + '/images',
            dataType: 'json'
        }).done(function(data) {
            var collectionOfImages = ( $.isPlainObject(data) )?data.collection:false;
            var useRetinaImg = tnVars.useRetinaImg();
            if($.isArray(collectionOfImages) && collectionOfImages.length > 0){
                var index = 0, lastIndex = collectionOfImages.length, minRequiredImageSrc, largestImageSrc = "", minWidth = 400;
                collectionOfImages.sort(function(a, b) {
                    if (a.width < b.width) //sort string ascending
                        return -1;
                    if (a.width > b.width)
                        return 1;
                    return 0;
                });
                //minRequiredImageSrc = collectionOfImages[lastIndex - 1];
                while(index < lastIndex){
                    var aImageObj = collectionOfImages[index];
                    if($.isPlainObject(aImageObj) && aImageObj.srcUrl.length > 0 ){
                        if(!minRequiredImageSrc && aImageObj.width > 400){
                            minRequiredImageSrc = aImageObj.srcUrl;
                        }
                        // It's sorted so use that to find what you want with a fallback
                        if(aImageObj.type == "445x250"){
                            theImageSrc = aImageObj.srcUrl;
                        } else if(useRetinaImg && aImageObj.type == "890x500"){
                            theImageSrc = aImageObj.srcUrl;
                        }
                        largestImageSrc = aImageObj.srcUrl; // sorted so the last in loop will be the largest
                    }
                    index++;
                }
                if(!theImageSrc){
                    if(!minRequiredImageSrc){
                        // Get the biggest since we only have small images
                        theImageSrc = largestImageSrc;
                    } else {
                        theImageSrc = minRequiredImageSrc;
                    }
                }
                cbHelper(theImageSrc);
            } else {
                cbHelper('');
            }
        }).fail(function() {
            cbHelper('');
        });
    },


    /**
     * [writeOnNowOverlay this can be used by pages to see if the displayed show/sport is playing live now]
     * @return {[type]} [description]
     */
    writeOnNowOverlay: function(elem, loc){
        var videoLinkLive = window.siteDefaults.name === 'TBS' ? Tn.mapLocToLiveTv.tbs[loc] : Tn.mapLocToLiveTv.tnt[loc];
        var parent = elem.find('.epleft2 > .image-wrapper');
        var text = ['<div class="on-now-overlay" data-videohref="' + videoLinkLive + '"><div class="playbut"></div>',
                '<div class="text"><div>This program is on now. Watch it LIVE.</div></div>',
            '</div>'].join('');
        parent.prepend(text);
        parent.find('.on-now-overlay').on('click', Tn.setOnNowPlayBtn);
    },
    setOnNowPlayBtn: function(event){
        event.preventDefault();
        event.stopPropagation();

        var lastClick = $(this).attr('lastclick');
        if (lastClick && (new Date().getTime()-lastClick)<250) {
            return;
        }

        $(this).attr('lastclick', new Date().getTime());

        var href = $(this).attr('data-videohref');
        if (!href || href.length === 0 || href === "undefined") {
            Tn.alert("No video url found");
            return;
        }
        Tn.showPlayer('http://' + $(location).attr('host') + href);
    },
    getAdjustedStartTime: function(dt, tz, format){
        var nst = '';
        var fmt = format ? format : 'h:mm a';
        try{
            // we need to find the difference in the offset of the incoming eastern time and the pacific time if it is pacific
            // get the dt in millis (unix time...millis since Epoch)
            var nextStartTimeMillis = moment(dt).format('x');

            //console.log('**********************');
            //console.log('tz: ' + tz );
            //console.log('dt: ' + dt );
            //console.log('nextStartTimeMillis: ' + nextStartTimeMillis);

            // then we need to get the offsets for the correct region for the time passed from the jsp
            var nextStartOffset = moment.tz(dt, tz);
            //console.log('nextStartOffset: ' + nextStartOffset );

            // then we get the offsets for time in eastern region
            // note - this could be the same as what was passed from the jsp
            
            var eastStartOffset = moment.tz(dt, 'America/New_York');
            //console.log('eastStartOffset: ' + eastStartOffset );

            // find the difference in millis between the eastern time and the region start time
            // this is the millis diff between the time zones for the passed in time
            var regionOffsetDiff = nextStartTimeMillis - nextStartOffset;
            //console.log('regionOffsetDiff: ' + regionOffsetDiff);

            // we want to make the adjustment on the eastern time, since the feed is always giving eastern time
            var adjustedStartTimeMillis = eastStartOffset + regionOffsetDiff;
            //console.log('adjustedStartTimeMillis: ' + adjustedStartTimeMillis);

            nst = moment(adjustedStartTimeMillis).format(fmt);
            //console.log('nst: ' + nst);
        } catch(e){
            console.log('Tn.getAdjustedStartTime did not work on livetv');
            console.log(e);
        }
        

        return nst;
    },
    getLiveTvFlowData: function(item){
        var flowData = $(item).find('.livetvFlowJson');
        var flowJson;
        if(flowData.text().length !== 0){
            try{
                flowJson = $.parseJSON(flowData.text());
            } catch(e){
                console.log('getLiveTvFlowData: flowData had a parsing error');
                console.log(e);
            }
            
        } else {
            console.log('getLiveTvFlowData: flowData 0 length');
        }
        $(item).remove();
        return flowJson;
    },
    findIsPremiere: function(data, time, loc){
        //console.log('***************');
        //console.log('findIsPremiere');
        if(!data || data.length === 0){
            console.log('findIsPremiere: there was an error in getting the flowJson');
            return false;
        }

        var isPremiere = false;
        var netFeedCode = loc === 'eastern' ? 'E' : 'W';
       
        //console.log('initial time: ' + time);
        if(netFeedCode === 'W'){
            // since the feed time is in eastern, we will need to do an adjustment here
            time = Tn.getAdjustedStartTime(time, 'America/Los_Angeles', 'YYYY-MM-DDTHH:mm:ss.SSS');
            //console.log('western adjusted time: ' + time);
        }
        // convert start time into UTC
        var startTime = moment(time).utc().format('YYYY-MM-DDTHH:mm:ss.SSS');
        console.log('start time UTC: ' + startTime);
        for(var i=0; i<data.length; i++){
            var show = data[i];
            // the flow feed has a 'Z' on the end of the data so we will add one to get an === comparison 
            // 2015-02-17T18:00:00.000Z
            var type = show.Titles[0].Type;
            // we only want this handled for episodes
            if(show.StartDate === startTime+'Z' && show.NetworkFeedCode === netFeedCode && (type === 'E' || type === 'EA') ){
                //console.log('show.StartDate: ' + show.StartDate);
                //console.log('show.NetworkFeedCode: ' + show.NetworkFeedCode);
                console.log('we have found the show: ' + show.Name + ' - ' + show.Titles[0].Name);
                if(show.IsPremiere === 'Y'){
                    isPremiere = true;
                    console.log('it is a premiere: ' + show.Name + ' - ' + show.Titles[0].Name);
                }
                break;
            }
        }
        return isPremiere;
    }



});

$('body').on('pageshown', function(event, pageId) {
    if (pageId !== 'page-livetv') {
        return;
    }

    // Page was already shown, so just call an update when the page is shown again
    if (Tn.livetvPageInitialized) {
        Tn.refreshTVPage();
        //$('#page-livetv').pageCarousel("resize");
        $('#page-livetv').pageCarousel("setYPos");
        return;
    }


    Tn.livetvPageInitialized = true;
    Tn.liveTVRefreshTimer = setTimeout(Tn.refreshTVPage, Tn.liveTVRefreshInterval);
    var carousels = [];
    var useRetinaImg = tnVars.useRetinaImg();
    


    $('#page-livetv .carousel').each(function() {
        var row = [];
        var flowJson = Tn.getLiveTvFlowData(this);

        var numTiles = $(this).find('div.item').length;
        // create map array for tbs branding
        Tn.setBrandingMap(numTiles, pageId);

        $(this).find('div.item').each(function() {
            var item = $(this),
                itemVars = item.children('span[data-id="vars"]'),
                imgSrc = item.children('[data-id="img"]').attr("data-standard");


            if (useRetinaImg) {
                if (item.children('[data-id="img"]').attr("data-retina") !== '') {
                    imgSrc = item.children('[data-id="img"]').attr("data-retina");
                }
            }
            // use the start time to look up in the flow api
            var onNowStartTime = itemVars.attr('onNowGuideStartTimeLong');
            var location = itemVars.attr('location');
            var progType = itemVars.attr("programType");
            var onNowTitleId = itemVars.attr("onNowTitleId");
            
            var isPremiereText = '';
            // we only want the premiere info for episodes
            if(progType === 'E' || progType === 'EA'){
                var isPremiere = Tn.findIsPremiere(flowJson, onNowStartTime, location);
                isPremiereText = isPremiere ? 'New' : isPremiereText;
            }
            
            // upNextStartTimeLong comes in as the eastern time even for the pacific live tile
            var nextStartTimeLg = itemVars.attr('upNextStartTimeLong');
            var tz = location === 'eastern' ? 'America/New_York' : 'America/Los_Angeles';

            var adjustedNextStartTm = Tn.getAdjustedStartTime(nextStartTimeLg, tz);
            console.log('tz: ' + tz + '; adjustedNextStartTm: ' + adjustedNextStartTm);

            if(adjustedNextStartTm === ''){
                adjustedNextStartTm = itemVars.attr("upNextStartTime");
            }

            // for movies, we will have the rating next to the title and no subtitle row
            // the .oneline class on the text-wrapper will hide the subtitle element and
            // will add top margin to the h2 so the background gradient will keep the same height
                        
            var tvRating = itemVars.attr("rating");
            var title = item.children('[data-id="title"]').text();
            title = progType === 'FF' ? title + ' <span class="rating">' + tvRating + '</span>' : title;
            var subText = itemVars.attr("subText");
            subText = progType !== 'FF' ? subText + ' <span class="rating">' + tvRating + '</span>' : subText;
            var textWrapperClass = subText === '' ? 'oneline' : '';
            
            row.push({
                isNew: itemVars.attr('span[data-id="isNew"]'),
                titleId: itemVars.attr("titleId"),
                subText: subText,
                textWrapperClass: textWrapperClass,
                tvRating: itemVars.attr("rating"),
                videoLink: item.children('[data-id="video-href"]').attr("href"),
                upNextTitle: itemVars.attr("upNext"),
                upNextRating: itemVars.attr("upNextRating"),
                upNextStartTime: adjustedNextStartTm,
                img: imgSrc,
                programType: progType,
                onNowTitleId: onNowTitleId,
                tileHeader: item.children('[data-id="tile-header"]').text(),
                title: title,
                isPremiereText: isPremiereText

            });
        });

        
        while (row.length < 1) {
            row.push({
                isPlaceholder: true
            });
        }

        carousels.push(row);
        $(this).remove();
    });

    

    function fm(txt) {
        var i, reg;

        // Check to see if we're using named value pairs
        if (arguments.length === 2 && typeof arguments[1] === 'object') {
            $.each(arguments[1], function(key, value) {
                reg = new RegExp("\\{" + key + "\\}", "gm");
                txt = txt.replace(reg, value);
            });
            return txt;
        }

        // We have a list of parameters, so traverse the list
        for (i = 1; i < arguments.length; i++) {
            reg = new RegExp("\\{" + (i - 1) + "\\}", "gm");
            txt = txt.replace(reg, arguments[i]);
        }
        return txt;
    }

    var isWindowScroll = false;
    if(window.tnVars.isIOS() || window.tnVars.isAndroid ){
        $('#page-livetv').addClass('is-window-scroll');
        isWindowScroll = true;
    }

    // make liveCarouselFunction a closure so we can call it in a if/else to find movie image and keep context
    var liveCarouselFunction = function(){
        $('#page-livetv').pageCarousel({
            itemCls: 'content-wrapper',

            carousels: carousels,
            useVerticalSnap: false,
            // alwasys refresh horizontal scroll
            alwaysRefreshHScrollOnResize: true,
            // always Refresh vertical scroll
            alwaysRefreshVScrollOnResize: false,
            // These values will be recalculated on screen resize to align everything
            tileWidth: 640,
            tileHeight: 360,

            bufferH: window.tnVars.isMobile() ? 2 : 2,
            bufferV: window.tnVars.isMobile() ? 0 : 0,
            isWindowScroll: isWindowScroll,


            // Called whenever the window is resized, to give you a change to position everything
            // TODO - the image does not have to be so small to leave the margins
            // need to adjut red header to make sure new image sizes have room with the footer
            
            onResizeSmall: function() {
                var page = $('#page-livetv');
                var width = $(window).width(),
                    items = 1,
                    checkFooter = true;

                this.windowWidth = width;

                items = parseInt(width / 716, 10) + 1;
                if (items > 2) {
                    items = 2;
                }

                // Calculate the width of an item
                width = parseInt(width / items, 10);

                // Calculate the height of an item
                var heightOriginal = page.height() - 5;
                var height = heightOriginal;

                // If we have too much vertical space (portrait mode), correct this behavior by making the tiles larger
                if (heightOriginal > width * 1.25) {
                    items -= 1;
                    if (items < 1) {
                        items = 1;
                    }
                    width = parseInt(this.windowWidth / items, 10);
                }

                if (height < 32) {
                    height = 32;
                }
                if (width < 32) {
                    width = 32;
                }
                if (checkFooter) {
                    var footerHeight = $('footer').is(':visible') ? $('footer').height() : 0;
                    heightOriginal -= footerHeight;
                    height -= footerHeight;
                }

                // the red title should always be at least 25% of the height of the page
                var thresholdHeight = 0.25 * heightOriginal;
                if (thresholdHeight > 180) {
                    thresholdHeight = 180;
                }
                if ((heightOriginal - height) < thresholdHeight) {
                    var delta = thresholdHeight - (heightOriginal - height);
                    height -= delta;
                }

                // allowed height is the allowed maximum height of the main image
                var allowedHeight = height;

                if (allowedHeight < 100) {
                    allowedHeight = 100;
                }

                // Calculate the optimal width required to show this image scaled at the allwed height
                var optimalWidth = 640 * allowedHeight / 360;
                var hPrimary;

                // If the optimal width is greater than the tile width, then just use the tile width 
                var firstTile =  page.find('.carousel-row-item').first();
                if (optimalWidth > width) {
                    optimalWidth = width;
                }
                hPrimary = optimalWidth * 360 / 640;

                optimalWidth = parseInt(optimalWidth, 10);
                hPrimary = parseInt(hPrimary, 10);
                // during resizing we reset css for main-footer
                page.find('.main-footer').removeAttr( 'style' );

                var tileFooterHeight = firstTile.find('.main-footer').outerHeight(true);
                var titleH = heightOriginal - hPrimary - tileFooterHeight;
                var totalHeight = hPrimary + titleH + tileFooterHeight;
                var titleWidth = optimalWidth;
                var titleHt = titleH;
                if(titleHt < (1.5 * tileFooterHeight)){
                    var headerPlusFooter = tileFooterHeight + titleHt;
                    titleHt = (2/3) * headerPlusFooter;
                    tileFooterHeight = tileFooterHeight / 3;
                    page.find('.main-footer').height(tileFooterHeight).css('padding', '0');
                }
                var contentMargin = 6;
               
                if(optimalWidth === width){
                    contentMargin = 0;
                }

                // the iscroll is not sending scrollend events consistently when there are 2 almost full tiles
                // so the classes were not getting set correctly to show the prev/next arrows
                // since on live tv we only have 2 tiles, i am hiding the arrows if this is the case
                if(optimalWidth < width && heightOriginal < 506){
                    page.find('.nav-slider').addClass('tn-hidden');
                } else {
                     page.find('.nav-slider').removeClass('tn-hidden');
                }

                // Calculate the tile width and height
                this.tileWidth = optimalWidth;
                this.tileHeight = totalHeight;

                page.find('.maintitle').width(titleWidth - contentMargin).height(titleHt);
                page.find('.main-content').height(hPrimary).width(optimalWidth - contentMargin);
                page.find('.main-footer').width(optimalWidth - contentMargin);

            },


            // Called whenever the window is resized, to give you a change to position everything
            // TODO - we need to account for the red main-footer height on the tiles
            onResize: function() {
                var page = $('#page-livetv');
                var width = $(window).width(),
                    items = 1;

                //var wHeight = $(window).height();
                //var headerHeight = $('header').height();
                //var footerHeight = $('footer').height();

                this.windowWidth = width;
                if (width < 767) {
                    return this.onResizeSmall();
                }

                items = parseInt(width / 716, 10) + 1;
                if (items > 2) {
                    items = 2;
                }

                // Calculate the width of an item
                width = parseInt(width / items, 10);

                // Calculate the height of an item
                var heightOriginal = page.height() - 10;
                //var heightOriginal = wHeight - headerHeight - footerHeight - 10;
                var height = heightOriginal;

                // If we have too much vertical space (portrait mode), correct this behavior by making the tiles larger
                if (heightOriginal > width * 1.25) {
                    items -= 1;
                    if (items < 1) {
                        items = 1;
                    }
                    width = parseInt(this.windowWidth / items, 10);
                }

                if (height < 32) {
                    height = 32;
                }
                if (width < 32) {
                    width = 32;
                }

                // the red title should always be at least 25% of the height of the page
                var thresholdHeight = 0.25 * heightOriginal;
                if (thresholdHeight > 180) {
                    thresholdHeight = 180;
                }
                if ((heightOriginal - height) < thresholdHeight) {
                    var delta = thresholdHeight - (heightOriginal - height);
                    height -= delta;
                }

                // allowed height is the allowed maximum height of the main image
                var allowedHeight = height;

                if (allowedHeight < 100) {
                    allowedHeight = 100;
                }

                // Calculate the optimal width required to show this image scaled at the allwed height
                var optimalWidth = 640 * allowedHeight / 360;
                var hPrimary;

                // If the optimal width is greater than the tile width, then just use the tile width 
                //var lastTile =  page.find('.carousel-row-item').last();
                //var lastTileMargin = lastTile.css('marginRight');
                //lastTileMargin = typeof(lastTileMargin) !== 'undefined' ? lastTileMargin.replace('px','').replace('em','') : 0;
                if (optimalWidth > (width - width*0.08)) {
                    optimalWidth = (width - width*0.08);
                }
                hPrimary = optimalWidth * 360 / 640;

                optimalWidth = parseInt(optimalWidth, 10);
                hPrimary = parseInt(hPrimary, 10);

                var tileFooterHeight = page.find('.carousel-row-item .main-footer').outerHeight(true);
                var titleH = heightOriginal - hPrimary - tileFooterHeight;
                var totalHeight = hPrimary + titleH + tileFooterHeight;
                var titleWidth = optimalWidth;
                var titleHt = titleH;
                var contentMargin = 6;

                // Calculate the tile width and height
                this.tileWidth = optimalWidth;
                this.tileHeight = totalHeight;

                // we are subtracting the contentMargin because we need to put the in between tile margins inside the tiles instead
                // of at the tile level or else we get scroll issues
                page.find('.maintitle').width(titleWidth - contentMargin).height(titleHt);
                page.find('.main-content').height(hPrimary).width(optimalWidth - contentMargin);
                page.find('.main-footer').width(optimalWidth - contentMargin);

            },

            // Called to grab the size of an item in the carousel
            // If you have ads in the carousel, you have to specify the size of the ad, instead of the carousel dimensions
            getItemDimensions: function() { /*carousel, index, data*/
                // Stick an ad at position 6
                /*
                if (index === 6) {
                    return {
                        w: 120,
                        h: 100
                    };
                }
                */
                // Return the responsive tile width and heights
                return {
                    w: this.tileWidth,
                    h: this.tileHeight
                };
            },

            // Called when an item is lazily added
            addItem: function(item, index, data, widget) {
                if (data.isPlaceholder) {
                    item.append('<div class="main-content"><img src="http://placehold.it/445x250/000000&text=PLACEHOLDER" style="width:100%; height:100%;"></div>');
                    return;
                }

                var branding = Tn.tbsBrandingActuals['page-livetv'][index];
                branding = typeof(branding) !== 'undefined' ? branding : 'default';
                item.attr('data-branding',branding);

                var text = fm([
                    '<div class="content-wrapper">',
                    '<div class="maintitle">',
                    '<div class="bottom"><h3>{tileHeader}</h3></div>',
                    '</div>',
                    '<div class="main-content" data-id="{titleId}" data-videohref="{videoLink}">',
                    '<div class="on-now">On Now</div>',
                    '<div class="main playbut"></div>',
                    '<img class="liveimg" src="{img}" style="width:100%; height:100%;">',
                    '<div class="caption">',
                    '    <div class="text-wrapper {textWrapperClass}">',
                    '        <h2><span class="title">{title}</span></h2>',
                    '        <span class="subtitle">{subText}</span><span class="availexpire">{isPremiereText}</span>',
                    '    </div>',
                    '</div>',

                    '</div>',
                    '<div class="main-footer">',
                    '   <span class="intro">Up Next:</span>',
                    '   <span class="time">{upNextStartTime}</span>',
                    '   <span class="upnext">{upNextTitle}</span>',
                    '   <span class="upnextrating">{upNextRating}</span>',
                    '</div>',
                    '</div>'
                ].join(''), data);
                if (!data) {
                    console.error("data.img");
                }
                item.append(text);

                if(window.siteDefaults.name.toLowerCase() === 'tnt'){
                    Tn.addBlurImage(item, data.img);
                }

                // NOT OVERLAYS ON LIVE TV - but we need this to set the play button event
                window.tnOverlays.init($(item).find('.main-content'));
                widget.resize();
            },

            // Called when an item is lazily removed
            removeItem: function(item) {
                window.tnOverlays.destroyTruncate(item);
                item.empty();
            },

            onArrowClick: function(event) {
                event.preventDefault();
                var widget = this.me;
                widget.scrollToPageOffset(this.index, this.offset);
            },

            rowAdded: function(item, index, carouselData, row) {

                item.append('<div class="nav-left nav-slider"></div><div class="nav-right nav-slider"></div>');
                item.append('<div class="shadowwrapper-left"><div class="shadow-left shadowbox"></div></div><div class="shadowwrapper-right"><div class="shadow-right shadowbox"></div></div>');
                item.find('.nav-left').on({
                    click: $.proxy(this.onArrowClick, {
                        me: row.widget,
                        index: index,
                        offset: -1
                    })
                });
                item.find('.nav-right').on({
                    click: $.proxy(this.onArrowClick, {
                        me: row.widget,
                        index: index,
                        offset: 1
                    })
                });

                //item.find('a.learnmore').on('click', function(event) {
                item.find('a.learnmore').on('tap', function(event) {
                    event.preventDefault();
                    Tn.setUrl($(this).attr("href"), true, 'page-generic');
                }).on('click', function(event) {
                    event.preventDefault();
                    Tn.setUrl($(this).attr("href"), true, 'page-generic');
                });

                // set margins of row header title to be centered <=600 or to 0 if >600 
                adjustTitle(item);
            },

            rowRemoved: function() {},

            onRowResized: function(index, row) {
                //console.error("Row Resized", arguments);
                //console.log('onRowResized');
                //console.log(row);
                if ($(window).width() <= 600) {
                    var ht = row.height();
                    row.height(ht);
                }
                // set margins of row header title to be centered <=600 or to 0 if >600 
                //adjustTitle(row);
            }
        });
    };

    var liveCarouselHelperFunction = function(){
        // We only need to run this once and there could be two if both movie images are missing.
        if (Tn.liveCarouselTimer) {
            clearTimeout(Tn.liveCarouselTimer);
            // We only have two so just run it right away
            liveCarouselFunction();
        } else {
            Tn.liveCarouselTimer = setTimeout(liveCarouselFunction, 200);
        }
    };


    // Do we need to fix movie image?
    var isThereAMissingMovieImage = check4MissingMovieImage(carousels);
    if(isThereAMissingMovieImage){
        fixMovieImages1stLoad(carousels, liveCarouselHelperFunction);
    } else {
        liveCarouselFunction();
    }
    
    

    
    /**
     * [fixMovieImages1stLoad - if there is missing movie images on the page, fetch the JSON for images and select on]
     * @param  {array} carousels [the typical page carousel pointer]
     * @return {function}  cb   [the function to be called to update the page with the new image]
     */
    function fixMovieImages1stLoad(carousels, cb){
        var iWillUpdateCarousel = false;
        for (var i = 0; i < carousels[0].length; i++) {
            var carousel = carousels[0][i];
            if((typeof(carousel.img) != 'string' || carousel.img.length == 0 ) && carousel.onNowTitleId.length > 0 && carousel.programType == "FF"){
                iWillUpdateCarousel = true;
                (function(carousel){
                    var cbHelper = function(theImageSrc){
                        carousel.img = theImageSrc;
                        cb();
                    };
                    Tn.fixMovieImages(carousel.onNowTitleId, cbHelper);
                })(carousel);
            }
        }
        // Here we have tighter conditions so update carousel with default images if needed
        if(!iWillUpdateCarousel){
            cb();
        }
    }

    /**
     * [check4MissingMovieImage - if there is missing movie images on the page, return true else return false]
     * @param  {array} carousels [the typical page carousel pointer]
     * @return {boolean}    [whether we have a missing movie image or not]
     */
    function check4MissingMovieImage(carousels, cb){
        var missingMovieImage = false;
        for (var i = 0; i < carousels[0].length; i++) {
            var carousel = carousels[0][i];
            if((typeof(carousel.img) != 'string' || carousel.img.length == 0 )){
                missingMovieImage = true;
            }
        }
        return missingMovieImage;
    }

    /**
     * [adjustTitle - vertically center the title in the <600px view]
     * @param  {[type]} hdr [description]
     * @return {[type]}     [description]
     */

    function adjustTitle(row) {
        var thisHdr = row.find('.carousel-row-header');
        var hdrHt = thisHdr.height();
        var title = thisHdr.find('.title');
        var titleHt = title.outerHeight();
        if (thisHdr.length > 0) {
            if ($(window).width() <= 600) {
                // we are adjusting the margin on the title to vertically center it
                // there could be multiple lines of title
                title.css('margin-top', (hdrHt - titleHt) / 2).css('margin-bottom', (hdrHt - titleHt) / 2);
            } else {
                thisHdr.find('.title').css('margin-top', '0').css('margin-bottom', '0');
            }
        }
    }

});
