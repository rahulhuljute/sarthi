window.onShowOverlayError = function(img) {
    if ($(img).attr('invalid') === "1") {
        return;
    }
    $(img).attr('invalid', "1");
    var title = $(img).closest('.carousel-row-item').find('.title span').text();
    if (title === '') {
        title = $(img).closest('.carousel-row-item').find('.text-wrapper .title').text();
    }
    //$(img).attr('src', '../images/no-image.gif');
    $(img).attr('src', 'http://placehold.it/640x360/000000&text=' + title);
};


/**
 * @class Tn
 */
$.extend(Tn, {

    playlistsOnShowPage: {},
    showsByNameData: {},
    clipPrefixText: 'EXTRA | ',
    mwtwLimitInd: 1,
    mwtwLimitOverlayInd: $(window).width() <= 687 ? 1 : 2,
    /**
     * [addBlurImage copy the main image into the tile header to add a blur filter]
     * @param {[type]} item    [description]
     * @param {[type]} imgPath [description]
     */
    addBlurImage: function(item, imgPath){

        if(tnVars.isIE || tnVars.isWindows) return false;

        // we will run this if not IE or windows mobile
        var pCont = item;
        var pBlurCont = pCont.find('.maintitle');
        var mainImg = imgPath;
        console.log('img blur\n');
        console.log(pCont);
        console.log(pBlurCont);
        console.log(mainImg);
        pBlurCont.prepend('<div class="blurImg" style="background-image: url(' + mainImg + ')"></div>');

    },
    /* Convert the duration of a video from seconds to a display format or empty if blank or -1 */
    formatDuration: function(durationSecs, type) {
        if (durationSecs !== durationSecs) {
            return '';
        }
        var durationMins = "";
        var timeStr = "";
        type = typeof(type) === 'undefined' ? '' : type;
        if (durationSecs !== null && durationSecs !== "" && durationSecs !== "-1") {
            if (durationSecs < 30) {
                durationMins = durationSecs;
                timeStr = type === 'small' ? 'secs' : 'seconds';
            } else {
                var secsRemaining = durationSecs % 60;
                if (secsRemaining < 30) {
                    durationMins = Math.floor(durationSecs / 60);
                } else {
                    durationMins = Math.ceil(durationSecs / 60);
                }
                if (durationMins === 1) {
                    timeStr = type === 'small' ? 'min' : 'minute';
                } else {
                    timeStr = type === 'small' ? 'mins' : 'minutes';
                }
            }
        }
        return durationMins + ' ' + timeStr;

    },
    getDurationSecs: function(txt) {
        var hms = txt.split(':');
        var duration = 0;
        // this converts the duration to seconds
        if (hms.length === 1) {
            duration = parseFloat(hms[0]);
        } else if (hms.length === 2) {
            duration = parseInt(hms[0], 10) * 60 + parseFloat(hms[1]);
        } else if (hms.length === 3) {
            duration = parseInt(hms[0], 10) * 60 * 60 + parseInt(hms[1], 10) * 60 + parseFloat(hms[2]);
        }
        //duration = Tn.formatDuration(duration);
        return duration;

    },

    managedAdItems: $('<div id="adManagedItems" class="tn-hidden"></div>'),

    /**
     * When the width is smaller than 900 banner ads will not fit and be shown
     */
    widthToStopShowingAdsOnShowPage: 900,

    /**
     * Updates the progress for all of the buttons in the input jQuery selector
     * @param  {Object} selector The jQuery selector
     */
    updateCanvasProgress: function(selector) {
        selector.each(function() {
            // ********this titleId is actually the videoId ********
            var but = $(this),
                titleId = but.attr('data-id'),
                isPlayable = but.parent().attr('data-playable'); // Used for homepage where we make teaser playable without o titleId

            // Make sure it's a button we're tracking
            if ((!titleId || titleId.length === 0) && (!isPlayable || isPlayable.length === 0 || isPlayable !== 'true')) {
                return;
            }

            // Get the progress of this button
            var progress = 0,
                history = Tn.Users.getPref('videoHistory', {}),
                videoHistoryKey = (titleId) ? Tn.Users.vidHistoryPrefix + titleId : 'noCnvskey';
            if (history[videoHistoryKey]) {
                progress = history[videoHistoryKey].pg || 0;
            }
            progress = parseInt(progress, 10);

            var isSmall = but.hasClass('sm');
            // smr is used on the secondary home page
            var isSmaller = but.hasClass('smr');
            // xsmall is used on the show learn more page
            var isXSmall = but.hasClass('xs');
            var size = isXSmall ? 24 : (isSmall ? 40 : (isSmaller ? 30 : 74));

            this.width = size; //but.parent().width()*0.3;
            this.height = size; //but.parent().width()*0.3;
            but.width(this.width).height(this.height);
            //but.css('margin', '-' + this.height/2 + 'px 0px 0px -' + this.width/2 + 'px');

            var ctx = this.getContext("2d");
            ctx.clearRect(0, 0, this.width, this.height);
            ctx.imageSmoothingEnabled = true;
            ctx.save();

            var radius = but.width() / 2;
            var bgcol = window.siteDefaults.fontColor; // the color of the play button without any progress
            var tr = radius * 0.33;

            //ctx.globalCompositeOperation = 'destination-over';
            // new chrome on windows was having an issue with destination-over in the way we were using it.
            // now the triangle is being written after the circle.
 
            ctx.shadowBlur = isXSmall ? 2 : (isSmall ? 4 : 8);
            ctx.shadowColor = "black";
            
            var lw = isSmall ? 2 : 4;
            ctx.lineWidth = lw;
            ctx.globalAlpha = 0.2;
            ctx.beginPath();
            ctx.translate(radius, radius);
            ctx.rotate(-Math.PI / 2);
            ctx.arc(0, 0, radius - lw - ctx.shadowBlur / 2, 0, 2 * Math.PI);
            ctx.fillStyle = 'black';
            ctx.fill();
            ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
            
            // we want the stroke of the circle and the red progress indicator on top of the circle (and triangle)
            ctx.globalCompositeOperation = 'source-over';
            ctx.globalAlpha = 1;
            ctx.strokeStyle = bgcol;
            ctx.stroke();
            
            // progress indicator
            ctx.strokeStyle = window.siteDefaults.playBtnProgressColor;
            ctx.beginPath();
            ctx.arc(0, 0, radius - lw - ctx.shadowBlur / 2, 0, progress * (2 * Math.PI) / 100);
            ctx.stroke();
            // restore puts the context back so the triangle will draw to the correct location
            ctx.restore();

            // play triangle
            ctx.fillStyle = bgcol;
            ctx.lineWidth = 1;
            ctx.strokeStyle = bgcol;
            ctx.beginPath();
            ctx.moveTo(tr * 0.25 + radius - tr, radius - tr);
            ctx.lineTo(tr * 0.25 + radius + tr, radius);
            ctx.lineTo(tr * 0.25 + radius - tr, radius + tr);
            ctx.fill();
            ctx.closePath();


        });
    },

    /**
     * Does a global update on all play buttons to show their current progress
     * @return {[type]} [description]
     */
    updateAllProgress: function() {

        Tn.updateCanvasProgress($('canvas.playbut'));
        $('div.playbut').each(function() {
            var but = $(this);
            var titleId = but.attr('data-id');

            // Make sure it's a button we're tracking
            if (!titleId || titleId.length === 0) {
                return;
            }

            var small = but.hasClass('sm');
            var style = Tn.buildProgressStylePosition(titleId, small);
            but.css('background-position', style);
        });
    },

    /**
     * Returns the progress offset as a background style to show the right progress string
     * @param  {String} titleId The id of the title in question
     * @param  {boolean} small  If true, will use the 34x34 progress icon sizes
     */
    buildProgressStyle: function(titleId, small) {
        var style = Tn.buildProgressStylePosition(titleId, small);
        return ' style="background-position:' + style + '" ';
    },

    buildProgressStylePosition: function(titleId, small) {
        // Calculate the progress inline, to account for the preference which may come after the page is loaded
        var progress = 0,
            history = Tn.Users.getPref('videoHistory', {}),
            videoHistoryKey = (titleId) ? Tn.Users.vidHistoryPrefix + titleId : 'noPoskey';
        if (history[videoHistoryKey]) {
            progress = history[videoHistoryKey].pg || 0;
        } else {
            progress = 0;
        }
        progress = parseInt(progress, 10);

        var bx = progress % 10,
            by = parseInt(progress / 10, 10);

        if (bx === 9 && by === 9 && progress < 100) {
            bx = 8;
        }
        if (progress >= 100) {
            bx = 9;
            by = 9;
        }

        var sz = 66,
            offset = 0;
        if (small) {
            sz = 34;
            offset = 660;
        }
        return Tn.fm('-{0}px -{1}px', bx * sz, offset + by * sz);
    },
    writeListView: function(){
        var data = Tn.showPageData.list.rowHdrData;
        //var rows = [];
        var page = $('#page-shows-list');
        var cont = page.find('.showlistview');
        $(data).each(function(index){
            var d = data[index];
            var uniqueClass = 'showList__row-' + index + '__';
            var dataTarg = '__row-' + index + '__';
            var text = Tn.fm([
                '<div class="accordion-wrapper">',
                    '<div data-toggle="collapse" class="shows-list accordionButtonNew ' + uniqueClass + '" data-target=".accordionContentNew.shows.' + dataTarg + '" data-showurl="{learnMoreHref}">',
                        '<i class="fa fa-caret-up"></i>{showTitle}</div>',
                        '<span>{numFullEpsAvail}</span>',
                        '<div class="buttons2">',
                           '<a itemprop="url" data-type="modal" href="{learnMoreHref}" title="{showTitle}"><span>i</span></a>',
                        '</div>',
                    '</div>',
                '</div>',
                '<div style="height: auto;" data-showurl="{learnMoreHref}" class="shows-list accordionContentNew shows ' + dataTarg + ' collapse" data-showname="{showTitle}" data-associated-div=".' + uniqueClass + '">',
                        '<div class="seasonlistview"></div>',
                '</div>'
             
            ].join(''), d);
            cont.append(text);
        });
        
        Tn.setShowsAccordionEvents(page);
        Tn.setShowListHt(page);
        Tn.setShowListClickEvents(page);
    },
    updateShowFilter: function() {
        // set the radio button values
        var pageId = Tn.currentPage;
        var page = $('#'+pageId);
        //var view = typeof(Tn.showPageData.view) !== 'undefined' ? Tn.showPageData.view: Tn.getShowsView(pageId);
        var view = Tn.showPageData.view;
        var sort = Tn.showPageData[view].sortOrder;
        page.find('.filter-menu .input-radio').removeClass('checked');
        page.find('.filter-menu .input-radio[data-value="' + view + '"]').addClass('checked');
        page.find('.filter-menu .input-radio[data-value="' + sort + '"]').addClass('checked');
    },
    initShowFilter: function(page, view, sort){
        page.find('.filter-menu .input-radio').removeClass('checked');
        page.find('.filter-menu .input-radio[data-value="' + view + '"]').addClass('checked');
        page.find('.filter-menu .input-radio[data-value="' + sort + '"]').addClass('checked');
    },
    getShowsView: function(pageId){
        return pageId === 'page-shows-list' ? 'list' : 'tile';
    },
    writeShowFilter: function(page, sel) {

        if(page.find('.filter').length === 0){
            sel = typeof(sel) === 'undefined' || sel === '' ? page : sel;
            var text = Tn.fm([
                '<div class="filter">',
                '                <div class="hdr1" ><span>View</span><span class="caret"></span></div>',
                '                <ul class="filter-menu">',
                '                    <li role="presentationview"><div tabindex="-1" class="input-radio" data-change="view" data-value="tile" ></div><div role="menuitem">Tile View</div></li>',
                '                    <li role="presentationview"><div tabindex="-1" class="input-radio" data-change="view" data-value="list" ></div><div role="menuitem">List View</div></li>',
                '                    <div class="hdr2" role="menuitem"><span>Sort</span></div>',
                '                    <li role="presentationsort"><div tabindex="-1" class="input-radio" data-change="sort" data-value="az" ></div><div role="menuitem">A-Z</div></li>',
                '                    <li role="presentationsort"><div tabindex="-1" class="input-radio" data-change="sort" data-value="featured" ></div><div role="menuitem">Featured</div> </li>',
                '                </ul>',
                '            </div>'

            ].join(''), Tn.spd);
           
            var isPhone = window.tnVars.isPhone();
            if(isPhone && sel !== page){
                page.find(sel).prepend(text);
            } else {
                page.append(text);
            }
            var filter = page.find('.filter');
            var arrow = filter.find("i.fa");
            if (!window.tnVars.isMobile()) {
                
                filter.on('mouseenter', function() {
                    $(this).find('.filter-menu').addClass('show');
                    $(arrow).removeClass("fa-caret-up").addClass("fa-caret-down");
                });

                filter.on('mouseleave', function() {
                    $(this).find('.filter-menu').removeClass('show');
                });
            }

            filter.find('.hdr1').on('touchstart', function(e) {
                e.preventDefault();
                filter.find('.filter-menu').toggleClass('show');
            });

            page.find('.filter-menu li[role="presentationview"]').on('click', Tn.changeShowsView);
            page.find('.filter-menu li[role="presentationsort"]').on('click', Tn.changeShowsSort);
        }
    },
    changeShowsSort: function(){
        // we are not loading a new page for this, just reloading the displayed data
        // we are getting the radio button inside the clicked li element
        var thisInput = $(this).find('.input-radio');
        var sortOrder = thisInput.attr('data-value');
        if(sortOrder !== Tn.showPageData[Tn.showPageData.view].sortOrder ){
            Tn.showPageData[Tn.showPageData.view].sortOrder = sortOrder;
            Tn.updateShowFilter();
            if(Tn.showPageData.view === 'list'){
                Tn.changeListSort(sortOrder);
            } else {
                Tn.changeTileSort(sortOrder);
            }
        }
        
    },
    changeListSort: function(sortOrder){
        if(sortOrder === 'featured'){
            Tn.showPageData.list.rowHdrData = Tn.showData.rowHdr;
        } else{
            Tn.showPageData.list.rowHdrData = Tn.showData.rowHdrSortAz;
        }
        var cont = $('#page-shows-list').find('.showlistview');
        cont.empty();
        //var cont = $('#page-shows-list').find('.showlistview');
        Tn.writeListView();
    },
    changeTileSort: function(sortOrder){
        if(sortOrder === 'featured'){
            Tn.showPageData.tile.rowHdrData = Tn.showData.rowHdr;
            Tn.showPageData.tile.carouselData = Tn.showData.carousels;
        } else{
            Tn.showPageData.tile.rowHdrData = Tn.showData.rowHdrSortAz;
            Tn.showPageData.tile.carouselData = Tn.showData.carouselsSortAz;
        }
        var page = $('#page-shows');
        page.pageCarousel("updateCarousel", Tn.showPageData.tile.carouselData);
        Tn.remixBrandingMap('page-shows');
        setTimeout(function() {
            page.pageCarousel("resize");
        }, 0);
    },
    changeShowsView: function(event) {
        // we are loading a new page each time it hits this function
        event.preventDefault();
        // set the url based on the state of the radio buttons
        // we are getting the radio button inside the clicked li element
        var thisInput = $(this).find('.input-radio');
        var view = thisInput.attr('data-value');
        Tn.showPageData.view = view;
        var href, pageId;
        if (view === 'tile') {
            href = '/shows/';
            pageId = 'page-shows';
        } else {
            href = '/shows/list.html';
            pageId = 'page-shows-list';
        }
        Tn.remixBrandingMap('page-shows');
        Tn.setUrl(href, false, pageId);
    },
    getShowsPage: function() {
        if (Tn.currentPage === 'page-shows') {
            return $('#page-shows');
        } else {
            return $('#page-shows-list');
        }
    },

    getSeriesData: function(url, associatedElClass, elem, hideSplash) {
        console.log('loading: ' + url);
        console.log(new Date().getTime());
        //$.getJSON(url).done(function(data) {
        $.ajax({
            url: url,
            dataType: 'html'
        }).done(function(data){
           //Tn.parseSeriesData(data, assocEl); // 1st done so guaranteed to be the first callback and there's no Tn.showData
           elem.addClass('loaded');
           console.log(new Date().getTime());
           elem.find('.seasonlistview').append(data);
           Tn.updateCanvasProgress( elem.find('.seasonlistview').find('canvas.playbut') );
           Tn.setShowListClickEvents( elem.find('.seasonlistview') );
           Tn.writeShowListMwtw(elem);
        }).fail(function() {
            Tn.alert("Failed to load series feed");
        }).always(function() {
            Tn.showPjaxSplash(false);
        });
    },
    writeShowListMwtw: function(elem){

        if(elem.find('.mwtwjsonshowlist').length === 0){
            return;
        }
        var txt = elem.find('.mwtwjsonshowlist').text();
        var data;
        try{
            data = $.parseJSON(txt);
        } catch (e){
            console.log('could not mwtw parse data');
            return;
        }

        var mwtw = "";
        var cont = elem.find('.mwtwlistview.season');
        cont.append('<div class="list"></div>');

        for (var m = 0; m < data.moreWaysToWatch.length; m++) {
            var item = data.moreWaysToWatch[m];
            mwtw += '<a href="' + item.url + '" class="ext" target="_blank">' + item.name + '</a>';

        }
        cont.find('.list').append('More episodes available on: ' + mwtw);

    },
    /**
     * set click events for list items
     * @param {jquery element} elem - jquery element to run find on
     */
    setShowListClickEvents: function(elem){

        elem.find('a[data-type]').not('.playbut, .playbutRef, .handled').on('click', function(event) {
            event.preventDefault();
            var type = $(this).attr('data-type');
            var href = $(this).attr('href');

            Tn.setUrl(href, true, 'page-generic');
        });
        elem.find('canvas').not('.handled').on('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
            Tn.setMobileDialogReturn();
            Tn.sendUmbelPlayTag(this, 'page-shows-list');
            var href = $(this).data('videohref');
            if(typeof(href) === 'undefined' || href.length === 0){
                href = $(this).parents('.main-content').data('videohref');
            }
            if (href && href.length > 0) {
                Tn.showPlayer(href);
            }
        });
    },
    setShowsAccordionEvents: function(page) {

        page.find('.accordionContentNew').on('show.bs.collapse', function(e) {
            // we want to grab the target element instead of the currentTarget
            // since we have nested accoridions, the event is bubbling up to the currentTarget instead of 
            // remaining on the clicked accord. buton
            var targetElem = $(e.target);
            var associatedElClass = targetElem.data("associated-div");

            if(targetElem.data("showurl")){
                var dataUrl = targetElem.data("showurl");

                if(typeof(dataUrl) === 'undefined' || dataUrl.length === 0){
                    console.error('there was an issue getting the dataUrl');
                    return;
                }
                dataUrl = dataUrl.replace('.html', '/seriesList.html');
                if(!targetElem.hasClass('loaded')){
                    Tn.getSeriesData(dataUrl, associatedElClass, targetElem);
                }
            }
         
            $(associatedElClass).find("i.fa").removeClass("fa-caret-up").addClass("fa-caret-down");

            //if( targetElem.hasClass('seasons') ){
                //Tn.setSeasonListHtSection(targetElem);
            //}
            

        }).on('shown.bs.collapse', function(e) {
            var targetElem = $(e.target);
            if( targetElem.hasClass('seasons') || targetElem.hasClass('clips')){
                Tn.setSeasonListHtSection(targetElem);
            }

        });


        page.find('.accordionContentNew').on('hide.bs.collapse', function(e) {
            var targetElem = $(e.target);
            var associatedElClass = targetElem.data("associated-div");
            $(associatedElClass).find("i.fa").removeClass("fa-caret-down").addClass("fa-caret-up");
        });
    },
    /**
     * Sorts an array of objects by a key value in an object
     * @param  {string} property name of the field we are sorting by
     * @return {array}  return an array of the sorted data
     */
    sortByProperty: function(property){
        var sortOrder = 1;
        if(property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return function (a,b) {
            var aStr = Tn.getSortString(a[property]);
            var bStr = Tn.getSortString(b[property]);
            //var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
            var result = (aStr < bStr) ? -1 : (aStr > bStr) ? 1 : 0;
            return result * sortOrder;
        };
    },
    /**
     * We want to not include 'The ' at the beginning of a name when we sort
     * @param  {string} str - the string to be compared
     * @return {string} return the string to be compared without 'the' at the beginning
     */
    getSortString: function(str){
        var s = str;
        return s.toLowerCase().indexOf('the ') === 0 ? s.substring(3).trim() : s;
    },
    /**
     * Sorts the carousel array by a field name
     * @param  {array} a - passed in array
     * @param  {array} b - passed in array
     * @return {array} return an array of the sorted arrays
     * 
     */
    sortArrayOfShows: function(a,b,fieldName){
        var aStr = Tn.getSortString(a[0].showTitle);
        var bStr = Tn.getSortString(b[0].showTitle);
        var result = (aStr < bStr) ? -1 : (aStr > bStr) ? 1 : 0;
        return result;
        /*
        if (a[0].showTitle < b[0].showTitle){
            return -1;
        }
        if (a[0].showTitle > b[0].showTitle){
            return 1;
        }
        return 0;
        */
    },
    /**
     * Given the page data, will parse the carousel data into carousels and their row headers
     * @param  {Object} pageData  jQuery object containing the DOM
     * @param  {Array} carousels The carousel row of items
     * @param  {Array} rowHdr    The row header result array
     */
    parseShowCarousel: function(pageData, carousels, rowHdr, sortAz) {
        var w = $(window).width(),
            videoRe = new RegExp("/videos/([^/]*)/");
        // we are passing in the onlyPhones boolean
        var useRetinaImg = window.tnVars.isRetinaScreen &&
            !(window.tnVars.isAndroid ||
                window.tnVars.isIPhone ||
                window.tnVars.isIPod ||
                window.tnVars.isIPad) ? true : false;

        pageData.each(function() {
            var row = [];

            $(this).find('div.row-hdr').each(function() {
                var hdr = $(this);
                var epAvail = hdr.children('p[data-id="num-full-eps-avail"]').attr('data-value');
                var episodeString = (epAvail === '1') ? 'Episode' : 'Episodes';
                var epAvailText = epAvail === '0' ? '' : epAvail + ' ' + episodeString + ' Available';
                var epAvailTextClass = epAvailText === '' ? 'tn-hidden' : '';
                var $theShowHdrAdHTML = hdr.children('div[data-ad-wrapper]'),
                    theShowHdrAdHTML = $theShowHdrAdHTML.length ? $theShowHdrAdHTML[0].outerHTML : '';
                var sponsorLogoText = $.trim(hdr.children('div.ad-text').text());

                rowHdr.push({
                    showTitle: hdr.children('h2[data-id="show-title"]').text().trim(),
                    showRatings: hdr.children('p[data-id="show-ratings"]').text(),
                    numFullEpsAvail: epAvailText,
                    epAvailTextClass: epAvailTextClass,
                    teaser: hdr.children('p[data-id="teaser"]').text(),
                    learnMoreHref: hdr.children('a[data-id="learn-more"]').attr('href'),
                    theShowHdrAdHTML: theShowHdrAdHTML,
                    sponsorLogoText: sponsorLogoText
                });
            });

            var showTitle, learnMoreHref;
            $.each(rowHdr, function() {
                showTitle = this.showTitle;
                learnMoreHref = this.learnMoreHref;
            });

            var sText = w < 500 ? 'S' : 'Season ';
            var eText = w < 500 ? 'E' : 'Episode ';
            var shortsText = 'S';
            var shorteText = 'E';
            var mwtwLimitInd = Tn.mwtwLimitInd;
            var mwtwLimitOverlayInd = Tn.mwtwLimitOverlayInd;

            $(this).find('div.item').each(function() {
                var item = $(this),
                    dataContentType = 'show',
                    itemVars = item.children('span[data-id="vars"]'),
                    isSpotlight = item.hasClass('spotlight') ? true : false,
                    $theAdHTML = item.children('div[data-ad-wrapper]'),
                    theAdHTML = $theAdHTML.length ? $theAdHTML[0].outerHTML : '',
                    theAdParameters = $theAdHTML.length && $theAdHTML.data('ad-parameters') ? $theAdHTML.data('ad-parameters') : {},
                    playable = itemVars.attr('isPlayable') === 'true' ? true : false,
                    //playlistSeriesName = itemVars.attr('playlistSeriesName') ? itemVars.attr('playlistSeriesName') : '', // Available in shows/byName
                    isTileLinkable = itemVars.attr('isTileLinkable') === 'true' ? true : false,
                    devOnlyFromCMA = itemVars.attr('devOnly') === 'yes' ? true : false,
                    duration = item.children('[data-id="duration"]').text(),
                    availExpire = itemVars.attr("availExpire"),
                    availExpireHover = itemVars.attr("availExpireHover"),
                    footerClass = availExpireHover.length === 0 ? 'tn-hidden' : '',
                    seasonNum = item.children('[data-id="season"]').text(),
                    epinfo = sText + seasonNum + ' | ' + eText + item.children('[data-id="ep"]').text(),
                    epinfoUPNEXT = shortsText + seasonNum + ' | ' + shorteText + item.children('[data-id="ep"]').text(),
                    contentTypeId = parseInt(itemVars.attr('contentTypeId'), 10),
                    contentTypeName = itemVars.attr('contentTypeName'),
                    tvRating = itemVars.attr('showRating'),
                    videoLink = item.children('[data-id="video-href"]').attr("href"),
                    epInfoLink = item.children('[data-id="ep-info-href"]').attr("href"),
                    isInPlaylist = (itemVars.attr('isInPlaylist') === 'true' && videoLink.indexOf('/videos/') > -1) ? true : false,
                    playlistSeriesName = '',
                    imgSrc = item.children('[data-id="ep-img"]').attr("data-standard"),
                    hideOverlayClass = '',
                    contentId = itemVars.attr("contentid"),
                    description = item.children('[data-id="ep-descr"]').text(),
                    epTitle = item.children('[data-id="title"]').text(),
                    belowFoldTitle = '',
                    episodeCount = itemVars.attr('episodeCount'),
                    titleId = itemVars.attr('titleid');

                // creating a new data item called videoId so we don't have to lie and say the titleid is the contentid :)
                // only clips should use contentId - everyting else uses @titleId or else the save state will not work
                // for clips the titleid in the feed is -1
                
                var videoId = titleId && (titleId === '-1' || titleId.length === 0) ? contentId : titleId;

                if(!playable){
                    videoId = "";
                }

                description = (typeof(description) === 'string') ? description.trim() : '';
                epInfoLink = (typeof(epInfoLink) === 'string') ? epInfoLink.trim() : '';

                //duration can be entered as 01:30 or as 120 (seconds)
                if (duration.indexOf(':') !== -1) {
                    duration = Tn.getDurationSecs(duration);
                }

                var epinfoPLUS = epinfoUPNEXT + " " + '<span class="smallRating">' + " " + tvRating + '</span>';

                if (devOnlyFromCMA && !Tn.devOnlyFromBrowser) {
                    return true; // skip this one
                }

                if (isInPlaylist) {
                    var aPlaylistSeriesMatch = videoLink.match('/videos/([^/]*)/');
                    if (aPlaylistSeriesMatch && typeof(aPlaylistSeriesMatch) === 'object' && aPlaylistSeriesMatch.length > 0) {
                        playlistSeriesName = aPlaylistSeriesMatch[1];
                    } else {
                        console.log('Error: should not get here');
                    }
                }

                if (useRetinaImg) {
                    if (item.children('[data-id="ep-img"]').attr("data-retina") !== '') {
                        imgSrc = item.children('[data-id="ep-img"]').attr("data-retina");
                    }
                }

                var videoContentTypeId = parseInt(window.siteDefaults.videoContentTypeId, 10);
                var externalVideoContentTypeId = parseInt(window.siteDefaults.externalVideoContentTypeId, 10);
                var seasonTileContentTypeId = parseInt(window.siteDefaults.seasonTileContentTypeId, 10);
               
                //var fullEpisodeContentTypeId = parseInt(item.children('[data-id="fullEpisodeContentTypeId"]').text(),10);

                // this is testing to see if it is a clip
                if (contentTypeId === videoContentTypeId) {
                    // currently in the feed for clips the prettyURL and prettyVideoUrl fields have the same value
                    epInfoLink = epInfoLink.replace('/videos/', '/shows/');
                    epinfo = Tn.clipPrefixText + item.children('[data-id="title"]').text();
                    epinfoUPNEXT = epinfo;
                    epinfoPLUS = epinfoUPNEXT;
                    dataContentType = 'clip';
                } else if (contentTypeId === externalVideoContentTypeId) {
                    // this is external video
                    // TODO - we want youtube handled differently
                    epinfo = item.children('[data-id="title"]').text();
                    playable = true;

                    if (itemVars.attr('videoType') === 'youtube') {
                        epinfo = Tn.clipPrefixText + epinfo;
                        epInfoLink = epInfoLink.replace('/videos/', '/shows/');
                    } else {
                        hideOverlayClass = 'tn-hidden';
                    }


                } else if (contentTypeId === 202) { // this is a teaser
                    if (videoRe.test(videoLink)) {
                        epinfo = item.children('[data-id="title"]').text();
                        if (!(epInfoLink) || !(description)) {
                            hideOverlayClass = 'tn-hidden';
                        }
                    }
                    duration = ''; // Blank out the duration since its not available
                } else if (contentTypeId === seasonTileContentTypeId) { // this is a season tile
                    epinfo = 'Season ' + seasonNum;
                    availExpire = '';
                    epTitle = 'Season ' + seasonNum;
                    epInfoLink = learnMoreHref;
                    duration = ''; // Blank out the duration since its not available
                    dataContentType = 'season';
                    mwtwLimitInd = w <= 687 ? 1 : 2;
                    mwtwLimitOverlayInd = w <= 687 ? 6 : 9;
                    belowFoldTitle = "Available for purchase or streaming.";

                }
                //console.log("contentTypeId: " + contentTypeId);


                if (duration < 0) {
                    duration = 0;
                }

                var durationTxt = Tn.formatDuration(duration);
                var notPlayableClass = '';
                if (!playable || duration === 0) {
                    durationTxt = "";
                    notPlayableClass = 'tn-hidden';
                }

                if (contentTypeId === seasonTileContentTypeId) { 
                    durationTxt = episodeCount !== '' ? episodeCount + " Episodes" : '';
                    notPlayableClass = "";
                }

                var mwtwtext = item.children('[data-id="mwtwjson"]').text();

                if (mwtwtext.length !== 0) {
                    var mwtw = Tn.getMwtwContent({
                        mwtwtext: mwtwtext,
                        epInfoLink: epInfoLink,
                        limit: mwtwLimitInd,
                        type: 'front',
                        playable: playable,
                        isSeasonTile: (contentTypeId === seasonTileContentTypeId ? true : false)
                    });
                    var mwtwOverlay = Tn.getMwtwContent({
                        mwtwtext: mwtwtext,
                        epInfoLink: epInfoLink,
                        limit: mwtwLimitOverlayInd,
                        playable: playable,
                        type: 'overlay',
                        isSeasonTile: (contentTypeId === seasonTileContentTypeId ? true : false)
                    });
                    if (mwtw !== "") {
                        availExpire = mwtw;
                        availExpireHover = mwtwOverlay;
                        footerClass = '';
                    }
                }

                if (w > Tn.widthToStopShowingAdsOnShowPage || theAdParameters.tileHeightLimit === undefined) {
                    row.push({
                        isSpotlight: isSpotlight,
                        contentid: contentId,
                        titleid: titleId,
                        playable: playable,
                        isPlayableClass: playable ? '' : 'hide',
                        isInPlaylist: isInPlaylist,
                        playlistSeriesName: playlistSeriesName,
                        isTileLinkableClass: isTileLinkable ? '' : 'hide',
                        contentTypeId: contentTypeId,
                        contentTypeName: contentTypeName,
                        tvRating: tvRating,
                        origPremiereDt: itemVars.attr('origPremiereDt') !== '' ? 'Airs ' + itemVars.attr('origPremiereDt') : itemVars.attr('origPremiereDt'),
                        availExpire: availExpire,
                        availExpireHover: availExpireHover,
                        footerClass: footerClass,
                        airOn: itemVars.attr("airOn"),
                        blurb: description,
                        showTitle: showTitle,
                        alt: showTitle,
                        epinfo: epinfo,
                        epinfoUPNEXT: epinfoUPNEXT,
                        epinfoPLUS: epinfoPLUS,
                        title: epTitle,
                        imgSrc: imgSrc,
                        duration: durationTxt,
                        epInfoLink: epInfoLink,
                        videoLink: videoLink,
                        notPlayableClass: notPlayableClass,
                        hideOverlayClass: hideOverlayClass,
                        theAdHTML: theAdHTML,
                        theAdParameters: theAdParameters,
                        dataContentType: dataContentType,
                        belowFoldTitle: belowFoldTitle,
                        videoId: videoId
                    });
                }
            });
            carousels.push(row);
            $(this).remove();
        });
        
        if(sortAz){
            Tn.showData.rowHdrSortAz = rowHdr;
            Tn.showData.carouselsSortAz = carousels;
            Tn.showData.rowHdrSortAz = $(Tn.showData.rowHdrSortAz).sort(Tn.sortByProperty("showTitle"));
            Tn.showData.carouselsSortAz = $(carousels).sort(Tn.sortArrayOfShows);
            Tn.showPageData.list.rowHdrData = Tn.showData.rowHdrSortAz;
        }
        
    },
    getMwtwContent: function(options){
        var mwtwtext = options.mwtwtext;
        var epInfoLink = options.epInfoLink;
        var limit = options.limit;
        var playable = options.playable;
        var type = options.type; // this is 'front' or 'overlay'
        var isSeasonTile = options.isSeasonTile;
        var mwtw = "", jsonData;
        if (mwtwtext.length !== 0) {

            try {
                jsonData = $.parseJSON(mwtwtext);
                //console.log("epInfoLink: " + epInfoLink);
            } catch (e) {
                console.error('The mwtw data did  not parse. ' + epInfoLink);
            }
        }
        if (jsonData && jsonData.moreWaysToWatch && !playable) {
            var data = jsonData.moreWaysToWatch;
            for (var m = 0; m <= limit && m < data.length; m++) {
                var item = data[m];
                mwtw += '<div data-href="' + item.url + '" class="ext" target="_blank">' + item.name + '</div>';
                if (m === limit && m < data.length - 1) {
                    mwtw += '<div class="more" data-type="mwtw" data-href="' + epInfoLink + '" style="display: inline;">More</div>';
                }
            }
            if (mwtw !== "") {
                
                if(type === 'overlay'){
                    // overlay of tile
                    if(isSeasonTile){
                        mwtw = '<span class="ways">' + mwtw + '</span>';
                    } else {
                        mwtw = '<span class="ways">WATCH:' + mwtw + '</span>';
                    }
                } else {
                    // front of tile
                    mwtw = '<span class="ways">WATCH:' + mwtw + '</span>';
                }
            }
        }
        return mwtw;
    },

    getCarouselDataHelper: function(data, callback) {
        data = $.parseHTML("<div>" + data.match(/<body[^>]*>([\s\S.]*)<\/body>/i)[0] + "</div>", document, false);
        var page = $(data).find('#page-shows .carousel');
        if (page.length === 0) {
            Tn.alert("Show page not found");
        } else {
            Tn.showData = {
                carousels: [],
                rowHdr: []
            };
            Tn.parseShowCarousel(page, Tn.showData.carousels, Tn.showData.rowHdr);
            callback(Tn.showData.carousels, Tn.showData.rowHdr);
        }
    },

    /**
     * Fetches the carousel data for shows and returns it back into the callback method
     */
    getCarouselData: function(callback, hideSplash) {
        if (!hideSplash) {
            Tn.showPjaxSplash(true);
        }
        if (Tn.showData) {
            callback(Tn.showData.carousels, Tn.showData.rowHdr);
            return;
        } else if (window.tnVars.jqXHR[window.tnVars.pageId4Cache]) {
            // Capturing the race condition between when Tn.showData is set and /shows/ is fetched.
            // Where we only need to call the /shows/ page once.
            window.tnVars.jqXHR[window.tnVars.pageId4Cache].done(function(data) {
                if (Tn.showData) {
                    callback(Tn.showData.carousels, Tn.showData.rowHdr);
                } else {
                    Tn.getCarouselDataHelper(data, callback);
                }
            }).always(function() {
                Tn.showPjaxSplash(false);
            });
            return;
        }
        window.tnVars.jqXHR[window.tnVars.pageId4Cache] = $.ajax({
            url: '/shows/',
            dataType: 'text'
        }).done(function(data) {
            Tn.getCarouselDataHelper(data, callback); // 1st done so guaranteed to be the first callback and there's no Tn.showData
        }).fail(function() {
            Tn.alert("Failed to load show page");
        }).always(function() {
            Tn.showPjaxSplash(false);
        });
    },

    /**
     * Given the page data, will parse the carousel data into carousels and their row headers
     * @param  {Object} pageData  jQuery object containing the DOM
     * @param  {Array} carousels The carousel row of items
     * @param  {Array} rowHdr    The row header result array
     */
    parseShowsByNameCarousel: function(pageData, carousels, playlistSeries, isPlaylist) {
        function getAttribute(attributeObj, attributeName) {
            var attribute, returnValue = '',
                attributeArr;
            if (attributeObj && typeof(attributeObj) === 'object') {
                attributeArr = attributeObj.attribute;
            }

            if (attributeArr && $.isArray(attributeArr)) {
                for (var i = 0; i < attributeArr.length; i++) {
                    attribute = attributeArr[i];
                    if (typeof(attribute) === 'object' && attribute.name === attributeName) {
                        returnValue = attribute.value;
                    }
                }
            }
            return returnValue;
        }

        function getTileItem(pageData, clipObj, playlistSeriesName, isInPlaylist) {
            //console.log('getTileItem');
            //
            var w = $(window).width();

            var sText = w < 500 ? 'S' : 'Season ';
            var eText = w < 500 ? 'E' : 'Episode ';
            var shortsText = 'S';
            var shorteText = 'E';

            var duration = parseInt(clipObj.duration, 10),
                epinfo = '',
                epinfoS = '',
                epinfoE = '',
                epinfoUPNEXTS = '',
                epinfoUPNEXTE = '',
                epinfoSubstr = '',
                epinfoUPNEXT = '',
                tvRating = (pageData.tvRating) ? pageData.tvRating : '',
                sponsoredNext = (typeof(pageData.series) === 'object') ? getAttribute(pageData.series.attributes, 'sponsoredNext') : '',
                //isInPlaylist = (sponsoredNext && sponsoredNext.length > 0)?true:false,
                videoLink = clipObj.prettyVideoUrl,
                epInfoLink = clipObj.prettyURL,
                imgSrc,
                imgTmp1 = '',
                imgTmp2 = '',
                imgTmp3 = '',
                findImageArr = [];

            if (isInPlaylist) {
                var plRegx = new RegExp('\/videos\/[^/]*\/');
                if (plRegx.test(videoLink)) {
                    videoLink = videoLink.replace(plRegx, '/videos/' + playlistSeriesName + '/');
                } else {
                    console.log('Error: should not get here');
                    playlistSeriesName = '';
                }
            } else {
                playlistSeriesName = '';
            }

            // Extra work until the feeds are sorted out
            if ($.isArray(clipObj.images) && typeof(pageData.series) === 'object' && $.isArray(pageData.series.images)) {
                findImageArr = clipObj.images.concat(pageData.series.images);
            } else if ($.isArray(clipObj.images)) {
                findImageArr = clipObj.images;
            } else if (typeof(pageData.series) === 'object' && $.isArray(pageData.series.images)) {
                findImageArr = pageData.series.images;
            }

            var doneHere = false;
            for (var i = 0; i < findImageArr.length && doneHere === false; i++) {
                var imageObj = findImageArr[i];

                if (imageObj.typeName === "445x250") {
                    imgTmp1 = imageObj.srcUrl;
                    doneHere = true;
                } else if (imageObj.typeName === "450x252") {
                    imgTmp2 = imageObj.srcUrl;
                    doneHere = true;
                } else if (typeof(imageObj.typeName) === 'string' && imageObj.typeName.length > 3) {
                    var xDim = imageObj.typeName.substring(0, imageObj.typeName.indexOf('x'));
                    if (xDim.length === 3 && xDim.charAt(0) === '4') {
                        imgTmp3 = imageObj.srcUrl;
                        doneHere = true;
                    }
                }
            }
            imgSrc = (imgTmp1.length > 0) ? imgTmp1 : (imgTmp2.length > 0) ? imgTmp2 : (imgTmp3.length > 0) ? imgTmp3 : '';
            if (imgSrc.length > 0 && imgSrc.indexOf('http://') !== 0 && imgSrc.indexOf('https://') !== 0) {
                var tntHostnameRE = new RegExp("tntdrama.com"),
                    tbsHostnameRE = new RegExp("tbs.com"),
                    myHostName = window.location.hostname,
                    cdn = '';

                if (tntHostnameRE.test(myHostName)) {
                    cdn = 'http://i.cdn.turner.com/v5cache/TNT/Images/';
                } else if (tbsHostnameRE.test(myHostName)) {
                    cdn = 'http://i.cdn.turner.com/v5cache/TBS/Images/Dynamic/';
                }
                imgSrc = cdn + imgSrc;

            }
            if (clipObj.seasonNo.length > 0) {
                epinfoS = sText + clipObj.seasonNo;
                epinfoUPNEXTS = shortsText + clipObj.seasonNo;
            }
            if (clipObj.episodeNo.length > 0) {
                epinfoE = eText + clipObj.episodeNo;
                epinfoUPNEXTE = shorteText + clipObj.episodeNo;
            }
            if (clipObj.seasonNo.length > 0 && clipObj.episodeNo.length > 0) {
                epinfoSubstr = ' | ';
            }
            epinfo = epinfoS + epinfoSubstr + epinfoE;
            epinfoUPNEXT = epinfoUPNEXTS + epinfoSubstr + epinfoUPNEXTE;


            // currently in the feed for clips the prettyURL and prettyVideoUrl fields have the same value
            epInfoLink = epInfoLink.replace('/videos/', '/shows/');
            epinfo = ''; // clipObj.showTitle; blank it out.  showTitle appears twice on up next
            epinfoUPNEXT = clipObj.showTitle;
            //console.log("contentTypeId: " + contentTypeId);

            if (duration < 0) {
                duration = 0;
            }
            //var durationTxt = duration.toFixed(2) + " minutes";
            //var durationTxt = Math.ceil(duration) + " minutes";
            var durationTxt = Tn.formatDuration(duration);

            return {
                isSpotlight: false,
                contentid: clipObj.contentId,
                titleid: -1,
                videoId: clipObj.contentId,
                playable: true,
                isPlayableClass: '',
                isInPlaylist: isInPlaylist,
                playlistSeriesName: playlistSeriesName,
                isTileLinkableClass: 'hide',
                contentTypeId: 200,
                contentTypeName: 'Video',
                tvRating: tvRating,
                origPremiereDt: '',
                availExpire: '',
                availExpireHover: '',
                footerClass: 'tn-hidden',
                nextUpPlaylist: sponsoredNext,
                airOn: '',
                blurb: clipObj.clipBlurbShort,
                showTitle: clipObj.showTitle,
                alt: clipObj.showTitle,
                epinfo: epinfo,
                epinfoUPNEXT: epinfoUPNEXT,
                epinfoPLUS: '', // epinfoUPNEXT + " " + '<span class="smallRating">' + " " + tvRating + '</span>', // blank it out.  showTitle appears twice on up next
                title: clipObj.showTitle,
                imgSrc: imgSrc,
                duration: durationTxt,
                epInfoLink: epInfoLink,
                videoLink: videoLink,
                notPlayableClass: '',
                hideOverlayClass: '',
                theAdHTML: '',
                theAdParameters: {}
            };
        }





        var w = $(window).width();
        // we are passing in the onlyPhones boolean
        var useRetinaImg = window.tnVars.isRetinaScreen &&
            !(window.tnVars.isAndroid ||
                window.tnVars.isIPhone ||
                window.tnVars.isIPod ||
                window.tnVars.isIPad) ? true : false;


        if (typeof(pageData) === 'object' && pageData.clips && pageData.clips.length > 0) {
            for (var i = 0; i < pageData.clips.length; i++) {
                carousels.push(getTileItem(pageData, pageData.clips[i], playlistSeries, isPlaylist));
            }
        }
    },

    /**
     * Fetches the carousel data for movies and returns it back into the callback method
     */
    getShowsByNameCarouselData: function(callback, series4VideoPlaying, isPlaylist) {
        if (Tn.showsByNameData[series4VideoPlaying]) {
            callback(Tn.showsByNameData[series4VideoPlaying].carousels, []);
            return;
        }
        // Fetch the show via a JSON call
        $.getJSON('/service/shows/byName/' + series4VideoPlaying + '.json').done(function(show) {
            //$.getJSON('/sponsored-playlist.json').done(function(show) {
            Tn.showsByNameData[series4VideoPlaying] = {
                carousels: [],
                rowHdr: []
            };
            Tn.parseShowsByNameCarousel(show, Tn.showsByNameData[series4VideoPlaying].carousels, series4VideoPlaying, isPlaylist);
            callback(Tn.showsByNameData[series4VideoPlaying].carousels, []);
        }).fail(function() {
            Tn.alert("Failed to load showbyname page");
            Tn.showsByNameData[series4VideoPlaying] = {};
        });
    },
    getPlaylistExpandedCarouselData: function(callback) {
        //Tn.showData must be defined
        if (Tn.showDataWithPlaylists) {
            callback(Tn.showDataWithPlaylists.carousels, Tn.showData.rowHdr);
            return;
        }
        var dataCarouselsWithPlaylists = [];
        //Tn.showData must be defined
        if (Tn.showData && Tn.showData.carousels) {
            dataCarouselsWithPlaylists = JSON.parse(JSON.stringify(Tn.showData.carousels)); // Clone the carousels.
        }
        if (dataCarouselsWithPlaylists.length > 0) {
            for (var i = 0; i < dataCarouselsWithPlaylists.length; i++) {
                var theCarousel = dataCarouselsWithPlaylists[i];
                for (var j = 0; j < theCarousel.length; j++) {
                    var theEp = theCarousel[j];
                    if (theEp.isInPlaylist && typeof(theEp.playlistSeriesName) === 'undefined') {
                        console.log('Error: why did we get here?');
                        theEp.playlistSeriesName = '';
                    }
                    if (theEp.isInPlaylist && theEp.playlistSeriesName.length > 0) { //theEp.playlistSeriesName has to be set in the shows/byName service
                        Tn.playlistsOnShowPage[theEp.playlistSeriesName] = 1;
                        if (Tn.showsByNameData[theEp.playlistSeriesName]) {
                            if (Tn.showsByNameData[theEp.playlistSeriesName].carousels && Tn.showsByNameData[theEp.playlistSeriesName].carousels.length > 0) {
                                var playlistEp,
                                    showsLandingEpIsInByNameplaylist = false,
                                    playlistCID,
                                    theEpVideoLink = (theEp.videoLink) ? theEp.videoLink : '';
                                for (var cIndex = 0, cLength = Tn.showsByNameData[theEp.playlistSeriesName].carousels.length; cIndex < cLength; cIndex++) {
                                    playlistEp = Tn.showsByNameData[theEp.playlistSeriesName].carousels[cIndex];
                                    playlistCID = (playlistEp.contentid) ? playlistEp.contentid : 'wontmatchjhthis';
                                    if (theEpVideoLink.indexOf(playlistCID) > -1) {
                                        showsLandingEpIsInByNameplaylist = true;
                                    }
                                    theCarousel.splice(j, 0, $.extend({}, playlistEp));
                                    j++; //theCarousel is now longer so skip the one added
                                }
                                if (showsLandingEpIsInByNameplaylist) {
                                    theCarousel.splice(j, 1); // remove theEp since it is in the playlist
                                }
                            } //else {
                            //     console.log('showsByNameData is empty');
                            //     theCarousel.splice(j, 0, $.extend({}, playlistEp));
                            //     j++; //theCarousel is now longer so skip the one added
                            // }
                        } else {

                            Tn.getShowsByNameCarouselData(function() {
                                Tn.getPlaylistExpandedCarouselData(callback);
                            }, theEp.playlistSeriesName, theEp.isInPlaylist);
                            return; // Try again after we have the playlist data
                        }
                    }
                }
            }
        }
        Tn.showDataWithPlaylists = {
            carousels: Tn.deDupList(dataCarouselsWithPlaylists),
            rowHdr: []
        };
        callback(Tn.showDataWithPlaylists.carousels, Tn.showData.rowHdr);
    },
    deDupList: function(carousels, seenObj) {
        var seen = (seenObj) ? seenObj : {},
            carousel;
        for (var i = 0; i < carousels.length; i++) {
            carousel = carousels[i];
            for (var j = 0; j < carousel.length; j++) {
                var item = carousel[j],
                    vidUrl = item.videoLink;
                if (seen[vidUrl] === true) {
                    carousel.splice(j, 1);
                    j--; // removed one so decrement the counter
                }
                seen[vidUrl] = true;
            }


            // carousel = carousel.filter(function(item) {
            //     var vidUrl = item.videoLink;
            //     return seen.hasOwnProperty(vidUrl) ? false : (seen[vidUrl] = true);
            // });
        }
        return carousels;
    },
    preloadData: function() {
        if (!Tn.movieData && Tn.videoType === 'movie') {
            Tn.getMovieCarouselData(Tn.preloadData, true);
        } else if (!Tn.showData) {
            Tn.getCarouselData(Tn.preloadData, true);
        } else if (!Tn.showDataWithPlaylists) { // requires Tn.showData so playlists can be added
            Tn.getPlaylistExpandedCarouselData(Tn.preloadData);
        } else if (Tn.videoPlayingIsSponsored && !Tn.playlistsOnShowPage[Tn.series4VideoPlaying]) {
            // Requires Tn.showDataWithPlaylists so we know what playlists are on the show page
            // This video might not be on the shows page so we just get the playlist
            if (!Tn.showsByNameData[Tn.series4VideoPlaying]) {
                Tn.getShowsByNameCarouselData(function() {
                    console.log("Carousel data pre-loaded!");
                }, Tn.series4VideoPlaying, true);
            }
        }
    },

    getImageTag: function() {
        return '<img src="{imgSrc}" alt="{alt}" style="width:100%; height:100%;position: relative;"/>';
    },
    /**
     * Initialize a show overlay
     */
    initializeShowOverlay: function(item, data) {
        if (data.isPlaceholder) {
            item.append('<div class="main-content"><img src="http://placehold.it/445x250/000000&text=PLACEHOLDER" style="width:100%; height:100%;"></div>');
            return;
        }

        // Update the progress on the play button

        data.playStyle = Tn.buildProgressStyle(data.videoId, false);

        var htmlTemplate = Tn.getItemHTMLStrHelper(data, {}),
            text = Tn.fm(htmlTemplate, data);

        item.append(text);

        window.tnOverlays.init(item.find('.main-content'));
        Tn.updateCanvasProgress(item.find('canvas.playbut'));
    },
    getItemHTMLStrHelper: function(data, options) {
        var htmlTemplate;
        if (data.contentTypeName === 'Ads') {
            htmlTemplate = '<div class="main-content" data-id="{videoId}" data-videohref="">' +
                '{theAdHTML}' +
                '</div>' +
                '<div class="advertisingimage_top"></div>';
        } else {
            htmlTemplate = '<div class="main-content" data-content-type="{dataContentType}" data-id="{videoId}" data-playable="{playable}" data-videohref="{videoLink}">' +
                '<canvas class="main playbut {isPlayableClass}" data-id="{videoId}" {playStyle}></canvas>';
            if (options.noImage) {
                htmlTemplate += '<span class="imgWrapper empty" data-src="{imgSrc}" data-alt="{showTitle} - {title}"></span>';
            } else {
                htmlTemplate += '<span class="imgWrapper" data-src="{imgSrc}" >' + Tn.getImageTag() + '</span>';
            }
            htmlTemplate += '{theAdHTML}' + // For 1x1's associate with a tile
                '<div class="caption withleft">' +
                '<div class="showInfoContainer">' +
                '<span class="showTitle">{showTitle}</span>' +
                '<span class="epinfo">{epinfo}</span>' +
                '</div>' +
                '<div class="text-wrapper">' +
                '<span class="special">{airOn}</span>' +
                '<span class="availexpire">{availExpire}</span>' +
                '</div>' +
                '</div>' +
                '<div class="icon-group2 {hideOverlayClass}">' +
                '<div class="icon plus"></div>' +
                '<div class="icon info"></div>' +
                '</div>' +
                '<a class="linkable-tile {isTileLinkableClass}" href="{epInfoLink}" target="_blank">&nbsp</a>' +
                '<div class="info-overlay">' +
                '<div class="icon-group">' +
                '<div class="icon plus"></div>' +
                '<div class="icon info" data-href="{epInfoLink}"></div>' +
                '<div class="icon playbut {isPlayableClass}"></div>' +
                '</div>' +
                '<div class="meta">' +
                '<div class="above-fold">' +
                '<div class="title">' +
                '<span>{title}</span>' +
                '</div>' +
                '<div class="specs {notPlayableClass}">' +
                '<div class="season">' +
                '<span></span>' +
                '</div>' +
                '<div class="ep">' +
                '<span></span>' +
                '</div>' +
                '<div class="time left">' +
                '<span>{duration}</span>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '<div class="below-fold">' +
                '<div class="ep-title">' +
                '<span>{belowFoldTitle}</span>' +
                '</div>' +
                '<div class="blurb truncate-h" style="">' +
                '{blurb}<div class="more" data-href="{epInfoLink}" style="display: inline;">More...</div>' +
                '</div>' +
                '</div>' +
                '<div class="footer {footerClass}">' +
                '<span class="availexpire">{availExpireHover}</span>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>';
        }
        return htmlTemplate;
    }

});

$('body').on('pageshown', function(event, pageId) {
    if (pageId !== 'page-shows' && pageId !== 'page-shows-list') {
        return;
    }

    /*
        WE ARE GOING TO HANDLE THE TILE AND LIST VIEWS AS IF THEY ARE ONE PAGE SINCE THEY USE THE SAME DATA SOURCE
        WE WILL LOAD BOTH VIEWS THE FIRST TIME ONE OF THE VIEWS IS HIT
    */
    var pageshowslist = $('#page-shows-list');
    var pageshows = $('#page-shows');
    var isPhone = window.tnVars.isPhone();
    var filterSel = isPhone  ? ".shows-info" : "";

    if (Tn.showsPageInitialized) {
        // if we hit the show page from another page on the site, the page-shows-list will not be put in th dom
        // thus the filter won't be written
        // we are checking for that here
        // 
        // we want to reset the height each time we show the list page
        Tn.setShowListHt( pageshowslist);
        if(!Tn.showPageListInitialized && pageshowslist.length > 0){
            
            Tn.writeShowFilter(pageshowslist, filterSel);
            Tn.initShowFilter(pageshowslist, 'list', 'az');
            Tn.writeListView();
            Tn.showPageListInitialized = true;
        }
        // Page was already shown, so just call an update when the page is shown again
        pageshowslist.removeClass('tn-hidden');
        pageshows.css('visibility', 'visible');

        // this is to close the filter upon changing views
        if(pageshowslist.find('.filter-menu').hasClass('show') && window.tnVars.hasTouchStart){
            pageshowslist.find('.filter').find('.hdr1').trigger('touchstart');
        }
        if(pageshows.find('.filter-menu').hasClass('show') && window.tnVars.hasTouchStart){
            pageshows.find('.filter').find('.hdr1').trigger('touchstart');
        }

        if (pageId !== 'page-shows') {
           
            if(!pageshows.is(":hidden")) {
                pageshows.hide();
            }
           
        } else {

            $('#page-shows').find('.carousel-row-item, .carousel-row-header').removeClass('adshown');
            //$('#page-shows').pageCarousel("resize");
            $('#page-shows').pageCarousel("setYPos");
            if(!pageshowslist.is(":hidden")) {
                pageshowslist.hide();
            }
        }
        return;
    }

    /*
            HERE WE ARE AT THE FIRST PAGE LOAD OF EITHER THE LIST OR TILE VIEW
    */
   
    if (Tn.showData) {
        delete Tn.showData.carousels;
        delete Tn.showData.rowHdr;
        delete Tn.showData.carouselsSortAz;
        delete Tn.showData.rowHdrSortAz;
    }
    Tn.showData = {
        carousels: [],
        rowHdr: [],
        carouselsSortAz: [],
        rowHdrSortAz: []
    };
    

    // Tn.showPageData holds the page object for the 2 views
    Tn.showPageData = {
        view: pageId === 'page-shows-list' ? 'list' : 'tile',
        tile: {
            sortOrder: 'featured',
            carouselData: Tn.showData.carousels,
            rowHdrData: Tn.showData.rowHdr
        },
        list: {
            sortOrder: 'az',
            rowHdrData: Tn.showData.rowHdrSortAz
        }
    };



    Tn.writeShowFilter(pageshows);
    Tn.initShowFilter(pageshows, 'tile', 'featured');
    
    

    if (pageId === 'page-shows') {
        pageshowslist.addClass('tn-hidden');
    } else{
        // we are hiding visibility instead of display so the carousels will init correctly
        // it will not find the pages if display: none
        pageshows.css('visibility', 'hidden');
    }
    
        
    Tn.showsPageInitialized = true;
    var pixelsOfRowHdrHorizontal = 687;
    var maxImageSize = 445;
    var bigMargins = 62;
    var smMargins = 8;
    var isWindowScroll = false;
    var bufferH = window.tnVars.isMobile() ? 0 : 2;
    var bufferV = window.tnVars.isMobile() ? 1 : 2;

    //if(window.tnVars.isAndroid && !window.tnVars.isAndroidChrome){
    // for Android phones we want vertical buffer of 2
    //if( window.tnVars.isAndroid && !window.tnVars.isAndroidChrome && !window.tnVars.isAndroidTablet() ){
    if (window.tnVars.isAndroid && !window.tnVars.isAndroidTablet()) {
        bufferV = 2;
    }
    // for tablets we want vertical buffer of 1
    if (window.tnVars.isIPad || window.tnVars.isAndroidTablet()) {
        bufferV = 1;
    }

    // for ios and android browser...we make these all window scroll....chrome app can stay in overflow scroll
    //if(window.tnVars.isIOS() || (window.tnVars.isAndroid && !window.tnVars.isAndroidChrome) ){
    if (window.tnVars.isIOS() || window.tnVars.isAndroid) {
        pageshows.addClass('is-window-scroll');
        isWindowScroll = true;
    }

    Tn.parseShowCarousel($('#page-shows .carousel'), Tn.showData.carousels, Tn.showData.rowHdr, true);

    // new tbs branding
    var numRows = Tn.showData.rowHdr.length;
    // create map array for tbs branding
    Tn.setBrandingMap(numRows, pageId);

    if(pageshowslist.length !== 0){
        Tn.writeShowFilter(pageshowslist, filterSel);
        Tn.initShowFilter(pageshowslist, 'list', 'az');
        Tn.writeListView();
        Tn.showPageListInitialized = true;
    }
    

    pageshows.pageCarousel({
        itemCls: 'content-wrapper',
        removeKeyHTMLOnDestroy: true,
        carousels: Tn.showPageData.tile.carouselData,
        rowHdr: Tn.showPageData.tile.rowHdrData,
        isWindowScroll: isWindowScroll,
        // These values will be recalculated on screen resize to align everything
        tileWidth: 445,
        tileHeight: 250,
        canHaveCarouselAds: true,
        bufferH: bufferH,
        bufferV: bufferV,
        useVerticalSnap: window.tnVars.isMobile() ? true : false,
        alwaysRefreshHScrollOnResize: true,
        //useVerticalSnap: true,
        //
        onResizeSmall: function() {
            var width = $(window).width(),
                cWidth = width,
                height,
                page = $('#page-shows'),
                items = 1;

            this.windowWidth = width;

            page.addClass('small-screen');


            this.canHaveCarouselAds = false;
            this.rowRightAdjustment = smMargins;




            if (cWidth > maxImageSize) {
                items = cWidth / maxImageSize;
            } else {
                width = cWidth - smMargins;
            }

            width = parseInt((width) / items, 10);

            // here we are trying to size the images so when the last image is fully visible on the right, the left image is correctly
            // hidden by the arrow on the left
            //width = parseInt((width - 5) / items, 10);

            // Calculate the height of an item
            height = parseInt(width * 250 / 445, 10);
            if (height < 32) {
                height = 32;
            }
            if (width < 32) {
                width = 32;
            }


            // Calculate the tile width and height
            this.tileWidth = width;
            this.tileHeight = height;

            //this.items = items;
        },

        // Called whenever the window is resized, to give you a change to position everything
        onResize: function() {
            var width = $(window).width(),
                cWidth = width,
                height,
                page = $('#page-shows'),
                items = 1;

            if (width <= pixelsOfRowHdrHorizontal) {
                this.onResizeSmall();
                return;
            }

            page.removeClass('small-screen');

            this.windowWidth = width;
            this.rowRightAdjustment = bigMargins;

            if (width > Tn.widthToStopShowingAdsOnShowPage) {
                height = 250;
                width = 445;
                this.canHaveCarouselAds = true;
            } else {
                // width is below 900px
                this.canHaveCarouselAds = false;
                if (width > 770) {
                    items = 1.2;
                } 

                // we are subtracting some extra width to allow space on the right side for arrows
                width -= 328;

                // Calculate the width of an item
                // width = parseInt((width - 5) / items, 10);
                // Calculate the width of an item
                // width = parseInt((width - 5) / items, 10);
                // here we are trying to size the images so when the last image is fully visible on the right, the left image is correctly
                // hidden by the arrow on the left
                width = parseInt((width - 5) / items, 10);

                if (cWidth > maxImageSize && cWidth >= (maxImageSize + this.rowRightAdjustment * 2)) {
                    width = width;
                } else if (cWidth > (maxImageSize + smMargins * 2) && cWidth < maxImageSize + bigMargins * 2) {
                    // if screen width is greater that max image plus the small margins and
                    // screen width is less that max image plus big margins
                    //width = maxImageSize;
                    width = cWidth - bigMargins * 2 >= maxImageSize ? maxImageSize : cWidth - bigMargins * 2;
                } else if (cWidth <= maxImageSize + smMargins * 2) {
                    // if the screen width is less= max image plus small margins
                    width = cWidth - smMargins * 2;
                } else if (cWidth <= maxImageSize) {
                    // if the screen width is less than 445, we use the screen width minus the small margins
                    width = cWidth - smMargins * 2;
                }

                // Calculate the height of an item
                height = parseInt(width * 250 / 445, 10);
                if (height < 32) {
                    height = 32;
                }
                if (width < 32) {
                    width = 32;
                }
            }

            // Calculate the tile width and height
            this.tileWidth = width;
            this.tileHeight = height;
            //this.items = items;
        },

        // Called to grab the size of an item in the carousel
        // If you have ads in the carousel, you have to specify the size of the ad, instead of the carousel dimensions
        getItemDimensions: function(carouselIndex, tileIndex, carouselData) { /*carousel, index, data*/
            var tileWidth, tileHeight, tileData, theAdParameters;
            try {
                tileWidth = this.tileWidth;
                tileHeight = this.tileHeight;
                tileData = carouselData[tileIndex];
                theAdParameters = tileData.theAdParameters;
            } catch (e) {
                console.log(e);
            }
            if (tileData && tileData.contentTypeName === 'Ads') { // This fixes the symptom not the cause. TENDP-12229.  Issue was problem with deep cloning ( fixed )
                if ((theAdParameters && theAdParameters.tileHeightLimit && theAdParameters.tileHeightLimit > tileHeight) ||
                    (theAdParameters && theAdParameters.tileWidthLimit && theAdParameters.tileWidthLimit > tileWidth) ||
                    (theAdParameters && theAdParameters.iHaveEpicAd !== 'true')) { // ROS ads won't work because they have the sam domId.  The flag for a bad ad is caught here
                    tileHeight = 1;
                    tileWidth = 1;
                } else if (theAdParameters && theAdParameters.tileWidth && theAdParameters.tileHeight) {
                    tileHeight = theAdParameters.tileHeight;
                    tileWidth = theAdParameters.tileWidth;
                }
            } else if (!tileData) {
                console.error('Should not get here.  tileData should be defined.');
            }
            // Stick an ad at position 6
            /*
            if (index === 6) {
                return {
                    w: 120,
                    h: 100
                };
            }
            */
            // Return the responsive tile width and heights
            return {
                w: tileWidth,
                h: tileHeight
            };
        },

        getTileDimensions: function() {
            return {
                w: this.tileWidth,
                h: this.tileHeight
            };
        },
        getImageTag: function() {
            return '<img src="{imgSrc}" alt="{alt}" style="width:100%; height:100%;position: relative;"/>';
        },

        // Called when an item is lazily added
        addItem: function(item, index, data) {
            // TODO: This should give a additional smaller sized image for phones or low bandwidth
            if (item.hasClass('isLightWeight')) {
                var $imgWrapper = item.find('span.imgWrapper.empty');
                if ($imgWrapper.length > 0) {
                    setTimeout(function() {
                        $imgWrapper.html(
                            Tn.fm(Tn.getImageTag(), {
                                imgSrc: $imgWrapper.data('src')
                            })
                        );
                    }, 50);
                }
            } else {
                Tn.initializeShowOverlay(item, data);
            }
        },

        /** Called when an item is lazily removed **/
        removeItem: function(item, itemIndex, data, removeKeyHTMLOnDestroy, removeHTMLOnDestroy) {
            window.tnOverlays.destroyTruncate(item);
            // Need to keep ads so sort removeItems that are memory hogs 
            if (removeKeyHTMLOnDestroy && !removeHTMLOnDestroy) {
                item.find('span.imgWrapper').empty().addClass('empty');
                item.addClass('isLightWeight');
            } else {
                item.empty();
            }

        },

        onArrowClick: function(event) {
            event.preventDefault();
            var widget = this.me;
            widget.scrollToPageOffset(this.index, this.offset);
        },
        rowAddedHelper: function(item) {
            item.addClass('hideloader');
        },
        rowAdded: function(item, index, carouselData, row) {
            // new tbs branding
            var branding = Tn.tbsBrandingActuals['page-shows'][index];
            branding = typeof(branding) !== 'undefined' ? branding : 'default';
            item.attr('data-branding',branding);

            // end new tbs branding
            var me = this,
                hdr = Tn.fm([
                    '<div class="carousel-row-header showsmeta">',
                        '<div class="meta-panel">',
                            '<div class="meta-panel_1">',
                                '<div class="title"><a href="{learnMoreHref}" class="learnmore">{showTitle}</a></div>',
                                '<div class="ratings">{showRatings}</div>',
                                '<div class="blurb numeps {epAvailTextClass}">{numFullEpsAvail}</div>',
                                '<div class="blurb tunein">{teaser}</div>',
                            '</div>',
                            '<div class="meta-panel_2">',
                                '<div class="sm-ad"><div class="ad-text">{sponsorLogoText}</div>{theShowHdrAdHTML}</div>',
                            '</div>',
                        '</div>',
                        //'<div class="button"><a class="watchlist" href="#">Watchlist</a></div>                                    ',
                        //'</div><div class="rowloader show"></div>'
                    '</div>'
                ].join(''), Tn.showPageData.tile.rowHdrData[index]);

            item.append(hdr);

            item.append('<div class="nav-left nav-slider"></div><div class="nav-right nav-slider"></div>');
            item.append('<div class="shadowwrapper-left"><div class="shadow-left shadowbox"></div></div><div class="shadowwrapper-right"><div class="shadow-right shadowbox"></div></div>');
            item.find('.nav-left').on({
                click: $.proxy(this.onArrowClick, {
                    me: row.widget,
                    index: index,
                    offset: -1
                })
            });
            item.find('.nav-right').on({
                click: $.proxy(this.onArrowClick, {
                    me: row.widget,
                    index: index,
                    offset: 1
                })
            });

            //item.find('a.learnmore').on('click', function(event) {
            item.find('a.learnmore').on('tap', function(event) {
                event.preventDefault();
                Tn.setUrl($(this).attr("href"), true, 'page-generic');
            }).on('click', function(event) {
                event.preventDefault();
                Tn.setUrl($(this).attr("href"), true, 'page-generic');
            });

            me.rowAddedHelper(item);

            // set margins of row header title to be centered <=600 or to 0 if >600 
            adjustTitle(item);
        },

        addCarousalEvents: function($rowEl, meRow, index) {
            // This is part of the old rowAdded function 
            var me = this;
            $rowEl.find('.nav-left').on({
                click: $.proxy(me.onArrowClick, {
                    me: meRow.widget,
                    index: index,
                    offset: -1
                })
            });
            $rowEl.find('.nav-right').on({
                click: $.proxy(me.onArrowClick, {
                    me: meRow.widget,
                    index: index,
                    offset: 1
                })
            });

            //$(row).find('a.learnmore').on('click', function(event) {
            $rowEl.find('a.learnmore').on('tap', function(event) {
                event.preventDefault();
                Tn.setUrl($(this).attr("href"), true, 'page-generic');
            }).on('click', function(event) {
                event.preventDefault();
                Tn.setUrl($(this).attr("href"), true, 'page-generic');
            });
        },

        addExtras4CarousalItem: function($rowItemEl) {
            window.tnOverlays.init($rowItemEl.find('.main-content'));
            Tn.updateCanvasProgress($rowItemEl.find('canvas.playbut'));
        },

        getExtraCarouselHTML: function(carouselIndex) {
            // This is the old rowAdded function
            var hdr = Tn.fm(
                '<div class="carousel-row-header showsmeta">' +
                '<div class="title">{showTitle}</div>' +
                '<div class="ratings">{showRatings}</div>' +
                '<div class="blurb {epAvailTextClass}">{numFullEpsAvail}</div>' +
                '<div class="blurb">{teaser}</div>' +
                '<div class="button"><a class="learnmore" href="{learnMoreHref}">Learn More</a></div>' +
                //'<div class="button"><a class="watchlist" href="#">Watchlist</a></div>' +
                //'</div><div class="rowloader show"></div>'
                '</div>', Tn.showPageData.tile.rowHdrData[carouselIndex]);

            hdr = hdr + '<div class="nav-left nav-slider"></div><div class="nav-right nav-slider"></div>' +
                '<div class="shadowwrapper-left"><div class="shadow-left shadowbox"></div></div><div class="shadowwrapper-right"><div class="shadow-right shadowbox"></div></div>';
            return hdr;
        },

        rowRemoved: function(item) {
            item.removeClass('hideloader');

        },
        onRowResized: function(index, row) {
            //console.error("Row Resized", arguments);
            if (this.windowWidth <= pixelsOfRowHdrHorizontal) {
                row.addClass('horizontal');
            } else {
                row.removeClass('horizontal');
            }
            //console.log('onRowResized');
            //console.log(row);
            // the timeout is here so the row ahs time to finish writing to the page resized before the resizeOverlay is called


            //setTimeout(function() {
            row.find('.carousel-row-item.active').find('.main-content').each(function() {
                var item = $(this);
                //TODO: Can I move this to getItemHTMLStr ?
                window.tnOverlays.resizeOverlay(item);
            });

            //}, 100);



            var rHdr = row.find('.carousel-row-header');
            if ($(window).width() <= pixelsOfRowHdrHorizontal) {
                // var hdrHeight = (rHdr.hasClass('adshown'))?134:80;
                // var ht = row.height() + hdrHeight;
                // row.height(ht);
                rHdr.width(this.windowWidth);
            } else {
                rHdr.width(186);
            }
            // set margins of row header title to be centered <=600 or to 0 if >600 
            adjustTitle(row);

        },

        onRowVisible: function(index, row) {
            // adding this additional width here was causing a huge flicker on desktop when it was trying to scroll to the spotlight
            // index at the end of the row.  it also was adding too much...we don't need this for desktop
            //var rowslider = row.find('.rowslider');
            //var rWidth = rowslider.width();
            //rowslider.width(rWidth + this.rowRightAdjustment);

            var w = $(window).width(),
                rHdr = row.find('.carousel-row-header');
            if (w <= pixelsOfRowHdrHorizontal) {
                // i am not sure where the extra 20 px comes from
                rHdr.width(w - 17);
                //var hdrHeight = (row.hasClass('headerAdShown'))?134:80,
                var hdrHeight = rHdr.outerHeight(),
                    tileDim = this.getTileDimensions(),
                    carouselHeight = tileDim.h,
                    ht = carouselHeight + hdrHeight;
                row.height(ht);
            } else {
                rHdr.width(186);
            }

            adjustTitle(row);
        },
        onRowItemsAdded: function(row) {
            row.find('.rowloader').removeClass('show');
        },
        onRowAdShown: function(){
            var that = this;
            return function(theAdWrapper, reset){
                if(theAdWrapper && $(theAdWrapper).parents('.carousel-row-header').length > 0){
                    var $row = $(theAdWrapper).parents('.carousel-row'),
                        index = $row.attr('index');
                    if(reset){
                        $row.removeClass('headerAdShown');
                        $row.find('.sm-ad').removeClass('ad-text-wrapper');
                        $row.find('.carousel-row-header .ad-text').hide();
                        that.onRowVisible(index, $row);
                    } else {
                        $row.addClass('headerAdShown');
                        $row.find('.sm-ad').addClass('ad-text-wrapper');
                        $row.find('.carousel-row-header .ad-text').show();
                        that.onRowVisible(index, $row);
                    }
                }
            };
        },
        getItemHTMLStr: function(data) {

            // Update the progress on the play button

            data.playStyle = Tn.buildProgressStyle(data.videoId, false);

            var htmlTemplate = Tn.getItemHTMLStrHelper(data, {
                    "noImage": true
                }),
                text = Tn.fm(htmlTemplate, data);
            return text;
        }
    });

    /**
     * [adjustTitle - vertically center the title in the <600px view]
     * @param  {[type]} hdr [description]
     * @return {[type]}     [description]
     */

    function adjustTitle(row) {
        var thisHdr = row.find('.carousel-row-header');
        var hdrHt = thisHdr.outerHeight();

        if (thisHdr.length > 0) {
            var contentHt = 0;
            thisHdr.find('div').not('.button').filter(":visible").each(function() {
                contentHt += $(this).outerHeight();
            });

            // if ($(window).width() <= pixelsOfRowHdrHorizontal) {
            //     // we are adjusting the row header padding vertically center the content
            //     // there could be multiple lines of tune in info
            //     // we are truncating the title to 1 line
            //     thisHdr.css('padding-top', ((hdrHt - contentHt) / 2) - 2).css('padding-bottom', (hdrHt - contentHt) / 2);
            // } else {
            //     thisHdr.css('padding-top', '10px').css('padding-bottom', '10px');
            // }
        }
    }


});
