// JavaScript
	
 var siteHost = "";
 var currentHost = window.siteDefaults.webSiteDomain;
 
 if(window.location.href.indexOf("dev19.tntdrama") > -1){
	siteHost = "http://dev19.tbs.com";
 } else if(window.location.href.indexOf("stage19.tbs") > -1){
	siteHost = "http://stage19.tntdrama.com";
 } else if(window.location.href.indexOf("stage19.tntdrama") > -1){
	siteHost = "http://stage19.tbs.com";
 } else if(window.location.href.indexOf("qa-ext.tntdrama") > -1){
	siteHost = "http://dev19.tbs.com";
 } else if(window.location.href.indexOf("dev19.tbs") > -1){
	siteHost = "http://dev19.tntdrama.com";
 } else if(window.location.href.indexOf("preprod19.tntdrama") > -1){
	siteHost = "http://preprod19.tbs.com";
} else if(window.location.href.indexOf("preprod19.tbs") > -1){
	siteHost = "http://preprod19.tntdrama.com";
} else if(window.location.href.indexOf("www.tntdrama.com") > -1){
	siteHost = "http://www.tbs.com";
 } else {
    siteHost = "http://www.tntdrama.com";
        }

 
$(document).ready (function () {
       
    $('#TNT-Switch'). click (function (e) {


        if(window.location.href == "http://dev19.tbs.com" || window.location.href == "http://dev19.tbs.com/" || window.location.href == "http://dev19.tbs.com/index.html" || window.location.href == "http://dev19.tbs.com/?O_CID=TBSMain"){
            this.href = siteHost + "/?O_CID=TNTMain";



		}else if(window.location.href == "http://preprod19.tbs.com" || window.location.href == "http://preprod19.tbs.com/" || window.location.href == "http://preprod19.tbs.com/index.html" || window.location.href == "http://preprod.19.tbs.com/?O_CID=TBSMain"){
            this.href = siteHost + "/?O_CID=TNTMain";      

       }else if(window.location.href == "http://www.tbs.com" || window.location.href == "http://www.tbs.com/" || window.location.href == "http://www.tbs.com/index.html" || window.location.href == "http://www.tbs.com/?O_CID=TBSMain"){
           this.href = siteHost + "/?O_CID=TNTMain";   

        } else if (window.location.href.indexOf("videos/movies") > -1){
            this.href = siteHost + "/movies/?O_CID=TNTMovPlayer"; 

   } else if (window.location.href.indexOf("videos" || "episode-" ) > -1){
            this.href = siteHost + "/shows/?O_CID=TNTEpiPlayer"; 

              } else if (window.location.href.indexOf("episode-") > -1){
            this.href = siteHost + "/shows/?O_CID=TNTShowInfo"; 

             } else if (window.location.href.indexOf("season-") > -1){
            this.href = siteHost + "/shows/?O_CID=TNTShowInfo"; 

        } else  if(window.location.href.indexOf("shows") > -1) {
            this.href = siteHost + "/shows/?O_CID=TNTShows";

        } else if (window.location.href.indexOf("movies/index.html") > -1) {
            this.href = siteHost + "/movies/?O_CID=TNTMovies";


        } else if (window.location.href.indexOf("movies") > -1) {
            this.href = siteHost + "/movies/?O_CID=TNTMovInfo";

        } else if (window.location.href.indexOf("search") > -1){
             this.href = siteHost + "/search.html?O_CID=TNTSearch";

        } else if (window.location.href.indexOf("help") > -1){
            this.href = siteHost + "/help.html?O_CID=TNTHelp";

        } else if (window.location.href.indexOf("watchtbs") > -1){
             this.href = siteHost + "/watchtnt/?O_CID=TNTLivePlayer";

         } else if ((window.location.href.indexOf("schedule") > -1) && (window.location.href.indexOf("list") > -1)){
            this.href = siteHost + window.location.pathname + "?O_CID=TNTSched";

         } else if (window.location.href.indexOf("schedule") > -1){
            this.href = siteHost + "/schedule/?O_CID=TNTSched";

        

        } else if (window.location.href.indexOf("privacy.html") > -1){
            this.href = siteHost + "/privacy.html";

         } else if (window.location.href.indexOf("terms.html") > -1){
            this.href = siteHost + "/terms.html";

           } else if (window.location.href.indexOf("dvs-offerings.html") > -1){
            this.href = siteHost + "/dvs-offerings.html";  

             } else if (window.location.href.indexOf("closed-captioning.html") > -1){
            this.href = siteHost + "/closed-captioning.html";  

  



        } else {
            this.href = sitehost + "/?O_CID=TNTMain";
        }
    });


     $('#TBS-Switch'). click (function (e) {

     	
       if(window.location.href == "http://dev19.tntdrama.com" || window.location.href == "http://dev19.tntdrama.com/" || window.location.href == "http://dev19.tntdrama.com/index.html" || window.location.href == "http://dev19.tntdrama.com/?O_CID=TNTMain"){
         this.href = siteHost + "/?O_CID=TBSMain";

      }else if(window.location.href == "http://preprod19.tntdrama.com" || window.location.href == "http://preprod19.tntdrama.com/" || window.location.href == "http://preprod19.tntdrama.com/index.html" || window.location.href == "http://preprod19.tntdrama.com/?O_CID=TNTMain"){
         this.href = siteHost + "/?O_CID=TBSMain"; 

    }else if(window.location.href == "http://qa-ext.tntdrama.com" || window.location.href == "http://qa-ext.tntdrama.com/" || window.location.href == "http://qa-ext.tntdrama.com/index.html" || window.location.href == "http://qa-ext.tntdrama.com/?O_CID=TNTMain"){
          this.href = siteHost + "/?O_CID=TBSMain";       

    }else if(window.location.href == "http://www.tntdrama.com" || window.location.href == "http://www.tntdrama.com/" || window.location.href == "http://www.tntdrama.com/index.html" || window.location.href == "http://www.tntdrama.com/?O_CID=TNTMain"){
         this.href = siteHost + "/?O_CID=TBSMain";    

  } else if (window.location.href.indexOf("videos/movies") > -1){
            this.href = siteHost + "/movies/?O_CID=TBSMovPlayer"; 

   } else if (window.location.href.indexOf("videos" || "episode-" ) > -1){
            this.href = siteHost + "/shows/?O_CID=TBSEpiPlayer"; 

              } else if (window.location.href.indexOf("episode-") > -1){
            this.href = siteHost + "/shows/?O_CID=TBSShowInfo"; 

             } else if (window.location.href.indexOf("season-") > -1){
            this.href = siteHost + "/shows/?O_CID=TBSShowInfo"; 

        } else  if(window.location.href.indexOf("shows") > -1) {
            this.href = siteHost + "/shows/?O_CID=TBSShows"; 


        } else if (window.location.href.indexOf("movies/index.html") > -1) {
            this.href = siteHost + "/movies/?O_CID=TBSMovies";

             } else if (window.location.href.indexOf("movies") > -1) {
            this.href = siteHost + "/movies/?O_CID=TBSMovInfo";

        } else if (window.location.href.indexOf("search") > -1){
             this.href = siteHost + "/search.html?O_CID=TBSearch";

        } else if (window.location.href.indexOf("help") > -1){
            this.href = siteHost + "/help.html?O_CID=TBSHelp";

        } else if (window.location.href.indexOf("watchtnt") > -1){
             this.href = siteHost + "/watchtbs/?O_CID=TBSLivePlayer";
        } else if ((window.location.href.indexOf("schedule") > -1) && (window.location.href.indexOf("list") > -1)){
            this.href = siteHost + window.location.pathname + "?O_CID=TBSSched";

        } else if (window.location.href.indexOf("schedule") > -1){
            this.href = siteHost + "/schedule/?O_CID=TBSSched";

         

            } else if (window.location.href.indexOf("privacy.html") > -1){
            this.href = siteHost + "/privacy.html";

         } else if (window.location.href.indexOf("terms.html") > -1){
            this.href = siteHost + "/terms.html";

           } else if (window.location.href.indexOf("dvs-offerings.html") > -1){
            this.href = siteHost + "/dvs-offerings.html";  

             } else if (window.location.href.indexOf("closed-captioning.html") > -1){
            this.href = siteHost + "/closed-captioning.html";  

           
        } else {
            this.href = sitehost + "/?O_CID=TBSMain";
        }
    });

});


