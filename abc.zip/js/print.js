$('body').on('pageshown', function(event, pageId) {

  var page = $('#' + pageId);

  page.find('.glyphicon-print').off('click').on('click', function(event) {

    var printContent;

    if ($('.auxContent').length === 0) {
      printContent = page.html();
    } else {
      printContent = page.find('.auxContent').html();
    }


    if ($('#printFrame').length === 0) {
      $('<iframe>', {
        id: 'printFrame',
        height: 0,
        width: 0,
        frameborder: 0
      }).appendTo('body');

      $('#printFrame').contents().find('head').append('<link rel="stylesheet" href="/css/print.css">');
    }

    $('#printFrame').contents().find('body').empty().append(printContent);
    $('#printFrame').get(0).contentWindow.print();
  });
});