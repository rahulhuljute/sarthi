window.currentPageUrl = window.location.href;


//for video player, flag live tv player so that data can be changed when show changes
var refreshLiveStreamData = false;

// These global variable are required for backwards compatibility with the existing auth and analytics system
window.logAdobe = false;
window.fw_ae = '';
window.hasSetFirstMetric = false;

//These global variable are intended to prevent over-reporting of analytics data
window.hasReportedPickerOpen = false;
window.hasReportedPickerList = false;
window.hasReportedPickerNoProvider = false;


//set auth vendorEnv to staging if not in production
if (window.location.hostname !== 'www.tntdrama.com' && window.location.hostname !== 'tntdrama.com' && window.location.hostname !== 'tbs.com' && window.location.hostname !== 'www.tbs.com') {
    var authVendorEnvId = 'staging';
    var authConfigEnvId = 'preprod';
} else {
    var authVendorEnvId = 'prod';
    var authConfigEnvId = 'prod';
}

// Used to track issues on startup
Tn.startupLog = '\n';

var Mousetrap = window.Mousetrap;

function logStartup(msg) {
    Tn.startupLog += msg + '\n';
}

// Hide the splash after 20 seconds if an error occured and output the startup log
setTimeout(function() {
    if (Tn.splashHidden) {
        return;
    }
    Tn.splashHidden = true;
    $('#screen-splash').fadeOut(1000);
    console.error("Splash took too long", Tn.startupLog);
}, 20000);

(function($, window, undefined) {
    var HistoryHelper = window.HistoryHelper,
        History = window.History,
        tnVars = window.tnVars,
        isMobile = tnVars.isMobile();

    if (tnVars.isAndroid && !tnVars.isAndroidChrome) {
        // we are targetting the Android default browser
        History.options.html4Mode = true;
    }
    // we have delayed the init until we pass in desired options
    History.init();

    // Set up the moment variables for displaying nice user date names
    moment.lang('en', {
        calendar: {
            lastDay: '[Yesterday]',
            sameDay: '[Today]',
            nextDay: '[Tomorrow]',
            lastWeek: '[last] dddd',
            nextWeek: 'dddd',
            sameElse: 'L'
        }
    });

    $.extend(Tn, {
        firstAuth: true,
        volumeLevel: 0.5,
        defaultVolumeLevel: 0.5,
        //savedVolumeLevel: 1,
        stateFrozen: false,
        maxVideoHistory: 50,
        upNextTimeInSeconds: 10,
        titles: {},
        brandImage: '',
        clickEventType: ((document.ontouchstart !== null) ? 'click' : 'touchstart'),
        sliderInProgress: false,
        getRandomInt: function(min, max){
            return Math.floor(Math.random() * (max - min + 1)) + min;
        },
        tbsBranding: {
            'page-landing': ['1', '2', '3', '4', '5', '6'],
            //'page-landing': ['pink', 'blue'],
            'page-shows': ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
            'page-schedule': ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
            'page-livetv': ['1', '2', '3', '4', '5', '6']
        },
        tbsBrandingActuals:{
            'page-landing': [],
            'page-shows': [],
            'page-schedule': [],
            'page-livetv': []
        },
        flashValue: function(){
            //Flash error message
            var flashErrorMsg = '';
            flashErrorMsg += '<strong>IMPORTANT</strong>: This website requires the Flash 11.1 (or higher) player.<br/>';
            flashErrorMsg += 'You may enable or upgrade your Flash plug-in by visiting the <a href="http://get.adobe.com/flashplayer/">Flash Download Center.</a><br/>';
            flashErrorMsg += 'Please note you may need to reboot your system.<br/>';
            flashErrorMsg += '<span class="closePopup gText">Close</span><div class="i-icon"></div>';
         
            flash = $('html').hasClass('flash');
            if(!flash){
                $('#fulloverlay').fadeIn(400);
                $('#noFlashPopup').html(flashErrorMsg);
                $('#noFlashPopup').fadeIn(600);

                $('.closePopup').on('click',function(){
                    $('#noFlashPopup').fadeOut('400');
                    $('#fulloverlay').fadeOut('500');
                });
            } else {

            }
        },
        detectFlash: function(){
            $('html').addClass(typeof CVP !== 'undefined' && CVP.swfobject.getFlashPlayerVersion().major !== 0 ? 'flash' : 'no-flash');
            var showNonFlashMessage = setTimeout(function(){
                Tn.flashValue()
            },400);
        },
        setBrandingMap: function(num, pageId, reset){
            var mapArr = Tn.tbsBrandingActuals[pageId];
            console.log('setBrandingMap');
            if(window.siteDefaults.name.toLowerCase() === 'tbs'){
                var cm = Tn.tbsBranding[pageId];
                if(typeof(cm) === 'undefined'){
                    return;
                }
                console.log('num: ' + num);
                if(reset){
                    Tn.tbsBrandingActuals[pageId] = [];
                }
                var cml = cm.length;
                console.log('color map length: ' + cml);
                var mapInd = Tn.getRandomInt(0, cml-1);
                console.log('mapInd: ' + mapInd);
                for(var i=0; i<num; i++){
                    var ind = mapInd > cml-1 ? mapInd%cml : mapInd;
                    console.log(ind);
                    Tn.tbsBrandingActuals[pageId].push(cm[ind])
                    mapInd++;
                }

                console.log('mapArr');
                console.log(Tn.tbsBrandingActuals[pageId]);
            }

            
            //return mapArr;
        },
        remixBrandingMap: function(pageId){
            if(window.siteDefaults.name.toLowerCase() !== 'tbs'){
                return;
            }
            console.log('remixBrandingMap pageId: ' + pageId);
            
            var branding = Tn.tbsBranding[pageId];
            var items;
            if(pageId === 'page-landing' && Tn.landingPageInitialized){
                items = $('#'+pageId).find('.carousel-row-item');
            } else if(pageId === 'page-shows' && Tn.showsPageInitialized){
                items = $('#'+pageId).find('.carousel-row');
            } else if(pageId === 'page-schedule' && Tn.schedulePageInitialized){
                items = $('#'+pageId).find('.carousel-row');
            }else if(pageId === 'page-livetv' && Tn.livetvPageInitialized){
                items = $('#'+pageId).find('.carousel-row-item');
            }  

            // on the first page load ther will be no items found
            if(typeof(items) === 'undefined'){
                return;
            }

            Tn.setBrandingMap(items.length, pageId, true);

            var actuals = Tn.tbsBrandingActuals[pageId];
            //console.log('actuals');
            //console.log(actuals);

            $.each(items, function(i){
                var item = $(this);
                item.attr('data-branding', actuals[i]);
            });


        },
        setSeasonListHt: function() {
            // we need to set the heights for IE
            // IE does not seem to like divs as table cells, and it would not set the top position correctly
            // without defining a height
            var lis = $('.shows-info').find('.seasonlist:visible').find('ol > li');
                       
            // set height to auto to clear out preexisting values
            lis.find('.theCol1 > div').css('height', 'auto');
            lis.find('.buttons2 > div').css('height', 'auto');

            lis.each(function() {
                var li = $(this);
                var ht = li.height();
                li.find('.theCol1 > div').css('height', ht);
                li.find('.buttons2 > div').css('height', ht);
            });

            // this is for the show list view to set the info icons at the show level
            //var divs = $('.shows-info').find('.seasonlist > .accoridion-wrapper');
            var divs = $('.shows-info').find('.seasonlist > .accordion-wrapper');
            divs.each(function() {
                var div = $(this);
                var ht = div.outerHeight();
                div.find('.buttons2 > a').css('height', ht);
                div.find('.buttons2 > a > span').css('margin-top', ht/2 - 20);
            });
        },
        setShowListHt: function(page){
            //var divs = $('.shows-info').find('.seasonlist > .accoridion-wrapper');
            var divs = page.find('.shows-info').find('.seasonlist > .accordion-wrapper');
            divs.each(function() {
                var div = $(this);
                var ht = div.outerHeight();
                div.find('.buttons2 > a').css('height', ht);
                div.find('.buttons2 > a > span').css('margin-top', ht/2 - 20);
            });
        },
        setSeasonListHtSection: function(elem){
            var lis = elem.find('ol > li');

                       
            // set height to auto to clear out preexisting values
            lis.find('.theCol1 > div').css('height', 'auto');
            lis.find('.buttons2 > div').css('height', 'auto');

            lis.each(function() {
                var li = $(this);
                var ht = li.height();
                li.find('.theCol1 > div').css('height', ht);
                li.find('.buttons2 > div').css('height', ht);
            });
        },

        getGenericMobileReturn: function(url){
            var pageId, path;
            if(url.indexOf('/movies/') !== -1){
                pageId = 'page-movies';
                path = '/movies/';
            } else if(url.indexOf('/sports/') !== -1){
                pageId = 'page-livetv';
                path = '/' + window.siteDefaults.liveLoc + '/';
            } else {
                pageId = 'page-shows';
                path = '/shows/';
            }
            return {
                'pageId': pageId,
                'path': path
            };
        },
        getVideoMobileReturn: function(url){
            var pageId, path;
            if(url.indexOf('/videos/') !== -1){
                if(url.indexOf('/movies/') !== -1){
                    pageId = 'page-movies';
                    path = '/movies/';
                } else {
                    pageId = 'page-shows';
                    path = '/shows/';
                }
            } else if(url.indexOf('/'+ window.siteDefaults.liveLoc + '/') !== -1){
                pageId = 'page-livetv';
                path = '/' + window.siteDefaults.liveLoc + '/';
            } else {
                pageId = 'page-shows';
                path = '/shows/';
            }
            return {
                'pageId': pageId,
                'path': path
            };
        },
        setMobileDialogReturn: function() {
            // the object this creates holds the return path for the mobile app dialog cancel
            var path = typeof(Tn.currentPagePath) !== 'undefined' ? Tn.currentPagePath : location.pathname;
            var pageId = Tn.currentPage;

            if(typeof(Tn.mobileDialogReturn) === 'undefined'){
                // if the object is not defined we need to do that here
                // a user may load a video page directly so there would not be a playbutton click before they need to set
                // the reutrn
                if(pageId === 'page-video' || pageId === ''){
                   Tn.mobileDialogReturn = Tn.getVideoMobileReturn(path);
                } else {
                    // we default to the shows page
                    Tn.mobileDialogReturn = {
                        'pageId': 'page-shows',
                        'path': '/shows/'
                    };
                }
            } else if(pageId === 'page-generic'){
                // for a generic page we need to test the path to determine the mobile return page
                Tn.mobileDialogReturn = Tn.getGenericMobileReturn(path);
            } else if(pageId === 'page-video'){
                // if up next is an episode, the user would be on the video page and get the mobile intercept
                // they may or may not have clicked a play button to start the ep video
                Tn.mobileDialogReturn = Tn.getVideoMobileReturn(path);
            } else {
                Tn.mobileDialogReturn = {
                    'pageId': Tn.currentPage,
                    'path': Tn.currentPagePath
                };
            }

        },
        sendUmbelShareTag: function(obj) {
            //_umbel.push({"type": "send", "name": "action.tag", "value": ["Share", "Twitter"]}); 
            //_umbel.push({"type": "send", "name": "action.tag", "value": ["Share", "Facebook"]}); 
            /*
            this is the object passed in when user clicks the gigya share button
            eventName: "sendDone"
            providers: "facebook"
            source: "showShareBarUI"
            sourceContainerID: "tn-autogen-1"
            targetURL: "http://devlocal.tntdrama.com:8080/shows/falling-skies/season-4/episode-2/the-eye.html"
            userMessage: ""
            */
            if (typeof(obj) !== 'undefined') {
                var socTmp = obj.providers;
                var soc = socTmp.charAt(0).toUpperCase() + socTmp.slice(1);
                console.log('soc: ' + soc);
                window._umbel.push({
                    "type": "send",
                    "name": "action.tag",
                    "value": ["Share", soc]
                });
            }

        },

        sendUmbelPlayTag: function(elem, pageId) {
            //on the click of the play button we want to send an umbel tag
            //_umbel.push({"type": "send", "name": "action.tag", "value": ["Shows", "<TV Show Name Here>"]}); 
            //_umbel.push({"type": "send", "name": "action.tag", "value": ["Movies", "Spider-Man"]}); 
            //_umbel.push({"type": "send", "name": "action.tag", "value": ["Live TV", "The King of Queens"]});
            var currPageId = typeof(pageId) !== 'undefined' ? pageId : Tn.currentPage;

            var $e = $(elem);
            var contentName = '',
                tabName = '';
            var videohref = $e.parents('.main-content, .secondary-item').attr('data-videohref');

            if ((!videohref || videohref.length === 0 || videohref === "undefined") && pageId !== 'page-generic') {
                return;
            }

            if (currPageId === 'page-livetv') {
                contentName = $e.parents('.main-content').find('.caption .title').text();
                tabName = 'Live TV';
            } else if (currPageId === 'page-landing') {
                contentName = $e.parents('.content-wrapper').find('.maintitle .bottom h2').text();
                tabName = Tn.getUmbelTabName(elem);

            } else if (currPageId === 'page-movies') {
                contentName = $e.parents('.main-content').find('.caption .title').text();
                tabName = 'Movies';
            } else if (currPageId === 'page-shows') {
                contentName = $e.parents('.carousel-row').find('.carousel-row-header .title').text();
                tabName = Tn.getUmbelTabName(elem);
            } else if (currPageId === 'page-shows-list') {
                contentName = $e.parents('.shows-list').data('showname');
                tabName = Tn.getUmbelTabName(elem, currPageId);
            } else if (currPageId === 'page-generic') {
                tabName = Tn.getUmbelTabName(elem, currPageId);

                // this is the structure for show page and movie page
                contentName = $e.parents('.infobox').find('.epright2 > .title').text();
                if (contentName.length === 0) {
                    // this is the struture for epinfo and clip info
                    contentName = $e.parents('#' + currPageId).find('.epright2 h2.title > a').text();
                }
                // we are using url matching here so we can accommodate the list and the play button on 
                // all generic pages with out adding data-content-type to everything
                tabName = Tn.getUmbelTabName(elem, currPageId);

            } else if (currPageId === 'page-video' || currPageId === 'page-youtube-video') {
                if ($e.parents('.extraWrapper').length !== 0) {
                    // watch extras clip
                    contentName = $e.parents('.infobox').find('h1.title').text();
                } else {
                    // up next video
                    contentName = $e.parents('.main-content').find('.caption .showTitle').text();
                }

                tabName = Tn.getUmbelTabName(elem);

            } else if (currPageId === 'page-search') {
                tabName = Tn.getUmbelTabName(elem);
                if (tabName === 'Shows' || tabName === 'Movies') {
                    contentName = $e.parents('.main-content').find('.caption .epinfo').text();
                } else if (tabName === 'Clips') {
                    contentName = $e.parents('.main-content').find('.caption .showTitle').text();
                }


            }

            console.log('tabName: ' + tabName + '\ncontentName: ' + $.trim(contentName.toUpperCase()));
            if (tabName !== '' && contentName !== '') {
                window._umbel.push({
                    'type': 'send',
                    'name': 'action.tag',
                    'value': [tabName, $.trim(contentName.toUpperCase())]
                });
            }

        },
        getUmbelTabName: function(elem, pageId) {
            var $e = $(elem);
            var pid = typeof(pageId) !== 'undefined' ? pageId : '';

            var dct = $e.parents('.main-content, .secondary-item').attr('data-content-type');
            // watch extras on a generic page has the dct in .main-content
            if (pid === 'page-generic' && typeof(dct) === 'undefined') {
                dct = $e.attr('data-content-type');
            } 
            var tabName;
            if (dct === 'show') {
                tabName = 'Shows';
            } else if (dct === 'clip') {
                tabName = 'Clips';
            } else if (dct === 'movie') {
                tabName = 'Movies';
            } else if (dct === 'live') {
                tabName = 'Live Tv';
            } else {
                tabName = '';
            }
            return tabName;
        },
        onVideoBackButton: function() {
            var historyJS_Obj_data = History.getState().data;
            //console.log('history data=' +historyJS_Obj_data);
            //console.log('onVideoBackButton history History.getCurrentIndex()=' + History.getCurrentIndex());
            if (typeof(historyJS_Obj_data) === 'object' && historyJS_Obj_data.index === 0) {
                //Since we don't want to loose them ( history index == 0 means a back button is another site or sessionStorage had problems ) 
                // send them to info page if we know about it
                var videosAssociatedInfoPage = '/index.html'; // When we don't have a associated info page like clips.  See showPlayerInternal
                if (Tn.videosAssociatedInfoPage) {
                    videosAssociatedInfoPage = Tn.videosAssociatedInfoPage;
                }
                if (videosAssociatedInfoPage.toLowerCase().indexOf('/watch') >= 0) {
                    Tn.setUrl(videosAssociatedInfoPage, false, 'page-livetv');
                } else if (videosAssociatedInfoPage === '/index.html') {
                    Tn.setUrl(videosAssociatedInfoPage, false, 'page-landing');
                } else {
                    Tn.setUrl(videosAssociatedInfoPage, true, 'page-generic');
                }
            } else {
                History.back();
            }
        },

        onHDToggleVisible: function(enabled) {
            // TENDP-11820: Not used for pHDS
        },

        updateActiveNavLink: function(pageId) {

            $('#mainnav').find('a').each(function() {
                var pid = $(this).attr('pageId');
                if (!pid) {
                    return;
                }
                if (pid !== pageId || ($(this).attr('modal') === '1') && pid !== 'page-search' && pid !== 'page-landing') {
                    $(this).removeClass('active');
                    if (tnVars.hasTouchStart && tnVars.windowW >= 768) {
                        $(this).addClass('noborder');
                    }
                } else {
                    $(this).addClass('active');
                    if (tnVars.hasTouchStart && tnVars.windowW >= 768) {
                        $(this).removeClass('noborder');
                    }
                }
                // the show tile and list views are 2 different page nodes
                if (pageId === 'page-shows-list' && pid === 'page-shows') {
                    $(this).addClass('active');
                    if (tnVars.hasTouchStart && tnVars.windowW >= 768) {
                        $(this).removeClass('noborder');
                    }
                }
            });

            // we added the schedule link as a div since its destination is dynamic based on device
            $('#mainnav').find('li > div').each(function() {
                var pid = $(this).attr('pageId');
                if (!pid) {
                    return;
                }
                if (pid !== pageId || ($(this).attr('modal') === '1') && pid !== 'page-search' && pid !== 'page-landing') {
                    $(this).removeClass('active');
                    if (tnVars.hasTouchStart && tnVars.windowW >= 768) {
                        $(this).addClass('noborder');
                    }
                } else {
                    $(this).addClass('active');
                    if (tnVars.hasTouchStart && tnVars.windowW >= 768) {
                        $(this).removeClass('noborder');
                    }
                }
                // the schedule tile and list views are 2 different page nodes
                if (pageId === 'page-schedule-list' && pid === 'page-schedule') {
                    $(this).addClass('active');
                    if (tnVars.hasTouchStart && tnVars.windowW >= 768) {
                        $(this).removeClass('noborder');
                    }
                }
            });


        },

        updateBrandImage: function() {
            if (Tn.brandImage.length > 0) {
                $(".att").css('background-image', 'url(' + Tn.brandImage + ')');
                $(".mvpd-logged-out").addClass('tn-hidden');
                $(".mvpd-logged-in").removeClass('tn-hidden');
                $(".mvpdoverlay").addClass('mvpdactive');
                return;
            }

            $(".att").css('background-image', '');
            $(".mvpd-logged-out").removeClass('tn-hidden');
            $(".mvpd-logged-in").addClass('tn-hidden');
            $(".mvpdoverlay").removeClass('mvpdactive');
        },

        closeMenu: function() {
            if ($('#navmain').hasClass('in')) {
                $('#navmain').collapse('hide');
                window.tnVars.enableMenuWindowScroll();
            }
        },
        loadImages: function(pageId) {
            // we need to pull the correct image standard/retina
            // this is for pages that are not build by javascript like the sport detail page
            // i wanted it to be asap so put it here instead of after the pageshown event is triggered
            var useRetinaImg = window.tnVars.isRetinaScreen &&
                !((window.tnVars.isAndroid && !window.tnVars.isAndroidTablet()) ||
                    window.tnVars.isIPhone ||
                    window.tnVars.isIPod) ? true : false;

            if ($('#' + pageId).find('img.loadimage').length !== 0) {

                $.each($('#' + pageId).find('img.loadimage'), function(index, img) {
                    var $img = $(img);
                    var imgSrc = img.src = $img.attr('data-standard');
                    if (useRetinaImg && $img.attr('data-retina') !== '') {
                        imgSrc = $img.attr('data-retina');
                    }
                    img.src = imgSrc;
                    // we only want the image to load 1 time
                    $img.removeClass('loadimage');
                });
            }
        },
        setAdTargets: function(pageId){
            var obj = window[window.siteDefaults.name];
            if(pageId === 'page-shows'){
                obj.adTargets.category = 'shows';
                window.AMPTManager.addPageLevelTarget('category', obj.adTargets.category);
            } else {
                window.AMPTManager.removePageLevelTarget('category');
                obj.adTargets.category = '';
            }
            
            console.log('adc: ' + obj.adTargets.category);
        },
        finalizePage: function(pageId, url) {
            // if there are any .loadimage images on the page, loadImages() will decide to pull standard or retina
            Tn.loadImages(pageId);

            if (isMobile || !$('body').hasClass('page-modal')) {
                // Hide any pages that aren't visible
                $('.page').each(function() {
                    var page = $(this),
                        id = page.attr('id');
                    if (id !== 'page-video' && id !== pageId) {
                        if (!page.is(":hidden")) {
                            // we are working with opacity here to try to avoid the carousel pages on ipad showing the new page
                            // before the old page is full hidden
                            if (isMobile) {
                                $('#' + id).css('opacity', 0);
                            }

                            $('#' + id).hide();
                        }
                    }
                    page.removeClass('modal');
                    $('#' + pageId).find(':first-child').removeClass('loading');
                });
            } else {
                // Hide other modals that should not be seen
                $('.page.modal').each(function() {
                    var page = $(this),
                        id = page.attr('id');
                    if (id !== pageId) {
                        if (!page.is(":hidden")) {
                            $('#' + id).hide();
                        }
                    }
                });
                $('#' + pageId).addClass('modal');
                $('#' + pageId).find(':first-child').removeClass('loading');
            }

            // can we remove the whole page from here??
            if (pageId !== 'page-embed360-video' && $('#page-embed360-video').length !== 0) {
                //$('#page-embed360-video.embed360').find('.embedPlayerDiv').empty();
                window.embed360Video.removePlayer();

            }

            // can we remove the whole page from here??
            if (pageId !== 'page-youtube-video' && $('#page-youtube-video').length !== 0) {
                window.ytVideo.removePlayer();

            }

            if (Tn.arkTanId && pageId === 'page-video') {
                Tn.showComments(Tn.arkTanId);
            } else {
                Tn.showComments();
            }

            Tn.currentPagePath = location.pathname;
            Tn.currentPage = pageId; // Side effect: when this changes for video, onContentPlayhead detects this and pauses/stops the video
            Tn.updateActiveNavLink(pageId);
            Tn.setAdTargets(pageId);

            // we are working with opacity here to try to avoid the carousel pages on ipad showing the new page
            // before the old page is full hidden
            if (isMobile) {
                $('#' + pageId).css('opacity', 1);
            }

            var viewport_width = window.innerWidth || document.documentElement.offsetWidth || document.documentElement.clientWidth || document.body.clientWidth;
            window.ad_page_mode = "TABLET_OR_DESKTOP"; // Also seen in head.jsp
            if (viewport_width < 601) {
                window.ad_page_mode = "MOBILE";
            }
            $('#headerAds').find('.banner_ad').addClass('tn-hidden');
            var goodAdInfoObj = window.adHelper.specialAdsInfoPerURL(url);
            if (goodAdInfoObj.theClass && window.ad_page_mode === "MOBILE") {
                $('#headerAds').find('.banner_ad.' + goodAdInfoObj.theClass).removeClass('tn-hidden');
                $(window.adHelper.mobileAdWrapperSelector).show();
                $('#' + pageId).addClass('hasMobileAd');
            } else {
                $(window.adHelper.mobileAdWrapperSelector).hide();
                $('#' + pageId).removeClass('hasMobileAd');
            }

            // we would need to update the branding here before the page is displayed
            Tn.remixBrandingMap(pageId);

            $('#' + pageId).show().trigger('pageshow');
            $('body').trigger('pageshown', pageId);

            // Check to see if we're on the video player page
            if (pageId === 'page-video') {
                $('#page-video').addClass('shown');
            } else if ($('#page-video').hasClass('shown')) {
                // Hide the video player if we're not on the video page
                $('#page-video').removeClass('shown');
                $('body').removeClass('video-page');
                if (window.turnerVideo) {
                    try {
                        // console.log(window.turnerVideo.player.isPaused());
                        // if the player is already paused we do not want/need to pause it again
                        // and send the analytics event
                        // This won't always happen because when Tn.currentPage changes occur ( above ), onContentPlayhead will pause it.
                        if (window.turnerVideo.player && !window.turnerVideo.player.isPaused()) {
                            if (Tn.videoType === 'live') { // Live doesn't actually pause.  The stream keeps going.  It has to be stopped ( pauseLive ).
                                turnerVideo.pauseLive();
                            } else {
                                window.turnerVideo.pause();
                            }
                        }

                        // for clips, we are no longer storing as currentVideo
                        // if we are watching a clip and navigate away, the last fullEp (show or movie) is cued in the playbar
                        // if the player is not stopped first, the clip we just navigated away from will play
                        // so we stop it here, and showDefaultVideo handles playing the last saved current video
                        // this is similar to what we are doing for live tv
                        if (window.turnerVideo.player && Tn.videoType === 'clip'){
                            turnerVideo.stopClipPlayer();
                        }
                        // If we left the video page in a ad then we need to reset the scrubber
                        window.turnerVideo.restoreState(Tn.Users.getPref('currentVideo'));
                    } catch (e) {
                        console.error("Error pausing video", e.message);
                    }
                }
            }

            // Check to see if we're on the video player page
            if (pageId === 'page-youtube-video') {
                $('#page-youtube-video').addClass('shown');
            } else if ($('#page-youtube-video').hasClass('shown')) {
                // Hide the video player if we're not on the video page
                $('#page-youtube-video').removeClass('shown');
                $('body').removeClass('video-page');
                if (window.ytVideo) {
                    window.ytVideo.pausePlayer();

                }
            }

            if (pageId === 'page-video') {
                $('body').attr('id', 'video-page');
            } else if (pageId === 'page-shows') {
                $('body').attr('id', 'shows-page');
            } else if (pageId === 'page-shows-list') {
                $('body').attr('id', 'shows-page-list');
            } else if (pageId === 'page-schedule') {
                $('body').attr('id', 'schedule-page');
            } else if (pageId === 'page-schedule-list') {
                $('body').attr('id', 'schedule-page-list');
            } else if (pageId === 'page-livetv') {
                $('body').attr('id', 'livetv-page');
            } else if (pageId === 'page-movies') {
                $('body').attr('id', 'movies-page');
            } else if (pageId === 'page-landing') {
                $('body').attr('id', 'landing-page');
            } else if (pageId === 'page-search') {
                $('body').attr('id', 'search-page');
            } else if (pageId === 'page-embed360-video') {
                $('body').attr('id', 'embed360-video-page');
            } else if (pageId === 'page-youtube-video') {
                $('body').attr('id', 'youtube-video-page');
            } else if (pageId === 'page-error') {
                $('body').attr('id', 'error-page');
            } else {
                $('body').attr('id', '');
            }

            Tn.scrollToAnchor();

            if (typeof(Tn.mobileDialogReturn) === 'undefined') {
                Tn.setMobileDialogReturn();
            }

            if(!isMobile){
                Tn.detectFlash();
            }
            


            // we are setting this in bottom.jsp after we make the jsmd.send call.
            // if we call it there, we do not want to call jsmd.send again when loading a modal or video when calling the page directly
            window.pageLoadAnalytics = false;

        },

        scrollToAnchor: function(anchorName){
            if(!anchorName){
                // get from query string
                anchorName = Tn.gup('anchor');
            }
            if(anchorName){
                $('[name="' + anchorName + '"]')[0].scrollIntoView();
            }
        },

        profileerror: function(msg, skipClear) {
            console.log(msg);
            if (!skipClear) {
                window.toastr.clear();
            }

            msg = (typeof(msg) === 'string' && msg.length > 1) ? msg : "We experienced a problem with your profile. Please try again.";

            window.toastr.options.onclick = undefined;
            $.extend(window.toastr.options, {
                "closeButton": true,
                "timeOut": "5000",
                "extendedTimeOut": "5000"
            });
            window.toastr.warning(msg);
        },

        success: function(msg) {
            console.log(msg);
            window.toastr.clear();

            window.toastr.options.onclick = undefined;
            $.extend(window.toastr.options, {
                "closeButton": true,
                "timeOut": "5000",
                "extendedTimeOut": "5000"
            });

            window.toastr.success(msg);
        },

        confirm: function(msg, callback) {
            console.log(msg);
            window.toastr.clear();

            window.toastr.options.onclick = callback;
            $.extend(window.toastr.options, {
                "closeButton": true,
                "timeOut": "15000",
                "extendedTimeOut": "5000"
            });

            window.toastr.info(msg);
        },

        legalMessage: function(msg, options) {
            console.error(msg);
            window.toastr.clear();

            window.toastr.options = {
                "closeButton": true,
                "timeOut": "3000000",
                "extendedTimeOut": "3000000"
            };
            $.extend(window.toastr.options, options || {});

            window.toastr.error(msg);
        },

        tvealert: function(msg) {
            console.error(msg);
            msg = "We experienced a problem with your TV Provider information. Please refresh or try again.";
            window.toastr.clear();

            window.toastr.options = {
                "closeButton": true,
                "timeOut": "3000000",
                "extendedTimeOut": "3000000"
            };

            window.toastr.options.onclick = function() {
                window.location.reload();
            };

            window.toastr.error(msg);
        },

        authalert: function(msg) {
            console.error(msg);
            window.toastr.clear();

            window.toastr.options = {
                "closeButton": true,
                "timeOut": "5000",
                "extendedTimeOut": "5000"
            };

            window.toastr.error(msg);
        },


        alert: function(msg, doReload) {
            console.error(msg);

            if (msg === 'blackoutMsg') {
                msg = "This game is not available in your area.";
            } else if (msg === 'blackoutTechIssue') {
                msg = "We are experiencing technical difficulties. Please try again later.";
            } else {
                msg = "We experienced a problem loading your content. Please refresh or try again.";
            }

            window.toastr.clear();

            window.toastr.options = {
                "closeButton": true,
                "timeOut": "3000000",
                "extendedTimeOut": "3000000"
            };

            if (doReload) {
                window.toastr.options.onclick = function() {
                    window.location.reload();
                };
            } else {
                window.toastr.options.onclick = undefined;
                $.extend(window.toastr.options, {
                    "closeButton": true,
                    "timeOut": "5000",
                    "extendedTimeOut": "5000"
                });
                window.toastr.warning(msg);
                return;
            }

            window.toastr.error(msg);
        },

        showPjaxSplash: function(shown) {
            var splash = $('#pjax-splash');
            if (shown) {
                // if (Tn.currentPage === 'page-video' || Tn.startedOnVideoPage) {
                //     return;
                // }
                if (splash.length === 0) {
                    splash = $('<div id="pjax-splash"></div>');
                    splash.insertBefore('footer');
                }
                splash.show();
                return;
            }
            splash.hide();
        },

        launchProtocol: function(url) {
            var launcher = $('#protocol-launcher');
            if (launcher.length === 0) {
                launcher = $('body').append('<iframe src="' + url + '" style="position: fixed; margin-left: -100000px;"></iframe>');
            } else {
                launcher.attr('src', url);
            }
        },

        parseHistoryPage: function(url, data) {

            // Hide our dialogs if page changes
            $('#profile-dialog').modal('hide');
            Tn.Users.cancelLogin();

            //console.error("SETTING URL:", url);
            window.currentPageUrl = url;
            var pageId = data.pageId;
            $('body').toggleClass('page-modal', data.isModal ? true : false);

            //Added for TENDP-12187 and deeplinking to apps
            tnVars.videoTitleId = '';
            tnVars.franchiseId = '';
            turnerVideo.stopAdPlayheadWorkAroundTimer();
            if (pageId === 'page-video' && typeof(url) == "string") {
                if (Tn.firstAuth) {
                    Tn.firstAuthVideoUrl = url;
                } else {
                    Tn.showPlayerInternal(url);
                }
            } else {
                window.turnerVideoPageObj.stopAdInTrayReloader();
                if (data.isModal) {
                    Tn.showInfoPage(url, pageId || "page-unknown");
                } else {
                    Tn.showPage(pageId || "page-unknown", url);
                }
            }
            //console.error("isModal", data.isModal);
        },

        getPageTitleFromData: function(data) {
            var title = "Shows";
            try {
                title = data.match(/<title[^>]*>([\s\S.]*)<\/title>/i)[1];
            } catch (e) {

                // In case we get a rare page without a title
                console.error("getPageTitleFromData", e.message);
            }
            return title;
        },

        showDefaultVideoFromShowsCB: function(data) {
            Tn.showPjaxSplash(false);
            if (Tn.showData) { // With all the deferred ajax shows pages, this may now be defined when it runs
                Tn.showDefaultVideoFromShowsCB2();
            } else if (typeof data === 'string') {
                data = $.parseHTML("<div>" + data.match(/<body[^>]*>([\s\S.]*)<\/body>/i)[0] + "</div>", document, false);
                var page = $(data).find('#page-shows .carousel'),
                    url = '';
                Tn.showData = {
                    carousels: [],
                    rowHdr: []
                };
                Tn.parseShowCarousel(page, Tn.showData.carousels, Tn.showData.rowHdr);

                Tn.showDefaultVideoFromShowsCB2();
            } else {
                Tn.alert("No default video available");
            }
        },
        showDefaultVideoFromShowsCB2: function(data) {
            var url = '';
            Tn.showPjaxSplash(false);
            if (Tn.showData && $.isArray(Tn.showData.carousels)) {
                out: for (var i = 0; i < Tn.showData.carousels.length; i++) {
                    var carouselItems = Tn.showData.carousels[i];
                    for (var j = 0; j < carouselItems.length; j++) {
                        if (carouselItems[i].playable) {
                            url = carouselItems[i].videoLink;
                            if (url.length > 0) {
                                break out;
                            }
                        }
                    }
                }
                if (url.length > 0) {
                    Tn.showPlayer(url);
                } else {
                    Tn.alert("No valid video found");
                }
            } else {
                Tn.alert("No default video available");
            }
        },
        // Temporarily grab the shows carousel and pull the first video from there
        showDefaultVideo: function() {
            if (window.turnerVideo.savedState && window.turnerVideo.savedState.url) {
                var index = window.turnerVideo.savedState.url.indexOf('/videos');

                // For dev purposes, strip out the hosts so that the videos can be shared across domains
                if (index >= 0) {
                    Tn.showPlayer(window.turnerVideo.savedState.url.substring(index));
                } else {
                    Tn.showPlayer(window.turnerVideo.savedState.url);
                }
                return;
            }

            // Use a featured video if no video found in user profile
            Tn.getFeaturedVideos(function(videos) {
                if (videos.length > 0) {
                    console.error("Playing default video", videos[0]);
                    Tn.showPlayer(videos[0].prettyVideoUrl);
                    return;
                }

                // If no featured videos found, then pull from the shows page
                if (Tn.showData) {
                    Tn.showDefaultVideoFromShowsCB2();
                } else if (tnVars.jqXHR[tnVars.pageId4Cache]) {
                    // We only need to call the /shows/ page once.
                    tnVars.jqXHR[tnVars.pageId4Cache].done(
                        Tn.showDefaultVideoFromShowsCB
                    ).always(function() {
                        Tn.showPjaxSplash(false);
                    });
                } else {
                    Tn.showPjaxSplash(true);
                    tnVars.jqXHR[tnVars.pageId4Cache] = $.ajax({
                        url: "/shows/",
                        dataType: 'text'
                    }).done(
                        Tn.showDefaultVideoFromShowsCB
                    ).fail(function() {
                        Tn.alert("Failed to load page<br>" + url);
                    }).always(function() {
                        Tn.showPjaxSplash(false);
                    });
                }
            });
        },

        parseAnalytics: function(meta, isModal) {
            if (!meta) {
                return;
            }

            // If analytics didn't get initialized properly, then skip
            if (!window._jsmd) {
                return;
            }
            //console.error("Sending analytics", window.currentPageUrl, meta);
            window.turner_metadata = meta;
            if (isModal) {
                window.turner_metadata.content_type = "other:overlay";
            }

            var pageURL = window.currentPageUrl;

            // we do want the video pause event sent even if the auth has failed
            // in the situation where auth failed and then history.back, the unauth video is playing again
            // but tnVars.pageStateChanges.authFail = true
            var isVideoContinue = meta.friendly_name === 'video continue watching' ? true : false;
            // Don't send() if we are 'History.back' here because of a authentication fail
            // issue....if auth has failed, we do want to send the video continue call, just not the page load call
            if (pageURL.indexOf("/.element/ssi/ads.iframes/") === -1 &&
                pageURL.indexOf("/doubleclick/dartiframe.html") === -1 &&
                (!tnVars.pageStateChanges.authFail || (tnVars.pageStateChanges.authFail && isVideoContinue)) && !window.pageLoadAnalytics) {
                //var jsmd = window._jsmd.init();
                //jsmd.send();
                try {
                    var jsmd = window._jsmd.init();
                    jsmd.send();
                } catch (e) {
                    console.log("jsmd did not init or send correctly");
                    console.log(e);
                }
            }
        },

        parseRawAnalytics: function(data, isModal, defer) {
            var match = data.match(/var turner_metadata = {([\s\S.]*?)}/i);
            if (!match || match.length !== 2) {
                return;
            }
            var meta = $.parseJSON('{' + match[1] + '}');
            if (!defer) {
                Tn.parseAnalytics(meta, isModal);
            }
            return $.extend({}, meta);
        },

        setFallbackPage: function() {
            if (!Tn.fallbackInfoPage) {
                return;
            }
            setTimeout(function() {
                if (!Tn.fallbackInfoPage) {
                    return;
                }
                // Special case for live TV
                // TODO : Pick a generic method which will work for TBS and other sites
                if (Tn.fallbackInfoPage.toLowerCase().indexOf('/watch') >= 0) {
                    Tn.setUrl(Tn.fallbackInfoPage, false, 'page-livetv');
                } else {
                    Tn.setUrl(Tn.fallbackInfoPage, true, 'page-generic');
                }
                delete Tn.fallbackInfoPage;
            }, 100);
        },

        showPageDoneCB: function(data, pageId, url) {
            var meta = Tn.parseRawAnalytics(data);

            if (!Tn.titles[pageId]) {
                Tn.titles[pageId] = {
                    title: Tn.getPageTitleFromData(data),
                    meta: meta
                };
            }
            window.document.title = Tn.titles[pageId].title;

            data = $.parseHTML("<div>" + data.match(/<body[^>]*>([\s\S.]*)<\/body>/i)[0] + "</div>", document, false);
            //console.error(video.length, $(data).find('#page-video'));
            var page = $(data).find('#' + pageId);
            if (page.length === 0) {
                Tn.alert("Page not found<br>" + url);
            } else {
                //Tn.setUrl(url, false, pageId);
                page.insertAfter('header');
                Tn.finalizePage(pageId, url);
            }
        },

        showPage: function(pageId, url) {

            if ($('#' + pageId).length === 0 && url) {
                Tn.showPjaxSplash(true);
                if (pageId === tnVars.pageId4Cache) {
                    if (tnVars.jqXHR[pageId]) { // Ajax call made someplace else
                        tnVars.jqXHR[pageId].done(
                            function(data) {
                                Tn.showPageDoneCB(data, pageId, url);
                            }
                        ).always(function() {
                            Tn.showPjaxSplash(false);
                        });
                    } else {
                        tnVars.jqXHR[pageId] = $.ajax({
                            url: url,
                            dataType: 'text'
                        }).done(
                            function(data) {
                                Tn.showPageDoneCB(data, pageId, url);
                            }
                        ).fail(function() {
                            Tn.alert("Failed to load page<br>" + url);
                        }).always(function() {
                            Tn.showPjaxSplash(false);
                        });
                    }
                } else { // only caching the /shows/ page
                    $.ajax({
                        url: url,
                        dataType: 'text'
                    }).done(
                        function(data) {
                            Tn.showPageDoneCB(data, pageId, url);
                        }
                    ).fail(function() {
                        Tn.alert("Failed to load page<br>" + url);
                    }).always(function() {
                        Tn.showPjaxSplash(false);
                    });
                }
            } else if (pageId === 'page-generic' && !HistoryHelper.isCurrentPageModal && HistoryHelper.wasPrevPageModal && url) {
                // this else statement is to catch the case where a modal page (learn more) loads into the browser as a non-modal page
                // since the page-id is page-generic; going back and forth from the non-modal to modal (info) and back
                // the $('#' + pageId).length === 0 prevented the learn more page from reloading the content
                // so, if the current page is not a modal
                // and, the prev page was a modal
                // and, the pageId = page-generic
                // and, the url is passed in (showInfoPage does not pass in the url)
                // we want to go to showinfopage to get page-generic reloaded with the right content
                Tn.showInfoPage(url, pageId, true);
            } else {
                // if (url) {
                //     Tn.setUrl(url, false, pageId);
                // }
                if (Tn.titles[pageId] && pageId === 'page-youtube-video') {
                    window.document.title = Tn.titles[pageId].title;
                    // analytics for new YT video is sent in ytPlayer.js
                } else if (Tn.titles[pageId] && pageId !== 'page-video') {
                    window.document.title = Tn.titles[pageId].title;
                    Tn.parseAnalytics(Tn.titles[pageId].meta, false);
                } else if (pageId !== 'page-generic' && window.turner_metadata) {
                    Tn.titles[pageId] = {
                        title: window.document.title,
                        meta: $.extend({}, window.turner_metadata)
                    };
                }
                Tn.finalizePage(pageId, url);
            }
        },

        showPlayer: function(url) {
            //Tn.showPage('page-video');
            //Tn.updateActiveNavLink('page-video');
            this.lastPageUrl = window.currentPageUrl;
            var pageId = 'page-video';
            var pattern360 = new RegExp('\/videos\/.*/360\/.*');
            var patternYoutube = new RegExp('\/videos\/.*/youtube\/.*');
            if (pattern360.test(url)) {
                // match found
                pageId = 'page-embed360-video';
            } else if (patternYoutube.test(url)) {
                pageId = 'page-youtube-video';
            }
            Tn.setUrl(url, false, pageId);
        },
        /**
         * [showPlayerInternal description]
         * @param  {[type]} url            [url of the video page to be loaded]
         * @param  {[type]} deferAnalytics [analytics does not want the page call event26 for live tv when the stream changes shows]
         * @return {[type]}                [description]
         */
        showPlayerInternal: function(url, deferAnalytics) {
            if (!url || url.length === 0) {
                Tn.alert("No video url specified");
                return;
            }
            deferAnalytics = typeof(deferAnalytics) === 'undefined' ? false : deferAnalytics;

            var isSameVideoAsLastTime = (Tn.lastVideoUrl && (Tn.lastVideoUrl.indexOf(url) > -1 || url.indexOf(Tn.lastVideoUrl) > -1));
            
            // jhillmann - we have to see if featured video was the last video played.
            // since we removed the clips from the video history and global playbar, if a clip is in tbe global playbar
            // it was not reloading since we stop the player for clips
            if (isSameVideoAsLastTime && Tn.videoType !== 'live' && Tn.videoType !== 'clip'){
                Tn.showPage('page-video');
                $('#page-video').addClass('shown');
                $('body').addClass('video-page');
                Tn.updateActiveNavLink('page-video');
                window.turnerVideo.play();
                if (Tn.lastVideoAnalytics) {
                    window.turner_metadata = Tn.lastVideoAnalytics;
                }
                window.turnerVideo.replaySameVideo();
                return;
            } else if (Tn.lastVideoUrl && !isSameVideoAsLastTime) { // A new video url so reset onContentError strategy and not a refresh
                var name4ContentErrorTime = window.turnerVideoPageObj.name4ContentErrorTime;
                Tn.localStorageWrapper.removeItem(name4ContentErrorTime);
                window.turnerVideoPageObj.resetBackGroundSkin();
            }
            Tn.series4VideoPlaying = false;
            Tn.sponsoredNextSeries4VideoPlaying = false;
            Tn.videoPlayingIsSponsored = false;

            window.turnerVideo.showSplash();
            if (Tn.currentPage.length !== 0 && Tn.currentPage !== "page-video") {
                Tn.showPjaxSplash(true);
            }
             
            window.turnerVideo.updateTitle('', '', '', 0, 'loading', 0, "Your video is loading.");
            $.ajax({
                url: url,
                dataType: 'text'
            }).always(function(data) {
                Tn.showPjaxSplash(false);
                
                if (typeof data === 'string') {
                    var noAuth, titleId, clipId, dataType, vidpage, aPlaylistSeriesMatch, durationSeconds, theImage,
                        video = $('#page-video'),
                        dataAsString = data;
                    data = $.parseHTML("<div>" + data.match(/<body[^>]*>([\s\S.]*)<\/body>/i)[0] + "</div>", document, false);
                    vidpage = $(data).find('#page-video');
                    Tn.fallbackInfoPage = vidpage.attr("infopage");
                    Tn.videosAssociatedInfoPage = Tn.fallbackInfoPage;
                    Tn.sponsoredNextSeries4VideoPlaying = vidpage.attr("sponsoredNext");
                    if (typeof(Tn.sponsoredNextSeries4VideoPlaying) === 'string') {
                        Tn.sponsoredNextSeries4VideoPlaying = Tn.sponsoredNextSeries4VideoPlaying.toLowerCase();
                    }
                    Tn.videoPlayingIsSponsored = (Tn.sponsoredNextSeries4VideoPlaying && Tn.sponsoredNextSeries4VideoPlaying.length > 0) ? true : false;

                    aPlaylistSeriesMatch = url.match('/videos/([^/]*)/');
                    if (aPlaylistSeriesMatch && typeof(aPlaylistSeriesMatch) === 'object' && aPlaylistSeriesMatch.length > 0) {
                        playlistSeriesName = aPlaylistSeriesMatch[1];
                        Tn.series4VideoPlaying = playlistSeriesName;
                    } else {
                        Tn.series4VideoPlaying = false;
                    }
                    //turner_metadata.series_name

                    // No auth will only get set if we explicitly say it is false.
                    noAuth = vidpage.attr("isAuthRequired") === "false" ? true : false;

                    //Added for TENDP-12187 and deeplinking to apps
                    tnVars.videoTitleId = vidpage.attr("titleid");
                    tnVars.franchiseId = vidpage.attr("franchiseId");

                    //Return/go back portion for unauthenticated users
                    if (!noAuth && !Tn.Auth.authenticated) {
                        Tn.Auth.getAuthentication(url);
                        if (Tn.lastPageUrl && !tnVars.pageStateChanges.watchOnAppModalShown) {
                            delete Tn.fallbackInfoPage;
                            setTimeout(function() {
                                tnVars.pageStateChanges.authFail = true;
                                History.back();
                                //Tn.setUrl(this.lastPageUrl);
                                delete Tn.lastPageUrl;
                            }, 100);
                        }
                        return;
                    }

                    // for a live stream, if a user is viewing during the show change, analytics does not want 
                    // a page call TENDP-12158
                    // i am not going to set the lastVideoAnalytics here since we are not sending the call
                    // but if there are issues take a look at this.
                    if(!deferAnalytics){
                        Tn.lastVideoAnalytics = Tn.parseRawAnalytics(dataAsString, false);
                        if (Tn.lastVideoAnalytics) {
                            window.turner_metadata = Tn.lastVideoAnalytics;
                        }
                    }
                    
                    window.document.title = Tn.getPageTitleFromData(dataAsString);

                    // Copy the new pages attribute over onto out existing page
                    var attributes = vidpage.prop("attributes");
                    $.each(attributes, function() {
                        // We don't care about resetting the class or the mode
                        if (this.name === 'class' || this.name === 'mode') {
                            return;
                        }
                        video.attr(this.name, this.value);
                    });

                    // Set the arktanid before the page gets shown
                    Tn.arkTanId = vidpage.attr("arktanStreamId");
                    titleId = vidpage.attr("titleid");
                    clipId = vidpage.attr("clipId");
                    theImage = vidpage.attr("image");
                    durationSeconds = vidpage.attr("durationSeconds");
                    Tn.videoType = vidpage.attr("type");
                    dataType = $(vidpage).find('#pane-info > div[data-type]').data('type');
                    if (video.length === 0) {
                        vidpage.insertAfter('header');

                        // Initialize the resizers if this is the first time the video is added to the page
                        window.turnerVideoPageObj.init();
                        video = $('#page-video');
                    } else {
                        video.find('#pane-info').html(vidpage.find('#pane-info').html());
                        video.find('#paused-sharebar').html(vidpage.find('#paused-sharebar').html());
                        video.find('#pane-share').html(vidpage.find('#pane-share').html());
                    }
                    // episode and clips have arktan id's and social tabs.
                    if (Tn.arkTanId) {
                        video.find('aside #arktan-comments').show();
                        //video.find('#pane-share').show();

                    } else {
                        video.find('aside #arktan-comments').hide();
                        //video.find('#pane-share').hide();
                    }
                    if ($(window).width() <= 600) {
                        window.turnerVideo.closeRailHelper();
                    }
                    
                    Tn.showPage('page-video');

                    // Update the server generated hours:min:sec to say minutes
                    // TODO: Do we need the extra work here now that we have durationSeconds
                    $('#pane-info .metainfo .duration, #pane-info .metainfo .movieduration').each(function() {
                        var hms = $(this).text().split(':');
                        var duration = 0;
                        // this converts the duration to seconds
                        if (hms.length === 1) {
                            duration = parseFloat(hms[0]);
                        } else if (hms.length === 2) {
                            duration = parseInt(hms[0], 10) * 60 + parseFloat(hms[1]);
                        } else if (hms.length === 3) {
                            duration = parseInt(hms[0], 10) * 60 * 60 + parseInt(hms[1], 10) * 60 + parseFloat(hms[2]);
                        }

                        //duration = window.turnerVideo.toHHMMSS(duration, true);
                        //all the duration display is now going through Tn.formatDuration excpet durations within turnerVideo
                        duration = Tn.formatDuration(duration);
                        $(this).text(duration);

                    });
                    if (refreshLiveStreamData !== true) {
                        if ((typeof(titleId) === 'undefined' || titleId.length === 0) && (typeof(clipId) === 'undefined' || clipId.length === 0)) {
                            Tn.alert("Video not found on server page<br>" + url);
                        } else {
                            window.turnerVideo.load({
                                // 'site': 'tnt',
                                // 'profile': '0',
                                // 'context': 'main',
                                // 'fullEpId': parseInt(titleId, 10),

                                'site': window.siteDefaults.name.toLowerCase(),
                                'profile': '0',
                                'context': 'fw_watchlive',
                                'videoType': Tn.videoType,
                                'fullEpId': parseInt(titleId, 10),
                                'clipId': parseInt(clipId, 10),
                                'theImage': theImage,
                                'durationSeconds': durationSeconds
                            });
                        }
                    } else {
                        window.turnerVideo.play(); // Moving code to this locatop
                    }
                } else {
                    Tn.showPage('page-video');
                    Tn.alert("Video not found on server<br>" + url);
                }
                if (tnVars.pageStateChanges.watchOnAppModalShown !== true) {
                    Tn.lastVideoUrl = url; // This was causing mobile to play the video if video clicked from its info page so make sure not in overlay
                }
                $('#page-video').addClass('shown');
                $('body').addClass('video-page');
                Tn.updateActiveNavLink('page-video');

                $('#page-video').show().trigger('pageshow');
                $('body').trigger('pageshown', 'page-video');

                window.refreshLiveStreamData = false;
            });
        },

        showInfoPage: function(url, pageId) {
            // Search is a special case where we want the data to remain, but still keep the modal state
            if (pageId === 'page-search' && $('#page-search').length > 0) {
                Tn.showPage(pageId);
                return;
            }

            Tn.showPjaxSplash(true);
            $.ajax({
                url: url,
                dataType: 'text'
            }).always(function() {
                Tn.showPjaxSplash(false);
            }).fail(function() {
                Tn.alert("Page not found<br>" + url);
            }).success(function(data) {
                Tn.parseRawAnalytics(data, true);
                window.document.title = Tn.getPageTitleFromData(data);

                var newData, page = $('#' + pageId);
                data = $.parseHTML("<div>" + data.match(/<body[^>]*>([\s\S.]*)<\/body>/i)[0] + "</div>", document, false);

                if (page.length === 0) {
                    page = $('<div class="page" id="' + pageId + '"></div>');
                    page.insertAfter($('header').parent().children(':last'));
                }

                // Check to see if we have a DIV with out page ID
                newData = $(data).find('#' + pageId);

                // If no DIV found, then look for the first page we can find
                if (newData.length === 0) {
                    newData = $(data).find('.page');
                }

                // We have to have a page
                if (newData.length === 0) {
                    Tn.alert("No page pulled in<br>" + url);
                } else {
                    // Update the new content for this page
                    page.html(newData.html());
                    // adding loading onto episode-info
                    page.find(':first-child').addClass('loading');
                }

                Tn.showPage(pageId);
            });
        },

        setUrl: function(url, isModal, pageId) {
            Tn.stateFrozen = true;
            tnVars.pageStateChanges.authFail = false; // Reset on click.  Initially set true on history.back (when Auth is being set) so ads don't reload
            // from the search results, the sport pages have a url of /shows/sportname.html
            // redir.conf has been updated for outside urls, but we need to 'fix' the url within the webapp as well
            // without this check, the correct page was pulling up (due to the redir.conf rule); but the url was not displaying
            // correctly in the location bar
            if (url === '/shows/mlb.html' ||
                url === '/shows/nba-on-tnt.html' ||
                url === '/shows/pga-on-tnt.html') {
                url = url.replace('/shows/', '/sports/');
            }
            //History.pushState(null, null, url);
            HistoryHelper.changeStateHelper({
                "nextPageUrl": url,
                "isModalLinkClick": isModal,
                "pageId": pageId
            });
            Tn.stateFrozen = false;
        },

        /**
         * Returns the featured videos JSON object
         */
        getFeaturedVideos: function(cb, showSplash) {
            if (Tn.featuredVideosData && Tn.featuredVideosData.length > 0) {
                cb(Tn.featuredVideosData);
                return;
            }

            if (showSplash) {
                Tn.showPjaxSplash(true);
            }

            $.getJSON('/service/featureVideos.json').done(function(data) {
                if (!data || !data.featuredItems || data.featuredItems.length <= 0) {
                    Tn.featuredVideosData = [];
                } else {
                    Tn.featuredVideosData = data.featuredItems;
                }
                cb(Tn.featuredVideosData);
            }).fail(function() {
                console.error("getFeaturedVideos::failed to load featured videos");
            }).always(function() {
                if (showSplash) {
                    Tn.showPjaxSplash(false);
                }
            });
        },

        getPageCarousel: function() {
            var page = $('#' + Tn.currentPage);
            if (page.hasClass('pagecarousel')) {
                return page;
            }
            return null;
        },

        updateCommentsHeight: function(height) {
            $('#arktan-comments iframe').height(height);
        },

        showComments: function(arktanStreamId) {
            $('#arktan-comments').empty();
            if (!arktanStreamId || arktanStreamId.length === 0) {
                return;
            }
            document.domain = document.domain;
            $('#arktan-comments').append('<iframe src="/includes/comments.html?id=' + arktanStreamId + '&domain=' + document.domain + '" style="width:100%;border:0;"></iframe>');
        },
        localStorageWrapper: {
            // Trying to handle exceptions with the normal localStorage API when in private browsing
            getItem: function(key) {
                try {
                    return window.localStorage.getItem(key);
                } catch (e) {
                    return false;
                }
            },
            setItem: function(key, value) {
                // in case of Quota issues
                try {
                    window.localStorage.setItem(key, value);
                } catch (e) {
                    return false;
                }
            },
            removeItem: function(key) {
                try {
                    window.localStorage.removeItem(key);
                } catch (e) {
                    return false;
                }
            }
        }
    });

    /**
     * @class Tn.Auth
     * Takes care of authorization routines
     */

    function createAuth(options) {

        Tn.Auth = {
            clientId: window.siteDefaults.name,
            vendorEnv: authVendorEnvId,
            configEnv: authConfigEnvId,
            authReady: false,
            authBool: false,
            authenticated: false
        };

        window.tntAuth = Tn.Auth;

        $.extend(Tn.Auth, options, {
            /**
             * Gets the authentication for the method
             * @param  {String} redirUrl The URL to redirect to
             */
            getAuthentication: function(redirUrl) {

                if (isMobile) {
                    if (typeof(Tn.mobileDialogReturn) === 'undefined') {
                        Tn.setMobileDialogReturn();
                    }
                    tnVars.pageStateChanges.watchOnAppModalShown = true;
                    $('#mobile-app-dialog').modal('show');
                    if($.cookie('rememberDeepLink')){
                        $('#mobile-app-dialog .download').trigger('click', {'autoClick': true}); //, #mobile-app-dialog .install'
                    }
                    return;
                }
                Tn.Auth.isChecking = true;

                if (redirUrl && redirUrl.charAt(0) === '/') {
                    redirUrl = window.location.protocol + "//" + window.location.host + redirUrl;
                }
                if (Tn.Auth.authReady) {
                    //console.log('getAuthentication');

                    if (!window.hasReportedPickerOpen) {
                        window.hasReportedPickerOpen = true;
                    }

                    CVP.AuthManager.on('pickerStateChange', function(state) {
                        //console.log(state.state);
                        if (state.state === "findbyname" && !window.hasReportedPickerList) {
                            window.hasReportedPickerList = true;
                            window.hasReportedPickerOpen = false;
                            window.hasReportedPickerNoProvider = false;
                        } else if (state.state === "noprovider" && !window.hasReportedPickerNoProvider) {
                            window.hasReportedPickerNoProvider = true;
                            window.hasReportedPickerList = false;
                            window.hasReportedPickerOpen = false;

                        } else if (!window.hasReportedPickerOpen) {
                            window.hasReportedPickerOpen = true;
                            window.hasReportedPickerNoProvider = false;
                            window.hasReportedPickerList = false;
                        }
                    });

                    $('#mvpdpicker .close').on('click', function(){
                        console.log('close the picker');
                    });
                    Tn.Auth.AUTH.getAuthentication(redirUrl);

                }
            },
            /**
             * Logs out of the current TVE session
             */
            logout: function() {
                if (Tn.Auth.authReady && Tn.Auth.authBool) {
                    // Analytics: Remove user cookies on logout
                    if (typeof(Storage) !== undefined) {
                        if (localStorage.getItem("pickerauth") === "yes") {
                            localStorage.removeItem("pickerauth");
                        }
                    }
                    console.log('logout');
                    Tn.Auth.AUTH.logout();
                }
            },

            /**
             * Starts a check for the authorization of the specified video
             * @param  {String} waitingVideo The video to be authorized
             */
            checkAuthorization: function() {
                if (Tn.Auth.authReady) {
                    if (Tn.Auth.authBool) {
                        //Tn.showPjaxSplash(true);

                        // Allow up to 15 seconds for the authorization to succeed, else reload the page
                        Tn.authorizationTimer = setTimeout(function() {
                            //Tn.showPjaxSplash(false);
                            Tn.tvealert("Authorization has not returned in 15 seconds.<br>It has most likely timed out.", true);
                        }, 15000);

                        Tn.Auth.AUTH.checkAuthorization(Tn.Auth.clientId);
                    } else {
                        Tn.Auth.AUTH.getAuthentication();
                    }
                }
            },

            /**
             * Initializes the auth
             */
            load: function() {
                Tn.Auth.AUTH = CVP.AuthManager.init({
                    clientId: Tn.Auth.clientId,
                    vendorEnv: Tn.Auth.vendorEnv,
                    configEnv: Tn.Auth.configEnv,
                    adobeSwfUrl: "/cvpconfigs/AccessEnablerLoader.swf", 
                    swfStyleOverride: {
                        height: 5,
                        width: 5,
                        style: "z-index: 500; position: fixed; left: 0px; top: 0px;"
                    },
                    onPickerHelpClicked: function() {
                        window.open('/help.html');
                        //Tn.setUrl('/help.html', true, 'page-generic');
                    },
                    onInitReady: function() {
                        //console.log('auth manager is ready');
                        Tn.Auth.authReady = true;
                        Tn.Auth.AUTH.isAuthenticated();
                    },
                    onAuthenticationPassed: function(mvpdId, mvpdConfig) {
                        Tn.Auth.authenticated = true;
                        Tn.Auth.authBool = true;
                        Tn.brandImage = '';
                        if (mvpdConfig && (typeof mvpdConfig.cobrand !== 'undefined') && (typeof(mvpdConfig.cobrand[0]) !== 'undefined')) {
                            Tn.brandImage = mvpdConfig.cobrand[0].url;
                        }
                        Tn.updateBrandImage();

                        // If we ever get into this bad state, just do a window refresh, which will make it go away.
                        // We risk an infinite refresh issue here, but technically speaking, this should never happen.
                        if (!mvpdConfig) {
                            window.location.reload();
                        }

                        Tn.Auth.authenticated = true;
                        if (Tn.Auth.onAuthorized) {
                            Tn.Auth.onAuthorized();
                        }
                    },
                    onAuthenticationFailed: function(msg) {
                        if (msg === 'Provider not Selected Error') {
                            Tn.Auth.isChecking = false;
                            Tn.setFallbackPage();
                            // else {
                            //     Tn.alert("Please select a provider to watch video.");
                            // }
                        }

                        if (Tn.Auth.isChecking && !Tn.firstAuth) {
                            Tn.setFallbackPage();
                            //Tn.alert("Authentication Failed!<br>" + msg, true);
                            console.error("Error", arguments);
                            //Tn.setUrl(Tn.currentPagePath, $('#'+Tn.currentPage).attr('modal') === '1' ? true : false, Tn.currentPage);
                        }

                        Tn.Auth.isChecking = false;
                        Tn.Auth.authenticated = false;
                        //console.log('authentication failed');
                        Tn.Auth.authBool = false;
                        Tn.brandImage = '';
                        Tn.updateBrandImage();
                        Tn.Auth.authenticated = false;
                        if (Tn.Auth.onFailedAuth) {
                            Tn.Auth.onFailedAuth();
                        }
                    },
                    onAuthorizationPassed: function() {
                        //Tn.showPjaxSplash(false);
                        if (Tn.authorizationTimer) {
                            clearTimeout(Tn.authorizationTimer);
                            delete Tn.authorizationTimer;
                        }
                        window.turnerVideo.playWithToken(Tn.Auth.AUTH.getAccessToken(null, null));
                    },
                    onAuthorizationFailed: function(resource, errorCode, errorString) {
                        //Tn.showPjaxSplash(false);
                        if (Tn.authorizationTimer) {
                            clearTimeout(Tn.authorizationTimer);
                            delete Tn.authorizationTimer;
                        }
                        Tn.authalert(errorString, true);
                    },
                    onTrackingData: function(trackingEventType, trackingData) {
                        switch (trackingEventType) {
                            case "authorizationDetection":
                                /*
                                 * [0] Whether the token request was successful
                                 * [true/false] and if true: [1] MVPD ID [string] [2]
                                 * User ID (md5 hashed) [string] [3] Whether it was
                                 * cached or not [true/false]
                                 */
                                // DEBUG
                                if (window.logAdobe === true) {
                                    console.log("onTrackingData | trackingEventType = " + trackingEventType + "; " + trackingData);
                                }
                                // populate Omniture Metrics
                                if (trackingData[0] === true) {
                                    // if cached == true
                                    if (trackingData[3] === true) {
                                        window.trackAlreadyLoggedInPage(trackingData);
                                    } else {
                                        // else just redirected back from authorization
                                        window.trackAuthenticationComplete(trackingData);
                                    }
                                } else {
                                    if (!window.hasSetFirstMetric) {
                                        // populate Omniture Metrics
                                        window.trackNotLoggedInPage();
                                        window.hasSetFirstMetric = true;
                                    }
                                }
                                break;
                            case "authenticationDetection":
                                /*
                                 * [0] Whether the token request was successful
                                 * [true/false] and if true: [1] MVPD ID [string] [2]
                                 * User ID (md5 hashed) [string] [3] Whether it was
                                 * cached or not [true/false]
                                 */
                                // populate Omniture Metrics
                                if (trackingData[0] === true) {
                                    window.fw_ae = trackingData[1];
                                    window.fw_ae = $.md5(window.fw_ae.toLowerCase());
                                    if (trackingData[3] === true) {
                                        window.trackAlreadyLoggedInPage(trackingData);
                                    } else {
                                        // else just redirected back from authorization
                                        window.trackAuthenticationComplete(trackingData);
                                    }
                                } else {
                                    if (!window.hasSetFirstMetric) {
                                        // populate Omniture Metrics
                                        window.trackNotLoggedInPage();
                                        window.hasSetFirstMetric = true;
                                    }
                                }
                                break;
                            case "mvpdSelection":
                                /* [0] MVPD ID */
                                window.trackAuthenticationStart(trackingData);
                                break;
                            default:
                                if (window.logAdobe === true) {
                                    console.log("trackingEventType = " + trackingEventType + "; " + trackingData);
                                }
                                break;
                        }
                        if (typeof window.onTrackingDataCallback === 'function') {
                            window.onTrackingDataCallback(trackingEventType, trackingData);
                        }
                    }
                });
            }
        });

        Tn.Auth.load();
        return Tn.Auth;
    }


    Tn.onReady(function() {

        $('body').addClass(window.siteDefaults.name.toLowerCase());
        if($.isArray(window.siteDefaults.pageConfigs)){
        	$.each( window.siteDefaults.pageConfigs, function( index, config ) {
        		var now = window.siteDefaults.serverTime,
        			canDoWork = true;
        		if(config.startTime && config.startTime > now ){
        			canDoWork = false;
        		}
        		if(config.endTime && config.endTime < now ){
        			canDoWork = false;
        		}
        		if (config.name && config.name === Tn.gup('name')){
        			canDoWork = true;
        		}
        		if(canDoWork && config.theSelector && config.addThisClass){
        			$(config.theSelector).addClass(config.addThisClass);
        		}
			});
        }
        logStartup('Creating Auth');

        // apps may pass in the hideChrome query since they have their own header/footer within theh app
        if(Tn.hideChrome){
            $('body').addClass('hideChrome');
        }  else {
            $('body').removeClass('hideChrome');
        }
        Tn.Auth = createAuth({
            onAuthorized: function() {
                if (Tn.firstAuth) {
                    Tn.firstAuth = false;

                    if (Tn.firstAuthVideoUrl) {
                        Tn.showPlayerInternal(Tn.firstAuthVideoUrl);
                    }
                    // var curVideo = Tn.gup('video');
                    // if (curVideo.length > 0) {
                    //     Tn.showPlayer();
                    // }
                    //window.turnerVideo.load();

                    // if (Tn.currentPage === 'page-video') {
                    //     Tn.showPlayer(window.location.href);
                    // }
                }
            },
            onFailedAuth: function() {
                // this is called when the first page loads
                if (Tn.firstAuth) {
                    Tn.firstAuth = false;
                    var authVideoId = $('#page-video').attr("titleid");
                    var noAuth = $('#page-video').attr("isAuthRequired") === "false" ? true : false;
                    Tn.fallbackInfoPage = $('#page-video').attr("infopage");
                    if (noAuth && authVideoId) {
                        Tn.showPlayerInternal(Tn.firstAuthVideoUrl);
                    } else if (typeof authVideoId !== "undefined" && authVideoId.length !== 0) {
                        setTimeout(function() {
                            if (isMobile) {
                                Tn.showPlayerInternal(Tn.firstAuthVideoUrl);
                            } else {
                                Tn.Auth.getAuthentication(window.currentPageUrl);
                            }
                        }, 10);
                    } else {
                        var clipId = $('#page-video').attr("clipId");
                        if (typeof clipId !== "undefined" && clipId.length !== 0) {
                            Tn.showPlayerInternal(Tn.firstAuthVideoUrl);
                        }
                    }
                } else {
                    // if it is not the firstAuth, we want to reset the History.closeModalData 
                    // the clicked video page is set as the close modal page on the play button click, but when the auth fails, it is not getting set back
                    // to the current page
                    // we were seeing issues when you close out of the picker then click an info page,
                    // the video page with the picker is being pulled up again and you can't break out of the loop
                    HistoryHelper.setDefaultCloseModalData();
                }
            }
        });

        logStartup('Binding click events');
        $(".signin-wrapper .mvpd-logged-out a").on("click", function(event) {
            event.preventDefault();
            Tn.Auth.getAuthentication(window.currentPageUrl);
        });
        $(".mvpd-show-picker").on("click", function(event) {
            event.preventDefault();
            Tn.Auth.getAuthentication(window.currentPageUrl);
        });
        $(".mvpd-sign-out").on("click", function(event) {
            event.preventDefault();
            Tn.Auth.logout();
        });
        $(".signin-wrapper .mvpd-logged-in").on("click", function(event) {
            event.preventDefault();
            Tn.Auth.logout();
        });

        logStartup('Setting initial page');
        // Initialize the default page
        // This will affect whether the header and footer will appear on the video page when video is playing.
        if (isMobile) {
            $('body').addClass('is-mobile');
        }
        Tn.currentPage = $("body").attr('curpage') || '';
        if (Tn.currentPage.length === 0) {
            var pages = $(".page");
            if (pages.length > 0) {
                //var page = pages.get(0).id;
                var page;
                // for schedule there are 2 possible pages, page-schedule and page-schedule-list
                if (window.currentPageUrl.indexOf('/schedule/') !== -1) {
                    var thePlatform = window.tnVars.getPlatform();
                    if (tnVars.isPhone() || (thePlatform.match("^mobile tablet android 2.2"))) {
                        page = 'page-schedule-list';
                    } else if (window.currentPageUrl.indexOf('/list') !== -1) {
                        page = 'page-schedule-list';
                    } else {
                        page = 'page-schedule';
                    }
                } else if (window.currentPageUrl.indexOf('/shows/list') !== -1) {
                     page = 'page-shows-list';
                } else {
                    page = pages.get(0).id;
                }
                // TODO: The initial page still has an analytics issue
                /*                if (window.turner_metadata) {
                    // If we come onto a modal page, we can't do this otherwise it will find the modal pageId in the object
                    // We probably have to statically define which pages we want to default here
                    Tn.titles[pageId] = {
                        title: window.document.title,
                        meta: $.extend({}, window.turner_metadata);
                    };                    
                }*/

                HistoryHelper.init(false, page);
                Tn.parseHistoryPage(window.currentPageUrl, History.getState().data);
            } else {
                HistoryHelper.init(false, "page-unknown");
            }
        }

        

        logStartup('Binding page links');

        $('body').prepend('<a href="javascript:void(0)" id="focusHack"></a>');

        $('a[pageid], a[data-toggle]').on('click', function(event) {
            event.preventDefault();
            Tn.closeMenu();
            var $this = $(this);
            var pageId = $this.attr('pageId');
            if (!pageId) {
                return;
            }
            Tn.setUrl($(this).attr('href'), $this.attr('modal') === '1' ? true : false, pageId);
            return false;
        });

        //make schedule link default to list view for phones
        $('.navitem-schedule > div').on('click', function(e) {
            e.preventDefault();
            Tn.closeMenu();
            if (tnVars.isIPhone || tnVars.isIPod || tnVars.isWindows || (tnVars.isAndroid && !tnVars.isAndroidTablet())) {
                Tn.setUrl('/schedule/list.html', false, 'page-schedule-list');
            } else {
                Tn.setUrl('/schedule/', false, 'page-schedule');
            }
            return false;
        });

        // some android devices are erroring with this touchstart event
        // it is conflicting with the bootstrap function which is on the click
        // the touchstart makes the menu open faster, so we will apply it to ios and android chrome browser
        if (tnVars.isIOS() || tnVars.isAndroidChrome) {
            $('button.navbar-toggle').on('touchstart', function(event) {
                event.preventDefault();
                $(this).trigger('click');
            });
        }

        $('#navmain').on({
            'show.bs.collapse': function() {
                //console.log('show');
                window.tnVars.disableMenuWindowScroll();
            },
            'hide.bs.collapse': function() {
                //console.log('hide');
                window.tnVars.enableMenuWindowScroll();
            }
        });


        $('#legal a').on('click', function(event) {
            if (this.id === window.siteDefaults.name.toLowerCase() + '_adchoices') {
                return;
            } else {
                event.preventDefault();
                Tn.setUrl($(this).attr("href"), true, 'page-generic');

            }
        });

        $('#modal-back-btn').on('click', function(event) {
            event.preventDefault();
            // with new requirements we don't want the close button to go back 1
            // we want it to go to the last non-modal page the user was on
            if (History.closeModalData !== null) {
                var data = History.closeModalData;
                Tn.setUrl(data.myUrl, false, data.pageId);
            } else {
                History.back();
            }
        });

        $('.email-verify .email-verify-login').on('click', function() {
            event.preventDefault();
            var options = {};
            if ($(this).attr('data-start-screen')) {
                options.startScreen = $(this).attr('data-start-screen');
            }
            Tn.Users.logIn(options);
            Tn.setUrl('/', false, 'page-landing');
        });

        $.each(window.siteDefaults.feeds, function(key, value) {
            if (Tn.gup(key) !== "") {
                var gupVal = Tn.gup(key);
                gupVal = (gupVal === 'true') ? true : gupVal;
                gupVal = (gupVal === 'false') ? false : gupVal;
                window.siteDefaults.feeds[key] = gupVal;
                $.cookie(key, gupVal);
            } else if ($.cookie(key)) {
                var cookVal = $.cookie(key);
                cookVal = (cookVal === 'true') ? true : cookVal;
                cookVal = (cookVal === 'false') ? false : cookVal;
                window.siteDefaults.feeds[key] = cookVal;
            }
        });

        $('#mobile-app-dialog .download, #mobile-app-dialog .install').on("click", function(event, data) {
            var justInstall = ( $(this).hasClass('install'))?true:false,
                isAutoClick =(typeof(data) == 'object' && data.autoClick === true)?true:false,
                rememberedAction = $.cookie('rememberDeepLink');
            if(rememberedAction && !isAutoClick){
                if(justInstall){
                    $.cookie('rememberDeepLink', 'deepLinkInstall', {
                        expires: 14,
                        path: '/'
                    });
                } else {
                    $.cookie('rememberDeepLink', 'deepLink', {
                        expires: 14,
                        path: '/'
                    });
                }
            } else if(isAutoClick && rememberedAction){
                if(rememberedAction == 'deepLinkInstall'){
                    justInstall = true;
                } else if(rememberedAction == 'deepLink'){
                    justInstall = false;
                } else {
                    return; // They just checked the box and didn't click anything to remember.  Do not autoclick
                }
            }

            
            event.preventDefault();

            function deepLinkHelper(isDeepLinking, appProtocol, appStore) {
                //trutv2go://deeplink?section=video&collection=12345&title=123456&source=fanhattan&campaign=tve&auth= true

                var section = (Tn.videoType === 'live') ? 'livestream' : 'video',
                    collection = (tnVars.franchiseId && tnVars.franchiseId.length > 0) ? tnVars.franchiseId : '',
                    title = (tnVars.videoTitleId && tnVars.videoTitleId.length > 0) ? tnVars.videoTitleId : '',
                    source = 'web',
                    campaign = '',
                    auth = 'true',
                    collectionSnippet = (Tn.videoType === 'live') ? '' : '&collection=' + collection,
                    titleSnippet = (Tn.videoType === 'live') ? '' : '&title=' + title,
                    deepLinkPortionTmp = '?section=' + section + collectionSnippet + titleSnippet + '&source=' + source + '&campaign=' + campaign + '&auth=' + auth,
                    deepLinkPortionForApp = (isDeepLinking && appProtocol) ? deepLinkPortionTmp : '';

                setTimeout(function() {
                    window.location.href = appStore;
                }, 50);
                if (appProtocol && !justInstall) {
                    window.location.href = appProtocol + deepLinkPortionForApp;
                }
            }
            if (tnVars.isKindle) {
                window.location.href = window.siteDefaults.feeds.kindle;
                return;
            }

            if (tnVars.isAndroid) {
                if (tnVars.isAndroidTablet()) {
                    deepLinkHelper(window.siteDefaults.feeds.androidTabletDeepLinking, window.siteDefaults.feeds.androidTabletProtocol, window.siteDefaults.feeds.androidTabletStore);
                } else {
                    deepLinkHelper(window.siteDefaults.feeds.androidPhoneDeepLinking, window.siteDefaults.feeds.androidPhoneProtocol, window.siteDefaults.feeds.androidPhoneStore);
                }
                return;
            }

            if (tnVars.isIPad) {
                deepLinkHelper(window.siteDefaults.feeds.ipadDeepLinking, window.siteDefaults.feeds.ipadProtocol, window.siteDefaults.feeds.ipadStore);
                return;
            }

            if (tnVars.isIPhone) {
                deepLinkHelper(window.siteDefaults.feeds.iPhoneDeepLinking, window.siteDefaults.feeds.iphoneProtocol, window.siteDefaults.feeds.iphoneStore);
                return;
            }

            // Fallback message if we don't handle this mobile platform
            alert("Your platform is currently not supported.");
        });
        $('#mobile-app-dialog .check-it').on("click", function() {
            var $checkBoxWrapper = $(this);
            var isChecked = ( $checkBoxWrapper.find('input:checked').length )?true:false;
            if(isChecked){
                $checkBoxWrapper.find('.glyphicon-ok').hide();
                $checkBoxWrapper.find('input').removeAttr( 'checked' );
                $.removeCookie('rememberDeepLink', { path: '/' });

            } else {
                $checkBoxWrapper.find('.glyphicon-ok').show();
                $checkBoxWrapper.find('input').prop('checked', 'checked');
                $.cookie('rememberDeepLink', '1', {
                    expires: 14,
                    path: '/'
                });
            }
            event.preventDefault();
        });
        if($.cookie('rememberDeepLink')){
            var $checkBoxWrapper = $('#mobile-app-dialog .check-it');
            $checkBoxWrapper.find('.glyphicon-ok').show();
            $checkBoxWrapper.find('input').prop('checked', 'checked');
        }
        if(tnVars.isAndroid){
            // Need to turn on the install button for android via css
            $('#mobile-app-dialog').addClass('android');
        }

        $('.hide-watch-later').on({
            click: function() {
                //event.preventDefault();
                var checkbox = $('#hide-watch-later');
                checkbox.prop("checked", !checkbox.prop("checked"));
            }
        });

        $('#continue-watching-dialog .signin').click(function(event) {
            event.preventDefault();
            event.stopPropagation();
            var options = {};
            if ($(this).attr('data-start-screen')) {
                options.startScreen = $(this).attr('data-start-screen');
            }
            Tn.Users.logIn(options);
        });

        $('#continue-watching-dialog').on({
            "hidden.bs.modal": function() {
                var checkbox = $('#hide-watch-later');
                if (checkbox.prop('checked')) {
                    $.cookie('hidewatch', '1', {
                        expires: 365,
                        path: '/'
                    });
                } else {
                    $.removeCookie('hidewatch', {
                        path: '/'
                    });
                }
            }
        });

        $('#mobile-app-dialog .cancel').on({
            "click": function() {
                event.preventDefault();
                $('#mobile-app-dialog').modal('hide');
            }
        });

        $('#mobile-app-dialog').on({
            "shown.bs.modal": function() {
                tnVars.pageStateChanges.watchOnAppModalShown = true;
                Tn.pathWhereOpenedMobileAppDialog = typeof(Tn.currentPagePath) !== 'undefined' && Tn.currentPagePath !== '' ? Tn.currentPagePath : location.pathname;
            },
            "hidden.bs.modal": function() {
                tnVars.pageStateChanges.watchOnAppModalShown = false;
                //Tn.setFallbackPage();// Remove per Jake for history back below

                if (Tn.lastPageUrl) {
                    setTimeout(function() {
                        delete Tn.lastPageUrl;
                    }, 100);
                }
                Tn.setUrl(Tn.mobileDialogReturn.path, false, Tn.mobileDialogReturn.pageId);
            }
        });
        /* we are not showing the welcome screen anymore */
        /*
                $('#welcome-dialog .create').on({
                    "click": function(event) {
                        event.preventDefault();
                        $('#welcome-dialog').modal('hide');
                        Tn.Users.logIn();
                    }
                });

                $('#welcome-dialog .cancel').on({
                    "click": function(event) {
                        event.preventDefault();
                        $('#welcome-dialog').modal('hide');
                    }
                });
                $('#welcome-dialog .termslink').on({
                    "click": function(event) {
                        event.preventDefault();
                        $('#welcome-dialog').modal('hide');
                        Tn.setUrl("/terms.html", true, 'page-generic');
                    }
                });
                $('#welcome-dialog .privacylink').on({
                    "click": function(event) {
                        event.preventDefault();
                        $('#welcome-dialog').modal('hide');
                        Tn.setUrl("/privacy.html", true, 'page-generic');
                    }
                });

        */

        function registerUIEvents(turnerVideo) {
            var clickEventType = ((document.ontouchstart !== null) ? 'click' : 'touchstart');

            $('.play-but').on("click", function(event) {
                event.preventDefault();
                if ($(window).width() <= 600) {
                    window.turnerVideo.closeRailHelper();
                }
                turnerVideo.play();
            });

            $('#pause-but').on("click", function(event) {
                event.preventDefault();
                turnerVideo.pause();
            });
            Tn.playheadSlider = $('input#playhead-slider-input');
            Tn.playheadSlider.val(0);
            Tn.playheadSlider.simpleSlider({
                'theme': 'time',
                'highlight': true,
                'direction': 'horizontal',
                'id': 'playhead-slider'
            });

            // we dont' want turnerVideo.updateProgress to run when the slider is moving
            // we set Tn.sliderInProgress to true of false and in Player.js i test the variable is updateProgress()
            $('body').on('slider:begin', function(e, options){
                //console.log('slider:begin: ' + options.pageX);
                if(options.id === 'playhead-slider'){
                    Tn.sliderInProgress = true;
                }
            }).on('slider:end', function(e, options){
                //console.log('slider:end ' + options.pageX);
                if(options.id === 'playhead-slider'){
                    Tn.sliderInProgress = false;
                    // we are adding a little to make up for the size of the dragger
                    var pos = options.pageX - $('#time-slider').offset().left + 8;
                    var fullWidth = $('#time-slider').width();
                    if (pos > fullWidth) {
                        pos = fullWidth;
                    }
                    turnerVideo.seek(pos, fullWidth);
                }
            });
            /*
            $('#time-slider').on(clickEventType, function(e) {
                var pos = e.pageX - $(this).offset().left;
                console.log('click event: ' + pos);
                var fullWidth = $('#time-slider').width();
                if (pos > fullWidth) {
                    pos = fullWidth;
                }
                //turnerVideo.seek(pos, fullWidth);
            });
            */

            $('#quickSeekBack').on("click", function(event) {
                event.preventDefault();
                turnerVideo.quickSeekBack();
            });

            // init the volume slider using simple-slider.js
            var volumeSlider = $('input#video-volume-input');
            volumeSlider.val(Tn.volumeLevel);
            //console.log(volumeSlider.val());
            volumeSlider.simpleSlider({
                'theme': 'volume',
                'highlight': true
            });

            $('input#video-volume-input').on("slider:changed", function(event, data) {
                // The currently selected value of the slider
                // console.log('changed: ' + data.value);
                // set the user volume level
                Tn.volumeLevel = data.value;
                // call the turnerVideo.setVolume which calls player.setVolume()
                turnerVideo.setVolume(Tn.volumeLevel);
                if (Tn.volumeLevel === 0) {
                    $('#volume-but').html('<span class="glyphicon glyphicon-volume-off"></span>');
                } else {
                    $('#volume-but').html('<span class="glyphicon glyphicon-volume-up"></span>');
                }

            });
            if (!window.tnVars.isMobile()) {
                $('#video-volume-slider').on("mouseenter", function(event) {
                    event.preventDefault();
                    // show or hide the video toggle
                    $(this).find('.volume-slider-wrapper').fadeIn(200);
                }).on('mouseleave', function(event) {
                    event.preventDefault();
                    $(this).find('.volume-slider-wrapper').fadeOut(200);
                });
                $('#volume-but').on("click", function(event) {
                    event.preventDefault();
                    if (Tn.volumeLevel === 0) {
                        // we will unmute
                        // we used the saved volume
                        volumeSlider.simpleSlider("setValue", Tn.defaultVolumeLevel);
                        $('#volume-but').html('<span class="glyphicon glyphicon-volume-up"></span>');
                    } else {
                        // we will mute
                        // we save the existing volume so if a user unmutes we can go back to it
                        //Tn.savedVolumeLevel = Tn.volumeLevel;
                        Tn.defaultVolumeLevel = Tn.volumeLevel;
                        Tn.volumeLevel = 0;
                        volumeSlider.simpleSlider("setValue", Tn.volumeLevel);
                        $('#volume-but').html('<span class="glyphicon glyphicon-volume-off"></span>');
                    }
                });
            }

            $('#volume-but').on("touchend", function(event) {
                event.preventDefault();
                // show or hide the video toggle
                $('#video-volume-slider > .volume-slider-wrapper').toggle();
            });

            Mousetrap.bind(['up', 'w'], function() {
                var page = Tn.getPageCarousel();
                if (!page) {
                    return;
                }
                page.pageCarousel('up');
            });
            Mousetrap.bind(['down', 's'], function() {
                var page = Tn.getPageCarousel();
                if (!page) {
                    return;
                }
                page.pageCarousel('down');
            });
            Mousetrap.bind(['left', 'a'], function() {
                var page = Tn.getPageCarousel();
                if (!page) {
                    return;
                }
                page.pageCarousel('left');
            });
            Mousetrap.bind(['right', 'd'], function() {
                var page = Tn.getPageCarousel();
                if (!page) {
                    return;
                }
                page.pageCarousel('right');
            });
            Mousetrap.bind('esc', function() {
                if ($('body').hasClass('page-modal')) {
                    History.back();
                }
            });
        }

        function onResizeTimeout() {
            delete Tn.resizeTimer;
            var width = $(window).width();

            if (window.tnVars.isPhone()) {
                $('body').addClass('phone');
            } else {
                $('body').removeClass('phone');
            }

            var timeSliderWidth = width - 200;
            if (timeSliderWidth < 20) {
                timeSliderWidth = 20;
            }
            $('#time-slider').parent().width(timeSliderWidth);
            $('body').trigger('pageresize');
        }

        function onResize() {
            if (Tn.resizeTimer) {
                return;
            }
            Tn.resizeTimer = setTimeout(onResizeTimeout, 250);
        }

        logStartup('Doing initial sizing');
        $(window).resize(onResize);
        onResize();

        logStartup('Registering page events');
        registerUIEvents(window.turnerVideo);

        // In development environments, capture any Gigya login issues that may occur
        try {
            logStartup('Initializing Gigya');
            Tn.Users.initialize({
                onLoginCB: function() {
                    window.turnerVideo.restoreState(Tn.Users.getPref('currentVideo'));
                },

                onStartup: function(userId) {
                    var legalMsgOne = "By using this site, you agree to our updated <a class='legaltoast' href='/terms.html'>Terms of Use</a> and <a class='legaltoast' href='/privacy.html'>Privacy Policy</a>.";
                    if (!userId) {

                        if (!$.cookie('legalMsg')) {
                            Tn.legalMessage("By using this site, you agree to " + window.siteDefaults.name + "’s <a class='legaltoast' href='/terms.html'>Terms of Use</a> and <a class='legaltoast' href='/privacy.html'>Privacy Policy</a>.", {
                                onHidden: function() {
                                    $.cookie('legalMsg', '1', {
                                        expires: 365,
                                        path: '/'
                                    });
                                }
                            });
                            $('a.legaltoast').on('click', function(event) {
                                event.preventDefault();
                                event.stopPropagation();
                                Tn.setUrl($(this).attr("href"), true, 'page-generic');
                                //$('#welcome-dialog').modal('hide');
                            });
                        } else if (!$.cookie('legalMsg1')) {
                            Tn.legalMessage(legalMsgOne, {
                                onHidden: function() {
                                    $.cookie('legalMsg1', '1', {
                                        expires: 365,
                                        path: '/'
                                    });
                                }
                            });
                            $('a.legaltoast').on('click', function(event) {
                                event.preventDefault();
                                event.stopPropagation();
                                Tn.setUrl($(this).attr("href"), true, 'page-generic');
                                //$('#welcome-dialog').modal('hide');
                            });
                        }
                        /*
                        if (!$.cookie('welcome')) {

                            
                            // we are removing the welcome screen but keeping in case we want it again later - TENDP-12191
                      
                            $.cookie('welcome', '1', {
                                expires: 365,
                                path: '/'
                            });
    
                            Tn.loadImages('welcome-dialog');
                            setTimeout(function(){
                                $('#welcome-dialog').modal('show');
                            }, 1000);
                         
                            Tn.parseAnalytics({
                                "url_section": "/",
                                "section": "profile",
                                "subsection": "profile:welcome",
                                "template_type": "adbp:misc",
                                "content_type": "other:overlay",
                                "search.keyword": "",
                                "search.number_results": "",
                                "friendly_name": "profile welcome page",
                                "series_name": ""
                            }, false);
                            
                        }
                        */
                        Tn.getFeaturedVideos(window.turnerVideo.updateTitleHelper);
                    } else {
                        if (!$.cookie('legalMsg1')) {
                            Tn.legalMessage(legalMsgOne, {
                                onHidden: function() {
                                    $.cookie('legalMsg1', '1', {
                                        expires: 365,
                                        path: '/'
                                    });
                                }
                            });
                            $('a.legaltoast').on('click', function(event) {
                                event.preventDefault();
                                event.stopPropagation();
                                Tn.setUrl($(this).attr("href"), true, 'page-generic');
                                //$('#welcome-dialog').modal('hide');
                            });
                        }
                    }
                }
            });
        } catch (e) {
            logStartup('Gigya Exception');
            console.error("Exception initializing Gigya", e.message);
        }

        logStartup('Removing splash normally');

        // Remove the splash screen
        if (!Tn.splashHidden) {
            Tn.splashHidden = true;
            $('#screen-splash').fadeOut(1000);
        }

        // Smart banner start
        function smartBannerShown(){
            $('body').addClass('smartbanner');
        }
        function smartBannerHidden(){
            $('body').removeClass('smartbanner');
            $('#'+ Tn.currentPage).resize();
        }
        $(function() { $.smartbanner(
            { 
                appendToSelector: 'header', 
                layer: true,
                daysHidden: 7,
                daysReminder: 7,
                hideOnInstall: false,
                author: window.siteDefaults.smartbannerAuthor,
                title: window.siteDefaults.smartbannerTitle,
                pushSelector: 'header .navbar .container',
                iOSUniversalApp: true,
                showCallback: smartBannerShown,
                hideCallback: smartBannerHidden,
                speedIn: 0,
                speedOut: 0
            }); 
        });
        // Smart banner end
    });


}(jQuery, window));
