/**
 * @class turnerVideo
 *
 * Takes care of displaying the video id found in the string url
 *
 * For example : page.html?titleId=123456
 *
 */
(function($, undefined) {
    var turnerVideo = window.turnerVideo = {},
        sendVideoEvent = window.sendVideoEvent,
        TVE_VideoEvent = window.TVE_VideoEvent,
        tnVars = window.tnVars,
        isMobile = tnVars.isMobile(),
        //jsmd = window._jsmd_default,
        site = "",
        profile = "",
        context = "",
        fullEpId,
        clipId,
        playerLoaded = false,
        cvpReady = false,
        cvpPlayStarted = false,
        cvpInAds = false,
        vidObject = null,
        playButton = null,
        pauseButton = null,
        timeSlider = null,
        timeSliderBut = null,
        timeSliderHandle = null,
        playtimeDone = null,
        playtimeTogo = null,
        playtimeLeftMin = 0,
        playtimeLeftSec = 0,
        pausedEpisodeTitle = null,
        pausedSeriesTitle = null,
        cvpDiv = null,
        // playerWrapper is the left side video container
        playerWrapper = null,
        playerArea = null, // Seen when HTML5 player is available
        // playerDiv contains the video object, pause div, control divs
        // this should be the same size as player so the control icons and pause screen lay over top of video
        playerDiv = null,
        pausedAreaDiv = null,
        isPaused = false,
        railAndVideoState = {"pausedWhenLastOpen_SmallScreen": true},
        doHideSplash = true,
        tveModeGlobal = '',
        lastTveModeGlobal = '',
        ssidEast = window.siteDefaults.liveTV.ssidEast,
        ssidWest = window.siteDefaults.liveTV.ssidWest,
        videoFeedEast = window.siteDefaults.liveTV.videoFeedEast,
        videoFeedWest = window.siteDefaults.liveTV.videoFeedWest,
        ssid = ssidEast,
        lastVideoId,
        videoState = {},
        showProgress = false,
        removeAdDiv = false,
        usingAuthentication = true,
        doVideoCompleteEvent = true,
        lastSavedInitOptions,
        doInitializeVideoEvents = true,
        setVideoCountdownCalledCount = 0,
        isLiveContentPlay = false,
        liveVideo = {},
        clipVideo = {},
        playbarState = null;


    // Always available in UI
    playButton = $('#play-but');
    pauseButton = $('#pause-but');
    timeSlider = $('#time-slider');
    //timeSliderBut = $("#time-slider-but");
    timeSliderBut = $("#time-slider").find('.highlight-track');
    //timeSliderHandle = $("#time-slider .time-slider-handle");
    timeSliderHandle = $("#time-slider").find('.dragger');
    playtimeDone = $(".playtime #done");
    playtimeTogo = $(".playtime #togo");

    function hideSplash() {
        doHideSplash = false;
        $('#loading-splash').hide();
        $('body').addClass('vid-loaded');
    }

    function addLiveStat(videoId) {
        var airingId = $('#page-video').attr("airingid");
        if (!airingId) {
            return;
        }

        var liveHistory = Tn.Users.getPref('liveHistory', []);
        if(!$.isArray(liveHistory)){
            /* Patching problem where gigya has objects stored for liveHistroy */
            liveHistory = [];
        }
        var liveDate = new Date().getTime();
        liveHistory.push({
            dt: liveDate,
            ai: airingId,
            fd: parseInt(videoId, 10) === parseInt(videoFeedEast, 10) ? 'e' : 'w',
            os: tnVars.getPlatform()
        });

        while (liveHistory > 50) {
            liveHistory.shift();
        }
        Tn.Users.setPref("liveHistory", liveHistory);
    }

    function addStat(videoId, franchiseId) {
        var history = Tn.Users.getPref('videoHistory', {}),
            videoHistoryKey = (videoId) ? Tn.Users.vidHistoryPrefix + videoId : 'not_found',
            vid = history[videoHistoryKey],
            now = new Date().getTime();
        if (!vid) {
            vid = {
                cnt: 0,
                play: []
            };
        }
        if (!$.isArray(vid.play)) {
            vid.play = [];
        }
        vid.cnt = vid.cnt + 1;
        vid.dt = now;
        vid.fId = franchiseId;
        vid.play.push({
            os: tnVars.getPlatform(),
            st: now
        });
        history[videoHistoryKey] = vid;

        // Trim list to contain a limited set of history
        var results = [];
        $.each(history, function(key, val) {
            results.push({
                key: key,
                dt: val.dt
            });
        });
        results.sort(function(b, a) {
            if (a.dt > b.dt) {
                return 1;
            }
            if (a.dt < b.dt) {
                return -1;
            }
            return 0;
        });
        for (var i = Tn.maxVideoHistory; i < results.length; i++) {
            delete history[results[i].key];
        }

        // Save the updated history
        Tn.Users.setPref('videoHistory', history);
    }

    function updateState(o, force) {


        if (force) {
            videoState = o;
        } else {
            videoState = $.extend({}, videoState, o);
        }

        if(videoState.videoType === 'clip'){
            // we no longer want clips saved in gigya for a user
            clipVideo = videoState;
            return;
        }
        
        

        var history = Tn.Users.getPref('videoHistory', {}),
            videoHistoryKey = (lastVideoId) ? Tn.Users.vidHistoryPrefix + lastVideoId : 'notFound';
        if (lastVideoId && history[videoHistoryKey]) {
            var vid = history[videoHistoryKey];
            if (videoState.playing && videoState.playhead !== undefined && videoState.duration !== undefined) {
                vid.pg = (videoState.playhead || 0) * 100 / (videoState.duration || 1);
            }
            if (videoState.pg !== undefined) {
                vid.pg = videoState.pg;
            }
            history[videoHistoryKey] = vid;
            Tn.Users.setPref('videoHistory', history);
        }

        // we do not want to pass videoType into gigya at this point
        // the apps do not have it, we will add type in the gigya service
        // but we do want to keep it in videoState so we can reference it again
        var vs = videoState;
        delete vs.videoType;
        

        // we do not want to save the live video as the currentvideo
        if(videoState.fullEpId !== window.siteDefaults.liveTV.videoFeedEast && 
            videoState.fullEpId !== window.siteDefaults.liveTV.videoFeedWest){
            Tn.Users.setPref('currentVideo', videoState);

        } else {
            liveVideo = videoState;
        }
        
    }

    function openRail(reset) {
        if (turnerVideo.currentMode !== "full") {
            return;
        }
        var infoPane = $('#page-video aside a[paneid="pane-info"]'),
            sharePane = $('#page-video aside a[paneid="pane-share"]');
        if ((!infoPane.hasClass('active') && !sharePane.hasClass('active')) || (!infoPane.hasClass('active') && reset)) {
            infoPane.trigger('click');
        }
    }

    function closeRail() {
        $('.in-player-tray').removeClass('open');
        $('#page-video aside a[paneid]').removeClass('active');
        $('#page-video .player-wrapper').removeClass('railopen');
        // setting timeout so the pane does not hide while it is still visible
        // transition in css is set to .5
        window.setTimeout(function() {
            if(!$('.in-player-tray').hasClass('open')){
                $('#page-video aside .pane').hide();
            }
        }, 600);
        window.turnerVideoPageObj.stopAdInTrayReloader();
        if (cvpInAds || ($(window).width() <= 600)) {
            // Small screens won't get sync ads
            // Turn off all cvp sync ads in the tray but only in preroll/midroll.  
            // Need the first ad to run so later ones can come into view later.  Need the instationation when first ad starts.
            // Rules are such that, the tray will open if closed on preroll start so only turn off ads if ads are running and user closed tray
            window.window.adHelper.manageSyncAds([], $('#page-video aside .syncAdWrapper'));
        }
        turnerVideo.watchResize(1000);
    }

    function updateSize() {
        var page = $('#page-video');
        var dim;
        switch (turnerVideo.currentMode) {
            case 'upnext':
                dim = [20, page.width() - 356 - 20, 20, page.height() - 200 - 20];
                break;
            default:
                dim = [0, 0, 0, 0];
        }

        var lastDim = turnerVideo.lastDim;
        if (lastDim && lastDim[0] === dim[0] && lastDim[1] === dim[1] && lastDim[2] === dim[2] && lastDim[3] === dim[3]) {
            return;
        }
        turnerVideo.lastDim = dim;

        $('#page-video .player-wrapper').css({
            left: dim[0],
            right: dim[1],
            top: dim[2],
            bottom: dim[3]
        });
        turnerVideo.watchResize(1500);
    }

    function doVideoCountdown() {
        if (turnerVideo.countdownTimer) {
            clearTimeout(turnerVideo.countdownTimer);
        }

        // If the video has finished playing, then play the next video
        if (!videoState.playing) {
            if (turnerVideo.upNextUrl) {
                Tn.showPlayer(turnerVideo.upNextUrl);
                Tn.autoPlaying = true;
                delete turnerVideo.upNextUrl;

            }
            return;
        }
        // Tn.Users.prefs.currentVideo.duration
        var theDuration = (turnerVideo.player.getDuration())?turnerVideo.player.getDuration():
                        (Tn.Users.prefs.currentVideo && Tn.Users.prefs.currentVideo.duration)?Tn.Users.prefs.currentVideo.duration:0,
            timeRemaining = theDuration - turnerVideo.player.getPlayhead();
        timeRemaining = parseInt(timeRemaining, 10) + 1;

        // If the user seeked backwards, then get rid of upnext
        if (timeRemaining > (Tn.upNextTimeInSeconds + 3)) {
            showMode('full');
            return;
        }

        // Clamp the upnext value
        if (timeRemaining > Tn.upNextTimeInSeconds) {
            timeRemaining = Tn.upNextTimeInSeconds;
        }

        $('#page-video .countdown').text(timeRemaining);

        turnerVideo.countdownTimer = setTimeout(doVideoCountdown, 500);
    }

    function setVideoCountdown() {
        setVideoCountdownCalledCount++;
        var setUpStatusObj,
            thisVideo,
            matchingPlaylistVideo,
            wasVideoFoundOnShowsPage = false,
            wasVideoFoundOnShowsByName = false,
            rows,
            thePlaylist4VideoPlaying = [],
            nextPlaylistVideos = [],
            movieCarousels = [],
            nextCarouselVideos = [],
            firstVideosFirstCarousel = [],
            sameTypeVideos = [],
            videosFromRelatedSeries = [],
            finalNextVideos,
            carousels,
            upnextEp;
        if (setVideoCountdownCalledCount > 4) {
            console.log("There's a problem with setVideoCountdown so stopping up next ");
            setVideoCountdownCalledCount = 0;
            return;
        }
        if (!Tn.movieData && Tn.videoType === 'movie') {
            Tn.getMovieCarouselData(setVideoCountdown, true);
            return;
        } else if (!Tn.showData) {
            Tn.getCarouselData(setVideoCountdown, true);
            return;
        } else if (!Tn.showDataWithPlaylists) { // requires Tn.showData so playlists can be added
            Tn.getPlaylistExpandedCarouselData(setVideoCountdown);
            return;
        } else if (Tn.videoPlayingIsSponsored && Tn.series4VideoPlaying && !Tn.playlistsOnShowPage[Tn.series4VideoPlaying]) {
            //} else if(true && Tn.series4VideoPlaying && !Tn.playlistsOnShowPage[Tn.series4VideoPlaying]){ 
            // Requires Tn.showDataWithPlaylists so we know what playlists are on the show page
            // This video might not be on the shows page so we just get the playlist
            if (!Tn.showsByNameData[Tn.series4VideoPlaying]) {
                Tn.getShowsByNameCarouselData(setVideoCountdown, Tn.series4VideoPlaying, true);
                return;
            } else if (Tn.showsByNameData[Tn.series4VideoPlaying].carousels) {
                thePlaylist4VideoPlaying = Tn.showsByNameData[Tn.series4VideoPlaying].carousels;
                setUpStatusObj = setUpNextVideosHelper(thePlaylist4VideoPlaying, nextPlaylistVideos, false, false, false, wasVideoFoundOnShowsPage);
                matchingPlaylistVideo = setUpStatusObj.thisVideo;
                wasVideoFoundOnShowsByName = setUpStatusObj.wasVideoFoundOnShowsPage;
            }
        }
        setVideoCountdownCalledCount = 0;
        doVideoCountdown();

        // Find the current video in the stack and play the next video after that

        carousels = (Tn.showDataWithPlaylists.carousels) ? Tn.showDataWithPlaylists.carousels : [];
        rows = (Tn.showData.rowHdr) ? Tn.showData.rowHdr : [];
        for (var showIndex = 0; showIndex < rows.length; showIndex++) {
            if (firstVideosFirstCarousel.length > 3) {
                // maintaining value of wasVideoFoundOnShowsPage so we can continue to build the list of nextCarouselVideos
                setUpStatusObj = setUpNextVideosHelper(carousels[showIndex], nextCarouselVideos, false, sameTypeVideos, videosFromRelatedSeries, wasVideoFoundOnShowsPage);
            } else {
                setUpStatusObj = setUpNextVideosHelper(carousels[showIndex], nextCarouselVideos, firstVideosFirstCarousel, sameTypeVideos, videosFromRelatedSeries, wasVideoFoundOnShowsPage);
            }
            if (!wasVideoFoundOnShowsPage) {
                thisVideo = setUpStatusObj.thisVideo;
                wasVideoFoundOnShowsPage = setUpStatusObj.wasVideoFoundOnShowsPage;
            }
        }
        var item;

        // In the case where we get the last video of the last carousel, upnext will
        // wasVideoFoundOnShowsPage can be true for the last video on the shows page and nextCarouselVideos empty
        // If nextCarouselVideos is empty then we know this video is not in the carousels we are looking at.  Find like videos and start there next.
        if (nextCarouselVideos.length === 0 && wasVideoFoundOnShowsPage === false && Tn.videoType === 'movie') {
            flatten(Tn.movieData.carousels, movieCarousels);
            setUpStatusObj = setUpNextVideosHelper(movieCarousels, nextCarouselVideos, false, sameTypeVideos, false, wasVideoFoundOnShowsPage);
            thisVideo = setUpStatusObj.thisVideo;
            wasVideoFoundOnShowsPage = setUpStatusObj.wasVideoFoundOnShowsPage;
        }
        // playlist video not in the shows landing page ( playlists expanded ) but found/not found in the byName feed
        if (Tn.videoPlayingIsSponsored && Tn.series4VideoPlaying && nextCarouselVideos.length === 0 && !Tn.playlistsOnShowPage[Tn.series4VideoPlaying]) {
            if (wasVideoFoundOnShowsByName === true) {
                finalNextVideos = nextPlaylistVideos.concat(videosFromRelatedSeries, firstVideosFirstCarousel);
            } else {
                finalNextVideos = thePlaylist4VideoPlaying.concat(videosFromRelatedSeries, firstVideosFirstCarousel);
            }
        } else if (nextCarouselVideos.length === 0 && wasVideoFoundOnShowsPage === false) { // video not on the shows landing page
            // videosFromRelatedSeries will populate if this video is sponsored
            finalNextVideos = sameTypeVideos.concat(videosFromRelatedSeries, firstVideosFirstCarousel);
        } else {
            finalNextVideos = nextCarouselVideos.concat(firstVideosFirstCarousel);
        }
        thisVideo = (matchingPlaylistVideo) ? matchingPlaylistVideo : (thisVideo) ? thisVideo : false;
        if (finalNextVideos.length > 0) {
            finalNextVideos.splice(10);
            var seenObj = {};
            if (thisVideo && typeof(thisVideo) === 'object' && thisVideo.videoLink && typeof(thisVideo.videoLink) === 'string' && thisVideo.videoLink > 0) {
                seenObj[thisVideo.videoLink] = true;
            }
            Tn.deDupList(finalNextVideos, seenObj);
            upnextEp = finalNextVideos[0];
            item = $('<div></div>');
            $('#page-video .countdown-video').empty().append(item);
            initializeUpNextOverlay(item, upnextEp);
            $('#page-video').find('.upnext-bg').css({
                'background-image': 'url("' + upnextEp.imgSrc + '")'
            });
            turnerVideo.upNextUrl = upnextEp.videoLink;
            if (finalNextVideos.length > 1) {
                item = $('<div></div>');
                $('#page-video .recommend-video').empty().append(item);
                initializeUpNextOverlay(item, finalNextVideos[1]);
                if (finalNextVideos.length > 2) {
                    item = $('<div></div>');
                    $('#page-video .recommend-video2').empty().append(item);
                    initializeUpNextOverlay(item, finalNextVideos[2]);
                }
            }
        }

        // if (!$('body').hasClass('adPlaying')) {
        //     turnerVideo.showMode('upnext');
        // }

        if (thisVideo && thisVideo.imgSrc) {
            $('#page-video .pausedArea').css('backgroundImage', 'url(/images/play.png), url("' + thisVideo.imgSrc + '")');
        }
        //console.error("Found last video", thisVideo);
    }

    function initializeUpNextOverlay(item, data) {
            if (data.videoType === 'movie') {
                Tn.initializeMovieOverlay(item, data, true);
            } else {
                Tn.initializeShowOverlay(item, data);
            }
        }
        /** Reuse for show, sponsored, and movie carousels.  Pass in pointer to the arrays you want populated. */
    function setUpNextVideosHelper(carousel, nextCarouselVideos, firstVideosFirstCarousel, sameTypeVideos, videosFromRelatedSeries, wasVideoFoundOnShowsPageTmp) {
        var videoCounter = 0,
            // maintaining value of wasVideoFoundOnShowsPage so we can continue to build the list of nextCarouselVideos
            wasVideoFoundOnShowsPage = (wasVideoFoundOnShowsPageTmp) ? wasVideoFoundOnShowsPageTmp : false,
            playListVideos = [],
            setUpStatusObj,
            thisVideo,
            thisLinkSubstr = (Tn.videoType === 'movie') ? 'videos/movies' : window.turner_metadata.series_name;
        $.each(carousel, function(tileIndex, ep) {
            ep.epinfo = ep.epinfoPLUS; /*ep.epinfo + " " + ep.tvRating*/
            // we are removing availExpire from the up next tiles (on the front)
            ep.availExpire = '';
            //console.log(ep);
            if (!ep.playable) {
                return;
            }
            videoCounter++;

            if (firstVideosFirstCarousel && videoCounter < 4) {
                firstVideosFirstCarousel.push($.extend({}, ep));
            }
            if (sameTypeVideos && ep.videoLink && ep.videoLink.length > 0 && ep.videoLink.indexOf(thisLinkSubstr) !== -1) {
                sameTypeVideos.push($.extend({}, ep));
            }
            // THe sponsored list's series name and the associated series name on the shows page both use the sponsored list's series name.
            var adaptForBadSeriesNameInPath = false; // See http://docs.turner.com/display/TEN/Watch+1.9+Documentation#Watch1.9Documentation-MakingaplaylistandadditsteaserintheCMA
            if (videosFromRelatedSeries && ep.videoLink && ep.videoLink.length > 0 && (
                    (Tn.sponsoredNextSeries4VideoPlaying && ep.videoLink.indexOf(Tn.sponsoredNextSeries4VideoPlaying) !== -1) ||
                    (adaptForBadSeriesNameInPath && Tn.series4VideoPlaying && ep.videoLink.indexOf(Tn.series4VideoPlaying) !== -1))) {
                videosFromRelatedSeries.push($.extend({}, ep));
            }
            // episodes match on contentID while clips match on contenid
            // /service/cvpXml?titleId=2012978 vs /service/cvpXml?titleId=&id=924567
            // playlists match on url since a video of the same content id can match but not be in the playlist.  The path for the playlist makes a playlist
            if (!wasVideoFoundOnShowsPage && (
                    (!(Tn.videoPlayingIsSponsored) && (parseInt(ep.contentid, 10) === lastVideoId || parseInt(ep.titleid, 10) === lastVideoId)) ||
                    (Tn.videoPlayingIsSponsored && Tn.series4VideoPlaying === ep.playlistSeriesName && ep.videoLink.indexOf(lastVideoId) > -1)
                )) {
                wasVideoFoundOnShowsPage = true;
                thisVideo = $.extend({}, ep);
                //console.error("Found video", ep);
            } else if (wasVideoFoundOnShowsPage && nextCarouselVideos) {
                nextCarouselVideos.push($.extend({}, ep));
            }
        });
        return {
            "thisVideo": thisVideo,
            "wasVideoFoundOnShowsPage": wasVideoFoundOnShowsPage
        };
    }

    function flatten(toBeFlattenedArr, resultArr) {
        if (typeof toBeFlattenedArr.length !== "undefined") {
            for (var i = 0; i < toBeFlattenedArr.length; i++) {
                flatten(toBeFlattenedArr[i], resultArr);
            }
        } else {
            resultArr.push(toBeFlattenedArr);
        }
    }

    function showMode(mode, force) {
        if (mode !== 'full' && turnerVideo.currentMode === mode) {
            if (!force) {
                return;
            }
        }

        var page = $('#page-video');
        turnerVideo.currentMode = mode;
        page.attr('mode', mode);
        switch (mode) {
            case 'upnext':
                window.turnerVideoPageObj.resetBackGroundSkin();
                // Animate down to the size shown
                $('#page-video .player-wrapper').css({
                    left: 20,
                    top: 20,
                    right: page.width() - 356 - 20,
                    bottom: page.height() - 200 - 20
                });
                closeRail();

                // After animation complete, set the fixed width and height
                setTimeout(function() {
                    $('#page-video .player-wrapper').css({
                        width: 356,
                        height: 200
                    });
                }, 500);
                // Call setVideoCountdown so it is none blocking and let's go of the thread which is onContentPlayhead 
                setTimeout(function() {
                    try {
                        setVideoCountdown(Tn.upNextTimeInSeconds);
                    } catch (e) {
                        console.log('setVideoCountdown error', e);
                    }
                }, 0);

                break;

            default:
                $('#page-video .pausedArea').css('backgroundImage', '');
                if (turnerVideo.countdownTimer) {
                    clearTimeout(turnerVideo.countdownTimer);
                    delete turnerVideo.countdownTimer;
                }
                $('#page-video .player-wrapper').css({
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0,
                    width: 'auto',
                    height: 'auto'
                });
                break;
        }

        page.attr('mode', mode);

        turnerVideo.watchResize(1500);
    }

    turnerVideo.showMode = showMode;

    function calculateXMLTimeInMS(time) {
        var times = time.split(':');
        return parseInt(times[0], 10) * 60 * 60 * 1000 + parseInt(times[1], 10) * 60 * 1000 + parseInt(times[2], 10) * 1000 + parseInt(times[3], 10) * 1000 / 100;
    }

    function toHHMMSS(txt, round) {
        var sec_num = parseInt(txt, 10); // don't forget the second param
        var hours = Math.floor(sec_num / 3600);
        var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
        var seconds = sec_num - (hours * 3600) - (minutes * 60);
        if (round) {
            if (seconds > 29) {
                minutes += 1;
            }
            return hours * 60 + minutes;
        }
        if (seconds < 10) {
            seconds = "0" + seconds;
        }
        var time = hours + ':' + minutes;
        if (hours === 0) {
            time = minutes;
        }
        if (!round) {
            time += ':' + seconds;
        }
        return time;
    }

    function toMMSS(txt) {
        var obj = {};
        var sec_num = parseInt(txt, 10); // don't forget the second param
        var minutes = Math.floor(sec_num / 60);
        var seconds = sec_num - (minutes * 60);
        obj.secs = seconds;
        obj.minutes = minutes;
        
        return obj;
    }

    function setTheSizingClass(playerWrapper, cvpHeight){
        playerWrapper.removeClass('smallerPlayer');
        playerWrapper.removeClass('smallPlayer');
        if(cvpHeight <= 230){
            playerWrapper.addClass('smallerPlayer');
        } else if(cvpHeight <= 340){
            playerWrapper.addClass('smallPlayer');
        }
    }
    $.extend(turnerVideo, {
        toHHMMSS: toHHMMSS,
        visible: true,
        videoSkinSelector: '.player-wrapper .videoSkinArea',
        screenWidthTooSmallForSkin: 1023,
        maxSizeOfCVPWithSkin: 740,
        videoSkinPatchSelector: '.player-wrapper .videoSkinAreaIconTransparencyPatch',
        isFullscreen: false,
        badVideoStateCount: 0,
        adPlayheadWithPauseCounter: 0,
        justRequestedSeekedTo: -1,
        justRequestedSeekedToAttempts: 0,
        
        /**
         * Initializs the turnerVideo object
         * @param {[type]} params [description]
         * @return {[type]} [description]
         */
        init: function(params) {
            site = params['site'];
            profile = params['profile'];
            context = params['context'];
            fullEpId = params['fullEpId'];
            clipId = params['clipId'];
            videoType = params['videoType'];

            cvpInAds = false;
            this.badVideoStateCount = 0;
            this.adPlayheadWithPauseCounter = 0;
            this.justRequestedSeekedTo = -1;
            this.justRequestedSeekedToAttempts = 0;
            var durationSeconds = (parseInt(params['durationSeconds'], 10)) ? parseInt(params['durationSeconds'], 10) : 0,
                videoId = parseInt(fullEpId, 10) ? parseInt(fullEpId, 10) : parseInt(clipId, 10),
                playhead = this.getPlayheadHelper(durationSeconds, videoId, true);

            updateState({
                'fullEpId': fullEpId,
                'clipId': clipId,
                'title': $('#pane-info h1.title').text(),
                'url': window.location.href,
                'playhead': playhead,
                'duration': durationSeconds,
                'videoType' : videoType
            }, true);
            
            if(vidObject && vidObject.hasOwnProperty("paused")){
                delete vidObject.paused; // Not paused or played for iPhone html5 player
            }

            // when changing pages to live tv, the duration seconds is 0 and it is setting the timer wrong
            // it should remain as it showing the currentVideo time until the playhead starts
            // and the playbar gets rewritten with the  live tv data
            if(durationSeconds > 0){
                this.updateProgress(playhead, durationSeconds);
            }
            
        },

        /**
         * Toggles the playing of the video
         *  I don't think this function is used.
         */
        togglePausePlay: function() {
            if (cvpPlayStarted) {
                if (turnerVideo.player.isPaused()) {
                    turnerVideo.player.resume();
                } else {
                    turnerVideo.player.pause();
                }
            }
        },
        /**
         * Pauses the currently playing video
         * We have to stop live and not pause because pause() lets the live stream keep playing.
         * @return {[type]} [description]
         */
        pause: function(stopMe) {
            if (cvpPlayStarted) {
                if (stopMe) { // for live from pauseLive.
                    turnerVideo.player.stop();
                    // we want to stop the player so that the next time the play button is clicked
                    // the defaultVideo, which is displayed in the playbar, will play
                    // previous to this, if you were on live stream then clicked away, the playbar would updated with the default video
                    // which was the last non live video to play, but when you clicked the play button on the playbar, it would go back to the 
                    // live stream
                    cvpPlayStarted = false;
                    // when we stop the live video, we do not want the analytics continue watching call to go out
                    //return;

                } else {
                    turnerVideo.player.pause();
                }
                // jhillmann - i am trying the analytics call witin onContentPause so we can send one when the user
                // touches the player itself to pause
                // at this location it only sends when the pause button is clicked
                /*
                Tn.parseAnalytics({
                    "url_section": "/",
                    "section": "videos",
                    "subsection": "videos:continue watching",
                    "template_type": "adbp:video",
                    "content_type": "other:overlay",
                    "search.keyword": "",
                    "search.number_results": "",
                    "friendly_name": "video continue watching",
                    "series_name": window.turner_metadata.series_name
                }, false);
    */
            }
            updateState({
                "paused": true
            });
            // Handles the case where its hard to get a event during html5 ads.  This is called from playbar button
            if(vidObject && typeof(vidObject) === 'object'){
                vidObject.paused = true;
            }
            playButton.css("display", "block");
            pauseButton.css("display", "none");
            turnerVideo.togglePauseState(true);
            turnerVideo.stopAdPlayheadWorkAroundTimer();
        },
        /**
         *  This stops the currently playing live video.
         *  We have to stop live when we want to pause it.  pause() lets the live stream keep playing.
         */
        pauseLive: function() {
            turnerVideo.pause(true);
            // this needs to pass in the currentVideo object, not the full prefs object
            turnerVideo.restoreState(Tn.Users.prefs.currentVideo);
            $("#time-slider").find('.highlight-track').show();
            $("#time-slider").find('.dragger').show();
            // can we put the playbar back to the saved state VOD
        },
        /**
         * [stopClipPlayer - when we are watching a clip and navigate away, we don't want the play button to start the clip]
         * @return {[type]} [description]
         */
        stopClipPlayer: function(){
            turnerVideo.player.stop();
            clipId = null;
            cvpPlayStarted = false;
        },
        getPlayheadHelper: function(durationTmp, videoIdTmp, forceLookup) {
            var videoHistoryKey = (videoIdTmp) ? Tn.Users.vidHistoryPrefix + videoIdTmp : Tn.Users.vidHistoryPrefix + lastVideoId,
                playhead = 0;

            if (cvpInAds || forceLookup) {
                // getPlayHead does like we want when in ads.  New videos should be looked up
                var history = Tn.Users.getPref('videoHistory', {}),
                    duration = (durationTmp && parseInt(durationTmp, 10)) ? parseInt(durationTmp, 10) : (videoState && videoState.duration) ? videoState.duration : -1;
                if (history[videoHistoryKey] && duration >= 0) {
                    if (history[videoHistoryKey].pg && history[videoHistoryKey].pg > 0 && history[videoHistoryKey].pg < 100) {
                        playhead = duration * history[videoHistoryKey].pg / 100.0;
                    }
                }
            }
            if (!cvpInAds && playhead === 0 && !forceLookup) {
                // in case we are not in ads and to try again to get a playhead value if this is not a new video initializing
                playhead = turnerVideo.player.getPlayhead();
            }
            return playhead;
        },
        stopAdPlayheadWorkAroundTimer: function(){
            if (turnerVideo.adPlayHeadTimer) {
                clearTimeout(turnerVideo.adPlayHeadTimer);
            }
        },

        setVolume: function(level) {
            if (!cvpPlayStarted || !cvpReady) {
                return;
            }
            if (level > 0) {
                turnerVideo.player.unmute();
                turnerVideo.player.setVolume(level);
            } else {
                turnerVideo.player.mute();
            }
        },

        hideHDIcon: function() {
            var el = document.getElementById('cvp_1');
            // hdEnabled = Tn.Users.getPref("hd", true); // TENDP-11820: Not used for pHDS
            if (el && typeof(el.setHDToggleVisible) === 'function') {
                el.setHDToggleVisible(false); // Hide HD icon in all cases for pHDS
            }
        },

        showPlayer: function() {
            if (!Tn.lastVideoUrl || $('#page-video').hasClass('shown')) {
                return;
            }
            Tn.setUrl(Tn.lastVideoUrl, false, "page-video");
        },

        cancelUpNext: function() {
            if (turnerVideo.countdownTimer) {
                clearTimeout(turnerVideo.countdownTimer);
            }
            delete turnerVideo.countdownTimer;
        },

        removeHTML5VideoControls: function(waitTmp) {
            var wait = (typeof(waitTmp) === 'number')?waitTmp:0;
            // See togglePauseState() and onAdPlay
            var amHTML5Player = ( typeof(this.player) === 'object' && typeof(this.player.getPlayerType) === 'function' && this.player.getPlayerType() === 'html5')?true:false;
            if(!amHTML5Player){
                return;
            }
            setTimeout(function() {
                $('#cvp_1').removeAttr('controls');
            }, wait);
        },

        addHTML5VideoControls: function(waitTmp) {
            var wait = (typeof(waitTmp) === 'number')?waitTmp:0;
            // See togglePauseState()
            var amHTML5Player = ( typeof(this.player) === 'object' && typeof(this.player.getPlayerType) === 'function' && this.player.getPlayerType() === 'html5')?true:false;
            if(cvpInAds || !amHTML5Player){
                return;
            }
            setTimeout(function() {
                $('#cvp_1').attr('controls','controls');
            }, wait);
        },

        togglePauseState: function(val) {
            // Here we will hide or show the footer / header for the video page for mobile.  
            $('body').toggleClass('vid-paused', val).toggleClass('vid-playing', !val);
            // Below ( removeHTML5VideoControls() | addHTML5VideoControls() ), we add/remove the video tag controls
            isPaused = val;
            if (val) {
                if (vidObject) {
                    //pausedSeriesTitle.html(vidObject.franchise);
                    //pausedEpisodeTitle.html(vidObject.headline);
                    // we are pulling the data control data from the right rail info panel
                    pausedSeriesTitle.html($('#pane-info h1.title').text());
                    pausedEpisodeTitle.html($('#pane-info .vidtitle h2').text());
                    // $('#paused-episode-desc').text($('#pane-info .desc').text());
                    var se = $('#paused-season-episode');
                    var wrapper = $('#pausedAreaDiv .wrapper');

                    se.find('.season span').text($('#pane-info .season span').text());
                    se.find('.ep span').text($('#pane-info .ep span').text());
                    if (vidObject.vidType === 'clip') {
                        wrapper.addClass('clip');
                        wrapper.removeClass('livetv');
                        wrapper.removeClass('fullep');
                    } else if (vidObject.vidType === 'fullep' || vidObject.vidType === 'movies') {
                        wrapper.addClass('fullep');
                        wrapper.removeClass('livetv');
                        wrapper.removeClass('clip');
                    } else if (vidObject.vidType === 'live') {
                        wrapper.addClass('livetv');
                        wrapper.removeClass('fullep');
                        wrapper.removeClass('clip');
                    } else {
                        wrapper.removeClass('livetv');
                        wrapper.removeClass('fullep');
                        wrapper.removeClass('clip');
                    }

                    if ($('#paused-season-episode .season span').text() === '') {
                        $('#paused-season-episode .season').hide();
                    } else {
                        $('#paused-season-episode .season').show();
                    }

                    if ($('#paused-season-episode .ep span').text() === '') {
                        $('#paused-season-episode .ep').hide();
                    } else {
                        $('#paused-season-episode .ep').show();
                    }

                    if ($('#paused-episode-title h2').text() === '') {
                        $('#paused-episode-title').hide();
                    } else {
                        $('#paused-episode-title').show();
                    }

                    if(vidObject.vidType === 'live') {
                        if ( $('#paused-season-episode .season span').text() === '' && $('#paused-season-episode .ep span').text() === '') {
                            $('#paused-season-episode .season').hide();
                            $('#paused-season-episode .ep').hide();
                        } else {
                            wrapper.addClass('highlight-title');
                        }
                    } else {
                        wrapper.removeClass('highlight-title');
                    }

                    if (playtimeLeftSec >= 60) {
                        $('#paused-remaining-time').text(playtimeLeftMin + ' minute' + (playtimeLeftMin !== 1 ? 's ' : ' ') + 'remaining');
                    } else {
                        $('#paused-remaining-time').text(playtimeLeftSec + ' seconds remaining');
                    }
                }
                turnerVideo.removeHTML5VideoControls();
                if (pausedAreaDiv) {
                    pausedAreaDiv.fadeIn();
                }
            } else {
                turnerVideo.addHTML5VideoControls();
                if (pausedAreaDiv) {
                    pausedAreaDiv.fadeOut();
                }
            }
            turnerVideo.watchResize(600);
        },
        /**
         * Plays the currently loaded video
         */
        play: function() {
            if (tnVars.pageStateChanges.watchOnAppModalShown) {
                showMode('full');
                turnerVideo.togglePauseState(true);
                return;
            }

            if (cvpPlayStarted) {
                turnerVideo.showPlayer();
                turnerVideo.player.resume();
            } else if (fullEpId) {
                turnerVideo.showPlayer();
                turnerVideo.playFullEp(fullEpId);
            } else if (clipId) {
                turnerVideo.showPlayer();
                turnerVideo.playClip(clipId);
            } else {
                Tn.showDefaultVideo();
            }
            // Handles the case where its hard to get a event during html5 ads.  This is called from playbar button
            if(vidObject && typeof(vidObject) == 'object'){
                vidObject.paused = false;
            }
            playButton.css("display", "none");
            pauseButton.css("display", "block");
            turnerVideo.togglePauseState(false);
        },
        /**
         * Resumes the currently loaded video and sets the page presentation as needed
         */
        resume: function() {
            turnerVideo.player.resume();
            // Handles the case where its hard to get a event during html5 ads.  This is called from playbar button
            if(vidObject && typeof(vidObject) == 'object'){
                vidObject.paused = false;
            }
            playButton.css("display", "none");
            pauseButton.css("display", "block");
            turnerVideo.togglePauseState(false);
        },
        /**
         * Seeks the video using the offset and full width
         * The percentage is calculated by pos * 100 / fullWidth.
         */
        seek: function(pos, fullWidth) {
            if (cvpPlayStarted && !cvpInAds) {
                if (tveModeGlobal === 'liveTVE') {
                    return;
                }
                // turnerVideo.player.getDuration() is returning zero for html5 player
                var theDuration = (turnerVideo.player.getDuration())?turnerVideo.player.getDuration():
                        (Tn.Users.prefs.currentVideo && Tn.Users.prefs.currentVideo.duration)?Tn.Users.prefs.currentVideo.duration:0,
                    vidPos = pos * theDuration / fullWidth;
                turnerVideo.showPlayer();
                turnerVideo.player.seek(vidPos);
            }
        },
        /**
         * Seeks 10 seconds into the past of the currently playing video
         */
        quickSeekBack: function() {
            if (cvpPlayStarted && !cvpInAds) {
                turnerVideo.showPlayer();
                turnerVideo.player.seek(turnerVideo.player.getPlayhead() - 10);
            }
        },
        /**
         * Plays the clip specified by the id
         * @param {String} clipId The clip to be played
         */
        playClip: function(clipId) {
            clipId = parseInt(clipId, 10);
            usingAuthentication = false;
            turnerVideo.player.play("&id=" + clipId, "");
        },
        /**
         * Plays full episode content specified by the id
         * @param {String} titleId The video to be played
         */
        playFullEp: function(titleId) {
            fullEpId = titleId;
            usingAuthentication = true;
            var noAuth = $('#page-video').attr("isAuthRequired") === "false" ? true : false;
            if (noAuth) {
                usingAuthentication = false;
                turnerVideo.player.play(titleId, "");
            } else {
                Tn.Auth.checkAuthorization(titleId);
            }
        },
        /**
         * Plays the queued up full episode with the proper authorization
         * @param {Object} accessToken The authorization token
         */
        playWithToken: function(accessToken) {
            if (fullEpId && typeof accessToken === 'object') {
                console.log("accessToken=" + accessToken);
                fullEpId = parseInt(fullEpId, 10);

                var live = false;
                switch (fullEpId) {
                    case videoFeedWest:
                        live = true;
                        ssid = ssidWest;
                        break;
                    case videoFeedEast:
                        live = true;
                        ssid = ssidEast;
                        break;
                }
                if (live) {
                    fullEpId = "&id=" + fullEpId;
                }
                turnerVideo.player.play(fullEpId, {
                    'accessToken': accessToken.accessToken,
                    'accessTokenType': accessToken.accessTokenType
                });
                fullEpId = null;
            } else if (cvpPlayStarted) {
                turnerVideo.player.resume();
            }
        },
        watchResize: function(timeToWatch) {
            this.endTime = new Date().getTime() + timeToWatch;
            this.onResizeTimer();
        },
        onResizeTimer: function() {
            if (this.videoTimer) {
                clearTimeout(this.videoTimer);
                delete this.videoTimer;
            }

            this.resize();
            if (new Date().getTime() > this.endTime) {
                return;
            }
            this.videoTimer = setTimeout($.proxy(this.onResizeTimer, this), 10);
        },

        updateSplashSize: function() {
            var splash = $('#loading-splash');
            var lw = splash.width();
            var lh = splash.height();
            var nw, nh;
            nw = lw;
            nh = lw * 360 / 640;

            // if (nh < lh && $(window).width() > 600 ) {
            //     nh = lh;
            //     nw = lh * 640 / 360;
            // }
            $('#loading-splash-image').width(nw).height(nh).css({
                'margin-left': -nw / 2,
                'margin-top': -nh / 2
            });
        },
        /**
         * removeSoloSkin runs on a timer that tests whether the skin has been removed by freewheel
         * freewheel will remove the skin code from the container (_fw_container_fw_tnt_skin_slot)
         * but does not remove the bg img from the videoSkinSelector
         * @return {[type]} [description]
         */
        removeSoloSkin: function() {
            if (turnerVideo.removeSoloSkinTimer) {
                clearTimeout(turnerVideo.removeSoloSkinTimer);
            }
            var contId = window.siteDefaults.name.toLowerCase() === 'tnt' ? '_fw_container_fw_tnt_skin_slot' : '_fw_container_fw_tbs_skin_slot';
            if ($('#' + contId).find('iframe').length === 0) {
                console.log('removeSoloSkin: remove');
                window.turnerVideoPageObj.resetBackGroundSkin();
            } else { // Should be in by 10 seconds
                //console.log('skin dom still full');
                turnerVideo.removeSoloSkinTimer = setTimeout(turnerVideo.removeSoloSkin, 1000);
            }

            
        },
        /**
         * displaySoloSkinAd is to be directly called by a video skin that is not associated with ad creative 
         * there are no events fired from CVP for this type of non-video ad
         * @return {[type]} [description]
         */
        displaySoloSkinAd: function(){
            //turnerVideo.resize();
            turnerVideo.wait4Skin(0, true);  //To see full skin
            turnerVideo.removeSoloSkinTimer = setTimeout(turnerVideo.removeSoloSkin, 1000);
        },
        wait4Skin: function(attempts, closeRRIfHasBackgroundImage) {
            attempts++;
            if(turnerVideo.wait4SkinTimer){
                clearTimeout(turnerVideo.wait4SkinTimer);
            }
            if (window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector)) {
                turnerVideo.resize();
                var backgroundImage = window.turnerVideoPageObj.getBackgroundImage(turnerVideo.videoSkinSelector);
                if (Tn.gup('norr', backgroundImage) === '1' || closeRRIfHasBackgroundImage) {
                    closeRail(); //To see full skin
                } else {
                    openRail();
                }
            } else if (attempts < 20) { // Should be in by 10 seconds
                turnerVideo.wait4SkinTimer = window.setTimeout(function() {
                    turnerVideo.wait4Skin(attempts, closeRRIfHasBackgroundImage);
                }, 500);
            }
        },
        /**
         * Updates the video to the current dom dimensions
         */
        resize: function() {
            // Always updated the splash size even if CVP is not ready
            turnerVideo.updateSplashSize();

            //console.log("resize");
            if (!cvpReady) {
                return;
            }
            updateSize();

            //var w = playerDiv.width();
            //var h = playerDiv.height();
            //
            var w = playerWrapper.width();
            var h = playerWrapper.height();
            var ww = w;
            var hh = h;
            var top = 0;
            var left = 0;
            var wWidth = $(window).width();
            var wHeight = $(window).height();
            var videoWidth = turnerVideo.player.getContentWidth();
            var videoHeight = turnerVideo.player.getContentHeight();
            var videoSkinDiv = $(turnerVideo.videoSkinSelector);
            var videoSkinPatchDiv = $(turnerVideo.videoSkinPatchSelector);
            if (videoWidth === 0 || videoHeight === 0) { //assume 16:9
                videoWidth = 640;
                videoHeight = 360;
            }
            var scale = Math.min(ww / videoWidth, hh / videoHeight);
            ww = videoWidth * scale;
            hh = videoHeight * scale;
            top = (h - hh) / 2;
            left = (w - ww) / 2;
            ww = Math.floor(ww);
            hh = Math.floor(hh);
            top = (wWidth <= 687 || wHeight <= 687)?0:Math.floor(top);
            left = Math.floor(left);
            var topString = top.toString() + "px";
            var leftString = left.toString() + "px";
            //console.log("ww: " + ww + " hh: " + hh);
            if (ww < 160) {
                ww = 160;
            }
            if (hh < 160) {
                hh = 160;
            }

            var cvpWidth = ww,
                cvpHeight = hh,
                skinH,
                skinW, ww2, hh2,
                skinRightClickDiv,
                skinLeftClickDiv;
            if (wWidth > turnerVideo.screenWidthTooSmallForSkin && window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector)) {
                var backgroundImage = window.turnerVideoPageObj.getBackgroundImage(turnerVideo.videoSkinSelector);
                skinRightClickDiv = $('#rightclick');
                skinLeftClickDiv = $('#leftclick');

                playerWrapper.addClass('hasSkin');
                playerDiv.addClass('hasSkin');
                $('#page-video').addClass('hasSkin');

                var isSetHt = Tn.gup('h', backgroundImage);
                if (isSetHt === '1' || isSetHt === 'true') {
                    // h is the height of the player wrapper
                    skinH = h;
                    skinW = (64 / 31) * skinH; // Width calculated from aspect ratio of the skin
                } else {
                    // wWidth is the width of the screen
                    skinW = wWidth;
                    skinH = (31 / 64) * skinW; // Height calculated from aspect ratio of the skin
                }
                scale = Math.min(wWidth / videoWidth, h / videoHeight);
                ww2 = videoWidth * scale;
                hh2 = videoHeight * scale;

                /*
                cvpWidth = 0.85 * ww2;
                cvpHeight = 0.85 * hh2;
                */

                
                if (cvpWidth > ww) {
                    cvpHeight = Math.round((ww * cvpHeight) / cvpWidth);
                    cvpWidth = ww;
                }

                // 390 is the amount of padding on the player-wrapper when the RR is open
                // 30 is the amount of left margin when the skin is present
                // 50 is the amount of the top margin plus 20 to try to give 20px at the bottom of the video
                var maxSizeOfCVPWithSkin = wWidth - 390 - 30;
                var maxHeightOfCVPWithSkin = h - 50;
                if (cvpWidth > maxSizeOfCVPWithSkin) {
                    cvpHeight = Math.round((maxSizeOfCVPWithSkin * cvpHeight) / cvpWidth);
                    cvpWidth = maxSizeOfCVPWithSkin;
                } else if (cvpHeight > maxHeightOfCVPWithSkin) {
                    cvpWidth = Math.round((maxHeightOfCVPWithSkin * cvpWidth) / cvpHeight);
                    cvpHeight = maxHeightOfCVPWithSkin;
                }
         
                setTheSizingClass(playerWrapper, cvpHeight);
                pausedAreaDiv.width(cvpWidth);
                pausedAreaDiv.height(cvpHeight);
                /*
                playerWrapper.addClass('hasSkin');
                playerDiv.addClass('hasSkin');
                $('#page-video').addClass('hasSkin');
                */
                // Had to put the div containing the video skin outside the div with the cvp because the cvp was getting corrupted
                // and the next video would not play
                videoSkinDiv.show();
                //videoSkinDiv.width(ww).height(hh);
                videoSkinDiv.width(skinW).height(skinH);
                // videoSkinDiv.css("margin-top", topString);
                // videoSkinDiv.css("margin-left", leftString);

                videoSkinPatchDiv.show();
                skinRightClickDiv.css("left", (cvpWidth + 10) + 'px');
                skinRightClickDiv.css("height", (cvpHeight + 10) + 'px');
                skinLeftClickDiv.css("top", (cvpHeight + 10) + 'px');
                // videoSkinPatchDiv.css("margin-top", topString);
                // videoSkinPatchDiv.css("margin-left", leftString);
                videoSkinPatchDiv.css("max-height", cvpHeight.toString() + "px");
            } else {
                setTheSizingClass(playerWrapper, cvpHeight);
                playerDiv.css("margin-top", topString);
                playerDiv.css("margin-left", leftString);
                pausedAreaDiv.width('auto');
                pausedAreaDiv.height('auto');
                pausedAreaDiv.css("margin-top", topString);
                pausedAreaDiv.css("margin-left", leftString);
                playerWrapper.removeClass('hasSkin');
                playerDiv.removeClass('hasSkin');
                $('#page-video').removeClass('hasSkin');
                videoSkinDiv.hide();
                videoSkinPatchDiv.hide();
            }
            turnerVideo.player.resize(cvpWidth, cvpHeight, 0);
            cvpDiv.width(cvpWidth).height(cvpHeight);
            //cvpDiv.css("margin-top", topString);
            //cvpDiv.css("margin-left", leftString);
            playerDiv.width(cvpWidth).height(cvpHeight);
            playerArea.width(cvpWidth).height(cvpHeight);
            //pausedAreaDiv.height(hh);
            if (wWidth <= 600) {
                $('#page-video .freewheelDEAdLocation').hide(); // Hide because no ads will show
            }
        },

        showSplash: function() {
            $('#loading-splash').show();
            doHideSplash = true;
        },

        updateProgress: function(playhead, duration, showProgressOverride) {
            if (!showProgress && !showProgressOverride) {
                return;
            }

            if(Tn.sliderInProgress){
                //console.log('updateProgress return');
                return;
            }
            //console.log('updateProgress');
            if (duration === undefined) {
                duration = 1;
            }
            if (playhead === undefined) {
                playhead = 0;
            }
            if (duration < 1) {
                duration = 1;
            }

            // we want the progress passed into simpleSlider as a decimal not as a percentage
            var progress = playhead / duration;
            Tn.playheadSlider.simpleSlider('setRatio', progress);
            playtimeDone.text(toHHMMSS(playhead.toString()));
            playtimeTogo.text(toHHMMSS((duration).toString()));
            playtimeLeftMin = toHHMMSS(duration - playhead, true);
            playtimeLeftSec = parseInt(duration - playhead, 10);
        },

        updateAdProgress: function(timeLeft) {
            //console.log('updateProgress');

            // timeLeft is the duration - playhead;
            if (timeLeft === undefined) {
                timeLeft = 0;
            }

            // we are figuring out time left of ad play
            var adSecs = $('#adCounterSecs');
            var adMins = $('#adCounterMins');

            var time = toMMSS(timeLeft.toString());
            adSecs.text(time.secs);
            adMins.text(time.minutes);
            //adMins.text(toHHMMSS(duration - playhead, true);
            //playtimeLeftSec = parseInt(duration - playhead, 10);
        },

        /** See Tn.getFeaturedVideos.  
            This is the callback using /service/featureVideos.json as input
         */
        updateTitleHelper: function(videos) {
            try {
                var ep = videos[0],
                    seasonNo = '',
                    episodeNo = '',
                    descriptor = 'Featured Video:',
                    duration = 0,
                    type = '',
                    title = '';
                if (typeof(ep) === 'object') {
                    title = (ep.showName && ep.showName.length > 0) ? ep.showName : (ep.title) ? ep.title : '';
                    if (ep.prettyURL && ep.prettyURL.indexOf('extras') > -1) {
                        seasonNo = 'Extra';
                        type = 'clip';
                    } else {
                        if (ep.episodeNo && !isNaN(parseInt(ep.episodeNo, 10))) {
                            episodeNo = 'Episode ' + parseInt(ep.episodeNo, 10);
                        } else if (typeof(ep.episodeNo) === 'string' && ep.episodeNo.length > 0) {
                            episodeNo = ep.episodeNo;
                        }
                        if (ep.seasonNo && !isNaN(parseInt(ep.seasonNo, 10))) {
                            seasonNo = 'Season ' + parseInt(ep.seasonNo, 10);
                        } else if (typeof(ep.seasonNo) === 'string' && ep.seasonNo.length > 0) {
                            seasonNo = ep.seasonNo;
                        }
                        if (ep.contentTypeName) {
                            type = ep.contentTypeName;
                        }

                    }
                    if (ep.prettyURL && ep.prettyURL.indexOf('movies') > -1) {
                        title = (ep.title && ep.title.length > 0) ? ep.title : title;
                    }
                    if (ep.duration) {
                        duration = ep.duration;
                    }
                }
                window.turnerVideo.updateTitle(title, seasonNo, episodeNo, duration, type, null, descriptor);
            } catch (e) {}
        },

        updateTitle: function(title, season, episode, duration, type, playhead, descriptor) {
            if (episode === undefined || episode === null) {
                episode = '';
            }
            if (season === undefined || season === null) {
                season = '';
            }
            if (descriptor === undefined || descriptor === null) {
                descriptor = '';
            }
            if (duration === undefined || duration === null) {
                duration = 0;
            }
            if (playhead === undefined || playhead === null) {
                playhead = 0;
            }


            /**
             * we are tracking the state of the playbar text so that when we come back to a video page during session
             * by clicking the global playbar, we know if it was an ad or content that was playing
             * if the video is in mid play, but is paused, we don't get the contentPlay or adPlay event when we resume
             * so we need to track by the playhead which for ads does not include the adtype
             * see updateAdPlaybar() for writing the ad playbar text
            */
                
            if(descriptor.toLowerCase().indexOf('featured') !== -1){
                playbarState = 'featured';
            } else if(descriptor.toLowerCase().indexOf('continue') !== -1){
                playbarState = 'continue';
            } else {
                playbarState = 'playing';
            }

            // we are pulling the data control data from the right rail info panel
            
            $(".video-meta .descriptor").text(descriptor).removeClass('tn-hidden');
            if(type === 'loading'){
                $(".video-meta .descriptor").addClass('loading');
            } else {
                $(".video-meta .descriptor").removeClass('loading');
            }
            $(".video-meta #divider").removeClass('tn-hidden');
            $(".video-meta .title").text(title);
            $('.video-meta .season span').text(season.replace('Season ','S'));
            $('.video-meta .ep span').text(episode.replace('Episode ','E'));

            playtimeDone.text(toHHMMSS(playhead));
            playtimeTogo.text(toHHMMSS(duration));
            
            if(type === 'clip'){
                // we always want a clip to start at the beginning
                // we are setting that here, and need to set showProgress to false
                // there is a race condition between stopping the video and getting here
                // and the last onContentPlayhead event (which was setting the progress bar back to where the clip stopped)
                turnerVideo.updateProgress(0, duration);
                showProgress = false;
            } 

            //if (type === 'liveTVE' || (season.length === 0 && episode.length === 0)) {
            if ((season.length === 0 && episode.length === 0)) {
                $('.video-meta .wrapper').hide();
            } else {
                $('.video-meta .wrapper').show();
            }

            if (type === 'liveTVE') {
                var upNextTitle = $('#pane-info .upnextvideotitle').text();
                $('.video-meta .playtime').hide();
                $('.video-meta .upnextvideo').html('');
                $('.video-meta .upnextvideo').html('Up Next: ' + upNextTitle);
            } else {
                if(duration === 0 && playhead === 0){
                    $('.video-meta .playtime').hide();
                } else {
                    $('.video-meta .playtime').show();
                }
                $('.video-meta .upnextvideo').text('');
            }
        },
        updatePlaybar: function(videoState, descriptor){
            var playbarVideo;

            if(videoState.tveMode === 'liveTVE' ){
                playbarVideo = liveVideo;
                turnerVideo.updateTitle($('#pane-info h1.title').text(), $('#pane-info .season span').text(), $('#pane-info .ep span').text(), null, playbarVideo.tveMode, null, descriptor);
            } else if(videoState.tveMode === 'clip'){
                playbarVideo = clipVideo;
                turnerVideo.updateTitle(videoState.title, videoState.season, videoState.episode, videoState.duration, videoState.tveMode, videoState.playhead, descriptor);
            } else {
                playbarVideo = Tn.Users.prefs.currentVideo;
                turnerVideo.updateTitle(playbarVideo.title, playbarVideo.season, playbarVideo.episode, playbarVideo.duration, playbarVideo.tveMode, playbarVideo.playhead, descriptor);
            }
            /*
            if(videoState.tveMode !== 'liveTVE'){
                playbarVideo = Tn.Users.prefs.currentVideo;
                turnerVideo.updateTitle(playbarVideo.title, playbarVideo.season, playbarVideo.episode, playbarVideo.duration, playbarVideo.tveMode, playbarVideo.playhead, descriptor);
            } else{
                playbarVideo = liveVideo;
                turnerVideo.updateTitle($('#pane-info h1.title').text(), $('#pane-info .season span').text(), $('#pane-info .ep span').text(), null, playbarVideo.tveMode, null, descriptor);
            }
            */
        },
        updateAdPlaybar: function(duration, adType){
            // TODO: will this work for live tv?
            adType = typeof(adType) !== 'undefined' ? adType : '';
            var playbarMsg = '';
            // when calling this from onAdPlayhead, which we will if the ad was playing when we left the page
            // and then we click global play to resume, we will not have the adType so we base on duration only
            if(adType === 'preroll'){
                playbarMsg = 'Your program will start in <span id="adCounterSecs"></span> seconds.';
            } else if(adType === 'midroll' && duration > 60){
                playbarMsg = 'Your program will resume in <span id="adCounterMins"></span> minutes and <span id="adCounterSecs"></span> seconds.';
            } else if(duration < 60){
                playbarMsg = 'Your program will resume in <span id="adCounterSecs"></span> seconds.';
            } else {
                playbarMsg = 'Your program will resume in <span id="adCounterMins"></span> minutes and <span id="adCounterSecs"></span> seconds.';
            }
            playbarState = 'ad';

            $('.video-meta .descriptor').text('').addClass('tn-hidden');
            $('.video-meta .title').text('Advertisement');
            $('.video-meta .season span').text('').html(playbarMsg);
            $('.video-meta .ep span').text('');

            $('.video-meta .wrapper').show();
        },
        restoreState: function(currentVideo) {
            //console.error("Found STATE", currentVideo);
            if (!currentVideo || !currentVideo.title) {
                Tn.getFeaturedVideos(window.turnerVideo.updateTitleHelper);
                return;
            }
            var descriptor = 'Continue Watching:';
            turnerVideo.savedState = $.extend({}, currentVideo);

            turnerVideo.updateTitle(currentVideo.title, currentVideo.season, currentVideo.episode, currentVideo.duration, currentVideo.tveMode, currentVideo.playhead, descriptor);
            turnerVideo.updateProgress(currentVideo.playhead || 0, currentVideo.duration || 0, true);
        },

        launchClip: function(clip) {
            $.get('/service/cvpXml.xml?titleId=&id=' + clip).success(function(xml) {
                var json = $.xml2json(xml);
                var files = json['#document'].video.files.file;
                var images = json['#document'].video.images.image;
                var file, selectedBitrate, poster, pw;
                $.each(files, function(key, f) {
                    if (!file) {
                        file = f._;
                        selectedBitrate = 'unknown';
                        return;
                    }
                    var bitrate = f.$.bitrate || '';
                    bitrate = bitrate.toLowerCase();
                    if (tnVars.isIPhone && bitrate === 'iphone') {
                        file = f._;
                        selectedBitrate = bitrate;
                    }
                    if (tnVars.isIPad && bitrate === 'ipad') {
                        file = f._;
                        selectedBitrate = bitrate;
                    }
                    if (tnVars.isIPod && bitrate === 'ios') {
                        file = f._;
                        selectedBitrate = bitrate;
                    }
                    if (tnVars.isAndroid && bitrate === 'androidphone') {
                        file = f._;
                        selectedBitrate = bitrate;
                    }
                });
                $.each(images, function(key, f) {
                    if (!poster) {
                        poster = f._;
                        pw = parseInt(f.$.width, 10) || 0;
                        return;
                    }
                    var nw = parseInt(f.$.width, 10) || 0;
                    if (nw > pw) {
                        poster = f._;
                        pw = nw;
                    }
                });

                console.error("Found files", file, poster, json, files, images);
                poster = '/images/no-image.gif';
                var html5 = $('#clip-video');
                if (html5.length === 0) {
                    html5 = $(Tn.fm('<div class="video-container"><video id="clip-video" src="{file}" width=640 height=360 poster="{poster}" webkit-playsinline></video></div>', {
                        file: file,
                        poster: poster
                    }));
                    html5.appendTo($('#playerDiv'));
                    // html5.on({
                    //     touchstart: function(e) {
                    //         e.preventDefault();
                    //         this.play();
                    //     },
                    //     play: function() {
                    //         $(this).removeAttr("poster");
                    //     }
                    // });
                } else {
                    html5.attr('src', file).attr('poster', poster);
                }

                //Tn.launchProtocol(file);
                //window.location.href = file;
            }).fail(function() {
                Tn.alert('Failed to load video');
            });
        },

        showClipComments: function() {
            var foundShow = 0,
                paths = window.currentPageUrl.split('/');
            for (var i = 0; i < paths.length - 1; i++) {

                // Locate the show name in the video url and grab the show info
                if (paths[i] === 'videos') {
                    foundShow = i + 1;
                    break;
                }
            }

            // Didn't find the show name
            if (foundShow < 1) {
                return;
            }

            // Fetch the show via a JSON call
            $.getJSON('/service/shows/byName/' + paths[foundShow] + '.json').success(function(show) {
                if (!show.series || !show.series.arktanAll || show.series.arktanAll.length === 0) {
                    return;
                }
                $('#page-video').find('aside .nav a[paneid="pane-share"]').show();
                Tn.showComments(show.series.arktanAll);
            });
        },
        closeRailHelper: function() {
            closeRail();
        },
        openRailHelper: function() {
            openRail();
        },
        /**
         * Set anything for a replayed video that won't be set in load()
         */
        replaySameVideo: function(){
            doVideoCompleteEvent = true;
        },
        callTwitterPixel: function(videoState){
            var title = videoState.title.toLowerCase();
            var twttr = window.twttr;
            if(title === 'the last ship'){
                twttr.conversion.trackPid('l5gpf');
            } else if(title === 'legends'){
                twttr.conversion.trackPid('l5qe1', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'murder in the first'){
                twttr.conversion.trackPid('l5qdz', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'the librarians'){
                twttr.conversion.trackPid('l5qeb', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'proof'){
                twttr.conversion.trackPid('l5qdx', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'public morals'){
                twttr.conversion.trackPid('l5zj6', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'american dad'){
                twttr.conversion.trackPid('l5qe2', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'meet the smiths'){
                twttr.conversion.trackPid('l5qe6', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'clipped'){
                twttr.conversion.trackPid('l5zj3', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else if(title === 'angie tribeca'){
                twttr.conversion.trackPid('l5zj5', { tw_sale_amount: 0, tw_order_quantity: 0 });
            } else {
                //console.log('no tw tracking for ' + title);
                return;
            }
            //console.log('sent tw pixel for ' + title);
        },
        /**
         * Initializes the video player
         */
        load: function(options) {
            lastSavedInitOptions = $.extend({}, options);
            $('body').removeClass('vid-loaded');

            // Delete any upnext video 
            turnerVideo.cancelUpNext();

            // Removed our stored poster image
            delete turnerVideo.posterImage;

            showMode('full');

            // Toggle whether or not to show the chat pane
            if (options.clipId) {
                turnerVideo.showClipComments(options.clipId);
            }

            turnerVideo.posterImage = '';
            if (options.theImage) {
                turnerVideo.posterImage = options.theImage;
            }

            if (isMobile) {
                $('#loading-splash-image').attr('src', '');

                // we are adding the mobile close button for the right rail
                $('#page-video aside.in-player-tray .mobilecloseRR').remove();
                $('#page-video aside.in-player-tray').append('<div class="mobilecloseRR"></div>');
                $('#page-video .mobilecloseRR').on('touchend', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    // Have it behave like a click to keep things the same
                    var infoPane = $('#page-video aside a[paneid="pane-info"]'),
                        sharePane = $('#page-video aside a[paneid="pane-share"]');
                    if (infoPane.hasClass('active')) {
                        infoPane.trigger('click');
                    } else if (sharePane.hasClass('active')) {
                        sharePane.trigger('click');
                    } else {
                        closeRail();
                    }
                });
                // we will show mobilecloseRR if the screen with is < 370;
                // we check the screen width on orientation changein global.js and
                // set the show class according to the new width
                if (tnVars.windowW < 370) {
                    $('#page-video aside.in-player-tray .mobilecloseRR').addClass('show');
                } else {
                    $('#page-video aside.in-player-tray .mobilecloseRR').removeClass('show');
                }

                if (options.theImage) {
                    $('#loading-splash-image').attr('src', options.theImage);
                    $('#loading-splash').removeClass('loading');
                    turnerVideo.posterImage = options.theImage;
                    $('#cvp_1').attr('poster', turnerVideo.posterImage);
                    turnerVideo.watchResize(250);
                }
                if (window.adHelper) {
                    //Turn off video skin sync ad
                    window.window.adHelper.manageSkinSyncAds([], $('#page-video .player-wrapper'));
                }

            }
            doVideoCompleteEvent = true;
            usingAuthentication = true;
            turnerVideo.useRestore = true;
            // If the profile dialog is shown, then hide it
            $('#profile-dialog').modal('hide');

            doHideSplash = true;
            //$('#loading-splash').toggleClass('mobile', isMobile).show();

            // If we're on mobile, the right rail is too large, so close it automatically
            if (isMobile) {
                if (!options.clipId) {
                    tnVars.pageStateChanges.watchOnAppModalShown = true;
                    $('#mobile-app-dialog').modal('show');
                    turnerVideo.togglePauseState(true);
                    if($.cookie('rememberDeepLink')){
                        $('#mobile-app-dialog .download').trigger('click', {'autoClick': true}); //, #mobile-app-dialog .install'
                    }
                    return;
                }
                // else {
                //     turnerVideo.launchClip(options.clipId);
                // }
            }

            if (options) {
                turnerVideo.init(options);
            }
            if (playerLoaded) {
                if (options.videoType !== 'live' && lastTveModeGlobal === 'liveTVE') {
                    turnerVideo.player.stop(); // Patching for http://tickets.turner.com/browse/TENDP-12273
                }
                if (options.clipId) {
                    turnerVideo.playClip(options.clipId);
                } else {
                    turnerVideo.playFullEp(options.fullEpId);
                }
                return;
            }
            playerWrapper = $('#page-video .player-wrapper');
            playerDiv = $('#page-video #playerDiv');
            pausedAreaDiv = $('#pausedAreaDiv');
            pausedSeriesTitle = $('#paused-series-title h2');
            pausedEpisodeTitle = $('#paused-episode-title h2');
            playerLoaded = true;
            // Switch to the testing freewheel suite if cookie is set
            if (Tn.devCVPFromBrowser) {
                context = context + '_dev';
                // $('.player-wrapper .videoSkinArea').parent().bind('DOMNodeInserted DOMNodeRemoved', function(event) {
                //     if (event.type == 'DOMNodeInserted') {
                //         console.log('Content added! Current content:' + '\n\n' + $(this).find('.videoSkinArea').html());
                //     } else {
                //         console.log('Content removed! Current content:' + '\n\n' + $(this).find('.videoSkinArea').html());
                //     }
                // });
            }
            turnerVideo.player = new CVP({
                id: 'cvp_1',
                width: 640,
                height: 360,
                flashVars: {
                    context: context,
                    basePath: '/',
                    site: site,
                    requestTimeout: 10000, // Slow mobile connections.
                    profile: profile
                },
                embed: {
                    containerSwf: 'http://z.cdn.turner.com/xslo/cvp/assets/container/2.0.5.1/cvp_main_container.swf',
                    expressInstallSwf: 'http://z.cdn.turner.com/xslo/cvp/assets/flash/expressInstall.swf',
                    flashVersion: '11.1',
                    options: {
                        quality: 'high',
                        bgcolor: '#000000',
                        allowFullScreen: 'true',
                        allowScriptAccess: 'always',
                        wmode: 'transparent'
                    }
                },
                onPlayerReady: function() {
                    //window.FullscreenMonitorTmp.setup(this); // cvp 2.8.3.4 has this built in
                    if (!isNaN(fullEpId)) {
                        turnerVideo.playFullEp(fullEpId);
                    } else if (!isNaN(clipId)) {
                        turnerVideo.playClip(clipId);
                    }
                },
                onAdSetup: function(){
                    window.AmazonDirectMatchBuy.setAdKeyValuePairs(this);
                    window.AmazonDirectMatchBuy.requestAdRefresh();
                },
                onInstreamAdCuePoint: function(){
                    console.log('testing this to see when it happens');
                },
                onCVPReady: function() {
                    cvpDiv = $('#cvp_1');
                    playerArea = $('#page-video #playerarea'); // Seen in html5 player if available
                    cvpReady = true;
                    turnerVideo.hideHDIcon(); // TENDP-11820: HD icon not used for pHDS
                },
                onContentBegin: function() {
                    cvpPlayStarted = true;
                    cvpInAds = false;
                    turnerVideo.watchResize(1000);
                    $(window).resize(turnerVideo.resize);
                    $('#page-video').addClass('video-playing').removeClass('video-finished');
                    // Wait 10 seconds for sync ad before starting ad reloader.  This will allow us to put ad in immmediately is there is no preroll
                    window.turnerVideoPageObj.firstSyncAdTimer = (new Date()).getTime();
                    setTimeout(window.turnerVideoPageObj.initSyncAd, (window.turnerVideoPageObj.initTrayAdTimer - 3000));
                    setTimeout(window.turnerVideoPageObj.startAdInTrayReloader, window.turnerVideoPageObj.initTrayAdTimer);
                    if ($(window).width() > 600 && !window.turnerVideo.isFullscreen) {
                        window.window.adHelper.manageSyncAds($('#page-video aside .syncAdWrapper'), []);
                        window.turnerVideoPageObj.locateFreewheelSyncAd();
                    }
                    if (this.getPlayerType() === 'html5' && !isNaN(fullEpId)) {
                        turnerVideoPageObj.needFlashHandler(this);
                    }
                },
                onContentError: function(playerId, contentId, errorMessage) {
                    var player = this;
                    console.error('onContentError', errorMessage);
                    window.turnerVideoPageObj.stopAdInTrayReloader();
                    updateState({
                        'playing': false
                    });
                    if (this.getPlayerType() === 'html5' && !isNaN(fullEpId)) {
                        window.setTimeout(function() {
                            turnerVideoPageObj.needFlashHandler(player);
                            $('#cvp_1').removeAttr('controls');
                        }, 0);
                    } else {
                        window.turnerVideoPageObj.contentErrorHandler();
                    }
                },
                onContentValidationFailure: function(playerId, contentId, errorType, data) {
                    if (errorType === "blackout") {
                        //document.getElementById("slate").style.visibility = "visible";
                        if (data.code === 0) { //User is in blacked out region
                            Tn.alert('blackoutMsg');
                        } else { //other blackout service error
                            Tn.alert('blackoutTechIssue');
                        }
                        try {
                            vidObject.blackoutType = "regional blackout";
                            TVE_VideoEvent(vidObject, "tve-live_video-blackout");
                        } catch (e) {}
                    }
                },

                onContentEntryLoad: function(playerId, videoId) {
                    if ($(window).width() > 600) {
                        openRail(true);
                    }

                    showMode('full');
                    $('body').removeClass('adPlaying');
                    var vidObjectJSON = turnerVideo.player.getContentEntry(videoId);
                    //console.log("onContentEntryLoad", arguments);
                    vidObject = $.parseJSON(vidObjectJSON.toString());
                    vidObject.usingAuth = usingAuthentication;
                    lastVideoId = parseInt(videoId, 10);
                    var duration = parseInt(vidObject.trt, 10);
                    playtimeLeftMin = toHHMMSS(vidObject.trt, true);
                    playtimeLeftSec = parseInt(duration, 10);

                    tveModeGlobal = (vidObject.tveMode) ? vidObject.tveMode : "";
                    lastTveModeGlobal = tveModeGlobal;
                    // jhillmann: moved this tveModeGlobal block from below to try to set the type for clips to pass to updateTitle
                    if (tveModeGlobal === "") {
                        tveModeGlobal = 'clip';
                        vidObject.tveMode = 'clip';
                    }

                    // Clear any current ad breaks
                    timeSlider.find('.time-ad-handle').remove();

                    // these elements are created by simpleSlider and may not be available when turnerVideo inits
                    // we will check and define here if necessary
                    timeSliderBut = timeSliderBut.length === 0 ? $("#time-slider").find('.highlight-track') : timeSliderBut;
                    timeSliderHandle = timeSliderHandle.length === 0 ? $("#time-slider").find('.dragger') : timeSliderHandle;
                    // This won't happen per TENDP-12184
                    // if (window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector) ){
                    //     window.turnerVideoPageObj.resetBackGroundSkin();
                    //     turnerVideo.watchResize(1500);
                    // }
                    if (tveModeGlobal === 'liveTVE') {
                        isLiveContentPlay = false;
                        showProgress = true;
                        timeSliderBut.hide();
                        timeSliderHandle.hide();
                        // Switch to the testing freewheel suite if cookie is set
                        if (Tn.devCVPFromBrowser) {
                            turnerVideo.player.switchAdContext('watchlivedev');
                        } else {
                            turnerVideo.player.switchAdContext('watchlive');
                        }
                        turnerVideo.player.setAdSection(ssid); //thisSiteSectionId is defined at page level 
                        //turnerVideo.setAdSection(''); 
                        addLiveStat(lastVideoId);
                    } else {
                        // Switch to the testing freewheel suite if cookie is set
                        if (Tn.devCVPFromBrowser) {
                            turnerVideo.player.switchAdContext('cvpdev');
                        } else {
                            turnerVideo.player.switchAdContext('default');
                        }
                        timeSliderBut.show();
                        timeSliderHandle.show();
                        showProgress = true;
                        // Update our histor of watched videos
                        var franchiseId = (vidObject.franchiseId) ? vidObject.franchiseId : 'na';
                        if(typeof(vidObject.vidType) !== 'undefined' && 
                                (vidObject.vidType.toLowerCase() === 'fullep' || vidObject.vidType.toLowerCase() === 'movies')){
                            addStat(lastVideoId, franchiseId);
                        }
                        

                        // Pull out the ad breaks
                        var actions = vidObject.actions || [],
                            breakSpots = [],
                            adBreakTime = 0;
                        $.each(actions, function(key, action) {
                            if (action.action.type !== 'c4') {
                                return;
                            }
                            adBreakTime += calculateXMLTimeInMS(action.action.end.time) - calculateXMLTimeInMS(action.action.start.time);
                            breakSpots.push(adBreakTime * 0.100 / duration);
                        });
                        breakSpots.pop();
                        $.each(breakSpots, function(key, spot) {
                            timeSlider.find('.slider-time').append('<div class="time-ad-handle" style="left: ' + spot + '%;"></div>');
                        });
                    }
                    /*
                    if (tveModeGlobal === "") {
                        tveModeGlobal = 'clip';
                        vidObject.tveMode = 'clip';
                    }
                    */


                    var history = Tn.Users.getPref('videoHistory', {}),
                        playhead = turnerVideo.getPlayheadHelper(duration, false, true);

                    var myState = {
                        title: $('#pane-info h1.title').text(),
                        season: $('#pane-info .season span').text(),
                        episode: $('#pane-info .ep span').text(),
                        tveMode: tveModeGlobal,
                        duration: duration,
                        playhead: playhead,
                        videoType: vidObject.tveMode
                    };
                    updateState(myState);

                    //var descriptor = 'Now Playing:';
                    //turnerVideo.updateTitle($('#pane-info h1.title').text(), $('#pane-info .season span').text(), $('#pane-info .ep span').text(), duration, tveModeGlobal, playhead, descriptor);

                    if (vidObject.tveMode === 'C3' || vidObject.tveMode === 'C4' || vidObject.tveMode === 'liveTVE') {
                        // authenticated video
                        turnerVideo.player.setAdKeyValue('_fw_ar', '1');
                        turnerVideo.player.setAdKeyValue('_fw_ae', window.fw_ae);
                        if (vidObject.tveMode === 'C3') {
                            turnerVideo.player.switchTrackingContext('short_interval_c3');
                        } else if (vidObject.tveMode === 'C4') {
                            turnerVideo.player.switchTrackingContext('short_interval_c4');
                        }
                    } else {
                        // non-authenticated video
                        turnerVideo.player.setAdKeyValue('_fw_ar', '0');
                        turnerVideo.player.switchTrackingContext('clips');
                    }

                    // we don't need to set the cookie here anymore since the guID is now passed in the ad_policy.xml
                    /*
                    if (window.cnnad_readCookie) {
                        turnerVideo.player.setAdKeyValue("GUID", window.cnnad_readCookie("ug"));
                    }
                    */

                    if (turnerVideo.posterImage) {
                        $('#cvp_1').attr('poster', turnerVideo.posterImage);
                        turnerVideo.watchResize(250);
                    }
                    if (this.getPlayerType() === 'html5') {
                        //video tag poster will display instead
                        hideSplash();
                    }
                    if (isMobile && doInitializeVideoEvents) {
                        doInitializeVideoEvents = false;
                        // $('#cvp_1').on("touchstart", function(event) {
                        //     event.preventDefault();
                        //     event.stopPropagation();
                        //     if (videoState.playing) {
                        //         turnerVideo.pause();
                        //     } else {
                        //         // Trigger a native html5 play
                        //         this.play();
                        //     }
                        // });
                    }

                    // Preload the carousel data for up-next
                    if (!isMobile) {
                        //Wait for the video to load and then prefetch data
                        window.setTimeout(function() {
                            Tn.preloadData();
                        }, 10000); // There should be a preroll
                    }
                },

                onContentPlay: function() {
                    // This won't happen per TENDP-12184
                    // if(window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector) ){
                    //     closeRail(); //Close per TENDP-11822... 
                    // }
                    if(videoState.tveMode === 'liveTVE'){
                        isLiveContentPlay = true;
                    }
                    turnerVideo.resize();
                    //timeSliderBut.css('width', '0%');
                    Tn.playheadSlider.simpleSlider('setRatio', 0);
                    playButton.css("display", "none");
                    pauseButton.css("display", "block");
                    turnerVideo.togglePauseState(false);

                    updateState({
                        'playing': true
                    });

                    //var descriptor = 'Now Playing:';
                    turnerVideo.updatePlaybar(videoState, 'Now Playing:');
                    /*
                    var playbarVideo;
                    if(videoState.tveMode !== 'liveTVE'){
                        playbarVideo = Tn.Users.prefs.currentVideo;
                        turnerVideo.updateTitle(playbarVideo.title, playbarVideo.season, playbarVideo.episode, playbarVideo.duration, playbarVideo.tveMode, playbarVideo.playhead, descriptor);
                    } else {
                        playbarVideo = liveVideo;
                        turnerVideo.updateTitle($('#pane-info h1.title').text(), $('#pane-info .season span').text(), $('#pane-info .ep span').text(), playbarVideo.duration, playbarVideo.tveModeGlobal, playbarVideo.playhead, descriptor);
                    }
                    */
                    turnerVideo.addHTML5VideoControls();

                    // the conversion pixel functions are only defined when directly hitting the video page
                    // the functions should be called after the preroll when the video starts playing
                    if (videoState.fullEpId && window.callFBQ) {
                        window.callFBQ();
                    }
                    
                    if (videoState.fullEpId && window.callFBQ2) {
                        window.callFBQ2();
                    }

                    if (videoState.fullEpId){
                        turnerVideo.callTwitterPixel(videoState);
                    }
                    
                  
                    if (window.callDoubleClickTracking) {
                        window.callDoubleClickTracking();
                    }
                  
                },

                onTrackingPaused: function() {
                    turnerVideo.stopAdPlayheadWorkAroundTimer();
                    vidObject.paused = true;
                },
                onContentPause: function(playerId, contentId, paused) {
                    //var playhead = turnerVideo.getPlayheadHelper(); Was sending this to updateState but cvp resize calls this from our resize call
                    // and it gets the playhead of the last video played.  No added value really
                    turnerVideo.stopAdPlayheadWorkAroundTimer();
                    vidObject.paused = paused;
                    vidObject.tveMode = tveModeGlobal;
                    if (tveModeGlobal === 'clip') {
                        sendVideoEvent(vidObject, "video-pause");
                    } else {
                        TVE_VideoEvent(vidObject, "video-pause");
                    }
                    updateState({
                        'paused': paused,
                        //'playing': false,
                        'duration': (parseInt(vidObject.trt, 10)) ? parseInt(vidObject.trt, 10) : 0
                    });

                    window.turnerVideoPageObj.stopAdInTrayReloader(); // Stop here since with pause and play, we at least need to start over.
                    if (paused) {
                        // putting this here to try to prevent the pause screen from flashing on/off while the live tv stream is loading
                        if(tveModeGlobal === 'liveTVE' && !isLiveContentPlay){
                            console.log('early live pause event sent');
                            return;
                        }

                        playButton.css("display", "block");
                        pauseButton.css("display", "none");
                        turnerVideo.togglePauseState(true);

                        // trying the continue watching analytics call here so we can send one if the player is touched anywhere to pause
                        // not only when clicking the pause button
                        // 
                        // we needed to check to see if we are on the video page
                        // this call was being sent if we clicked away from a video since the video is paused (except for live)
                        // when we navigate to another page
                        // NOTE - if you change the string 'video continue watching', you also have to change it in
                        // parseAnalytics()
                        if (Tn.currentPage === "page-video") {
                            Tn.parseAnalytics({
                                "url_section": "/",
                                "section": "videos",
                                "subsection": "videos:continue watching",
                                "template_type": "adbp:video",
                                "content_type": "other:overlay",
                                "search.keyword": "",
                                "search.number_results": "",
                                "friendly_name": "video continue watching",
                                "series_name": window.turner_metadata.series_name
                            }, false);
                        }
                    } else {
                        playButton.css("display", "none");
                        pauseButton.css("display", "block");
                        turnerVideo.togglePauseState(false);
                        window.turnerVideoPageObj.startAdInTrayReloader();
                    }
                },
                onContentBuffering: function(playerId, contentId, buffering) {
                    vidObject.buffering = buffering;
                    vidObject.tveMode = tveModeGlobal;
                    if (tveModeGlobal === "clip") {
                        sendVideoEvent(vidObject, "video-buffer");
                    } else {
                        TVE_VideoEvent(vidObject, "video-buffer");
                    }
                },
                onTrackingContentSeek: function() {
                    if (tveModeGlobal === 'clip') {
                        sendVideoEvent(vidObject, "video-scrub");
                    }
                },
                onContentBitrateChangeEnd: function() {
                    // if (Tn.Users.getPref("hd", true)) {
                    //     turnerVideo.player.setAutoBitrateSwitch(true);
                    // }
                },
                /*
                for liveTV, the ad playhead and content playhead will both be running at the same time during ads
                */
                onContentPlayhead: function(playerId, contentId, playhead, duration, currentPlayTime) {
                    // iPhone html5 native player may have had the playClip/playFullEp but they will still have to hit the play button.
                    // Since vidObject.paused is undefined on init, we define it on the first onAdPlay
                    if(typeof(vidObject.paused) === 'undefined'){
                        vidObject.paused = false;
                        turnerVideo.togglePauseState(false);
                    }
                    
                    // this starts off as undefined for live tv
          
                    if(typeof(vidObject.adType) !== 'undefined' && vidObject.adType !== '' && tveModeGlobal === 'liveTVE'){

                    } else {
                        
                        if (removeAdDiv && tveModeGlobal === 'liveTVE') {
                            console.log('onContentPlayhead: remove ad div live');
                            removeAdDiv = false;
                            $('body').removeClass('adPlaying');
                            turnerVideo.updatePlaybar(videoState, 'Now Playing:');
                        } else if(playbarState !== 'playing' && !vidObject.paused){
                            turnerVideo.updatePlaybar(videoState, 'Now Playing:');
                        }
                    }

                    if (window.turnerVideoPageObj.contentErrorMsgShown || window.turnerVideoPageObj.contentErrorHappened) {
                        window.toastr.clear();
                        window.toastr.options.onclick = undefined;
                        window.turnerVideoPageObj.contentErrorHappened = false;
                        window.turnerVideoPageObj.contentErrorMsgShown = false;
                    }
                    if (turnerVideo.justRequestedSeekedTo > 0 && turnerVideo.justRequestedSeekedToAttempts < 6) {
                        var playheadDelta = Math.abs((playhead - turnerVideo.justRequestedSeekedTo));
                        if (playheadDelta > 35) {
                            console.log('Try and push the player to ' + turnerVideo.justRequestedSeekedTo);
                            turnerVideo.player.seek(turnerVideo.justRequestedSeekedTo); // Try it again
                            turnerVideo.justRequestedSeekedToAttempts++;
                        } else {
                            turnerVideo.justRequestedSeekedTo = -1;
                            turnerVideo.justRequestedSeekedToAttempts = 0;
                        }
                    } else {
                        turnerVideo.justRequestedSeekedTo = -1;
                        turnerVideo.justRequestedSeekedToAttempts = 0;
                    }

                    // Ensure we remove the ad playing class if our play head is giving us data once again
                    if (removeAdDiv && tveModeGlobal !== 'liveTVE') {
                        //console.log('onContentPlayhead: remove ad div NOT live');
                        removeAdDiv = false;
                        $('body').removeClass('adPlaying');
                        turnerVideo.updatePlaybar(videoState, 'Now Playing:');
                        
                    }
                    // If we're not currently on the video page, then pause/stop the video
                    if (Tn.currentPage !== "page-video") {
                        turnerVideo.badVideoStateCount++;
                        if (turnerVideo.badVideoStateCount > 6) {
                            if (tveModeGlobal !== 'liveTVE') {
                                turnerVideo.pause();
                            } else {
                                turnerVideo.pauseLive();
                            }
                        }
                        if (turnerVideo.badVideoStateCount > 6) { // Reflects a weird cvp issue.
                            //window.turnerVideo.player.isPaused inside framework.js ( finalizePage: ) is returning false positives.  A catch all.
                            console.log('onContentPlayhead: Stopped video since we are on Tn.currentPage=' + Tn.currentPage + ' Dont expect to get here because finalizePage() handles it.  So catch all here.');
                        }

                        if (!Tn.currentUser) {
                            if (!$.cookie('hidewatch')) {
                                $('#continue-watching-dialog').modal('show');
                            }
                            //Tn.confirm("Sign in to continue watching <b>" + videoState.title + "</b> later.<br>Tap me to do so now.", function() {
                            //Tn.Users.logIn();
                            //});
                        }
                    } else {
                        turnerVideo.badVideoStateCount = 0;
                    }

                    // If we're currently showing the video splash, hide it
                    if (doHideSplash) {
                        hideSplash();
                    }

                    // Check to see if we should restore at our previous location
                    var restoreSeekTo = false;
                    if (turnerVideo.useRestore) {
                        turnerVideo.useRestore = false;

                        var history = Tn.Users.getPref('videoHistory', {}),
                            videoHistoryKey = (lastVideoId) ? Tn.Users.vidHistoryPrefix + lastVideoId : 'notfound';
                        if (history[videoHistoryKey]) {
                            if (history[videoHistoryKey].pg && history[videoHistoryKey].pg > 0 && history[videoHistoryKey].pg < 99) {
                                var seekToTime = duration * history[videoHistoryKey].pg / 100.0;

                                // We're not going to seek if we're less than 5 seconds into a video
                                if (seekToTime > 5) {
                                    turnerVideo.player.seek(seekToTime);
                                    turnerVideo.justRequestedSeekedTo = seekToTime;
                                    turnerVideo.justRequestedSeekedToAttempts = 0;
                                    restoreSeekTo = true;
                                    if (duration > 0) {
                                        turnerVideo.updateProgress(seekToTime, duration);
                                    }
                                }
                            }
                        }
                    } else {
                        // We don't want to flood Gigya with requests, so record our play state every 30 seconds
                        if (Math.abs((videoState.playhead || 0) - playhead) > 15) {
                            updateState({
                                'playhead': playhead,
                                'duration': duration
                            });
                        }

                        // Show the up-next screen
                        var actualTimeLeft = duration - playhead; // Patching for http://tickets.turner.com/browse/TENDP-12273.  Playhead can be wrong
                        if (duration > 0 && actualTimeLeft > 0 && actualTimeLeft < (Tn.upNextTimeInSeconds + 0.99)) {
                            if (tveModeGlobal !== 'liveTVE') {
                                turnerVideo.showMode('upnext');
                            }
                        }
                    }
                    vidObject.playhead = playhead;
                    vidObject.currentPlayTime = currentPlayTime;
                    if (duration > 0 && !restoreSeekTo) {
                        turnerVideo.updateProgress(playhead, duration);
                    } 

                    // setting showProgress back to true incase it was defined as false by updateTitle for a clip
                    showProgress = true;
                    // NOTE - we cannot use the vidObject.trt value for duration because it does not account for airtime ads
                    // for an hour show the trt is 42 minutes
                },
                onContentEnd: function() {
                    cvpPlayStarted = false;
                    //vidObject = null;

                    playButton.css("display", "block");
                    pauseButton.css("display", "none");
                    //turnerVideo.togglePauseState(true);
                    var myState = {
                        'playing': false,
                        'pg': 100
                    };
                    if (videoState && videoState.duration) {
                        myState = $.extend(myState, {
                            'playhead': videoState.duration
                        });
                    }
                    updateState(myState);

                    $('#page-video').removeClass('video-playing').addClass('video-finished');
                },
                onLiveShowChange: function() {
                    console.log("onLiveShowChange");
                    // this is where we need to check the airing date and if it is different than the last one
                    // we need to pull the lmdb feed for the right rail data.
                    // i see this event being called at beginning of new show and after ad breaks
                    window.refreshLiveStreamData = true;
                    // adding a new defer analytics arg - TENDP-12158
                    Tn.showPlayerInternal(window.location.href, true);
                },

                onAdPlay: function(playerId, token, mode, id, duration, blockId, adType) {
                    if ($(window).width() <= 600) {
                        // Sync ads won't play on small screens
                        window.turnerVideoPageObj.firstSyncAdShown = false;
                    } else {
                        window.turnerVideoPageObj.firstSyncAdShown = true;
                    }
                    console.log('onAdPlay: ' + adType);
                    cvpInAds = true;

                    turnerVideo.updateAdPlaybar(duration, adType);
                    
                    turnerVideo.removeHTML5VideoControls();
                    Tn.playheadSlider.simpleSlider('pauseTrackingHelper', true);
                    window.turnerVideoPageObj.stopAdInTrayReloader();
                    window.turnerVideoPageObj.hideReloadingAds();
                    if(adType !== 'preroll'){
                        window.turnerVideoPageObj.hideAds();
                    }
                    window.turnerVideoPageObj.showSyncAdInTray();
                    window.turnerVideoPageObj.locateFreewheelSyncAd();

                    $('body').addClass('adPlaying');

                    turnerVideo.showMode('full');

                    removeAdDiv = true;
                    playButton.css("display", "none");
                    pauseButton.css("display", "block");
                    turnerVideo.togglePauseState(false);
                    vidObject.mode = mode;
                    vidObject.id = id;
                    vidObject.duration = duration;
                    vidObject.videoState = "ad";
                    vidObject.adType = adType;
                    if (tveModeGlobal === 'liveTVE') {
                        TVE_VideoEvent(vidObject, "tve-live_ad-start");
                    } else if (vidObject.tveMode !== "clip") {
                        TVE_VideoEvent(vidObject, "ad-start");
                    } else if (adType !== "postroll") {
                        sendVideoEvent(vidObject, "video-preroll");
                    }
                },
                /*
                for liveTV, the ad playhead and content playhead will both be running at the same time during ads
                */
                onAdPlayhead: function(playerId, playhead, duration) {
                    turnerVideo.stopAdPlayheadWorkAroundTimer();
                    if (Tn.currentPage !== "page-video") {
                        turnerVideo.pause();
                    }
                    if (doHideSplash) {
                        hideSplash();
                    }
                    if (!showProgress) {
                        return;
                    }

                    // we are checking to make sure we are still on the video page before updating the playbar to the ad text
                    if(playbarState !== 'ad' && Tn.currentPage === "page-video"){
                        turnerVideo.updateAdPlaybar(duration);
                    }
                    //console.log('onAdPlayhead: updating ad progress');
                    //console.log('onAdPlayhead: duration: ' + duration);
                    //console.log('onAdPlayhead: playhead: ' + playhead);
                    turnerVideo.updateAdProgress(duration - playhead);

                    //var progress = playhead * 100 / duration;
                    // we want the progress passed into simpleSlider as a decimal not as a percentage
                    var progress = playhead / duration;
                    //var progressString = progress.toString() + "%";
                    Tn.playheadSlider.simpleSlider('setRatio', progress);
                    //timeSliderBut.css('width', progressString);
                    //timeSliderHandle.css("left", progressString);
                    vidObject.playhead = playhead;
                    // iPhone html5 native player may have had the playClip/playFullEp but they will still have to hit the play button.
                    // Since vidObject.paused is undefined on init, we define it on the first onAdPlay
                    // 
                    

                    
                    if(typeof(vidObject.paused) === 'undefined'){
                        vidObject.paused = false;
                        turnerVideo.togglePauseState(false);
                    }
                    // 'Done' on iOS is pausing the video and we are not getting a pause event needed to know to show the header footer
                    // We won't know it is paused so if we have vidObject.paused == true a 'Done' is not what we are looking at here.
                    if(isMobile && vidObject.paused !== true){
                        turnerVideo.adPlayHeadTimer = setTimeout(function() {
                            //turnerVideo.togglePauseState(true);
                            turnerVideo.pause();
                        }, 2200);
                    } else {
                        turnerVideo.stopAdPlayheadWorkAroundTimer();
                    }
                        
                    // We get extra adPlayhead events while the cvp is trying to pause. Use a coundown and video pause flag to wait for the 
                    // adPlayheadEvents from happening.  If they keep happening and we are suppose to be paused  -->  Pause it.
                    if(vidObject.paused === true && turnerVideo.adPlayheadWithPauseCounter >= 2){
                        turnerVideo.pause();
                        turnerVideo.adPlayheadWithPauseCounter = 0;
                    } else if(vidObject.paused === true){
                        turnerVideo.adPlayheadWithPauseCounter++;
                    } else {
                        turnerVideo.adPlayheadWithPauseCounter = 0;
                    }
                },
                onAdEnd: function(playerId, token, mode, id, blockId, adType) {
                    cvpInAds = false;
                    console.log('onAdEnd');
                    turnerVideo.addHTML5VideoControls();
                    turnerVideo.adPlayheadWithPauseCounter = 0;
                    Tn.playheadSlider.simpleSlider('pauseTrackingHelper', false);
                    turnerVideo.stopAdPlayheadWorkAroundTimer();
                    // Rules are such that, the tray will open if closed after preroll/midroll start so only turn off sync ads if video ads are running and 
                    // user closed tray.  Here we are turning sync ads back on ( if closed previously ) in prep for the next pre-roll / midroll
                    if ($(window).width() > 600 && !window.turnerVideo.isFullscreen) {
                        window.window.adHelper.manageSyncAds($('#page-video aside .syncAdWrapper'), []);
                    }
                    window.turnerVideoPageObj.startAdInTrayReloader();
                    window.turnerVideoPageObj.showAds();
                    window.turnerVideoPageObj.locateFreewheelSyncAd();
                    vidObject.adType = adType;
                    vidObject.videoState = "video";
                    if (tveModeGlobal === 'liveTVE') {
                        TVE_VideoEvent(vidObject, "tve-live_ad-complete");
                        vidObject.adType = "";
                    } else if (adType === "midroll") {
                        TVE_VideoEvent(vidObject, "ad-complete");
                    }
                    // This won't happen per TENDP-12184
                    // if(window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector) ){
                    //     closeRail(); 
                    // } else 
                    if ($(window).width() > 600) {
                        openRail(true);
                    }
                    //Clear out video skin if there is one.  Let prerool go until the first tray ad refresh or onAdStart
                    // if (((adType === 'midroll') || (adType === 'postroll')) && window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector) ){
                    //     window.turnerVideoPageObj.resetBackGroundSkin();
                    //     turnerVideo.watchResize(1500);
                    // }

                    // if (videoState.playing === false) {
                    //     turnerVideo.showMode('upnext');
                    // }
                },
                onTrackingAdProgress: function(playerId, dataObj) {
                    if (tveModeGlobal && tveModeGlobal !== "clip") {
                        if (dataObj.adType !== "preroll") {
                            TVE_VideoEvent(vidObject, "ad-progress");
                        }
                    }
                },
                onTrackingAdClick: function(playerId, dataObj){
                    turnerVideo.pause();
                    // Also, the controls appear sometimes ( after a ad is clicked ) so remove them again
                    turnerVideo.removeHTML5VideoControls(300);
                },
                onTrackingContentPlay: function(playerId, dataObj) {
                    try {
                        //var isvideoComplete_flg = false;
                        //var video_progressMarkerNum = 0;
                        //var isvidperct100 = false;
                        vidObject.videoState = "video";
                        vidObject.adType = "";
                        if (tveModeGlobal === "liveTVE") {
                            TVE_VideoEvent(vidObject, "tve-live_video-start");
                        } else if (tveModeGlobal !== 'clip') {
                            vidObject.duration = dataObj["length"];
                            if (Tn.autoPlaying) {
                                TVE_VideoEvent(vidObject, "video-autostart");
                                Tn.autoPlaying = false;
                            } else {
                                TVE_VideoEvent(vidObject, "video-start");
                            }
                        } else {
                            if (Tn.autoPlaying) {
                                sendVideoEvent(vidObject, "video-autostart");
                                Tn.autoPlaying = false;
                            } else {
                                sendVideoEvent(vidObject, "video-start");
                            }

                        }
                    } catch (e) {}
                },
                onTrackingContentComplete: function() {
                    if (!doVideoCompleteEvent) {
                        return;
                    }
                    doVideoCompleteEvent = false;
                    if (vidObject.tveMode !== 'clip') {
                        TVE_VideoEvent(vidObject, "video-complete");
                    } else {
                        sendVideoEvent(vidObject, "video-complete");
                    }
                },
                onTrackingContentProgress: function() {},

                onTrackingContentSegmentComplete: function() {
                    if ($(window).width() > 600) {
                        openRail(true);
                    }
                },
                onAdCreativeStart: function() {
                    if ($(window).width() > 600) {
                        openRail(true);
                    }
                    turnerVideo.wait4Skin(0);
                },
                onAdCreativeEnd: function() {
                    if (window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector)) {
                        window.turnerVideoPageObj.resetBackGroundSkin();
                        turnerVideo.watchResize(1500);
                    }
                },
                onTrackingFullscreen: function(playerId, dataObj) {
                    window.turnerVideoPageObj.stopAdInTrayReloader();
                    //console.log('!!!!!!! onTrackingFullscreen ' + dataObj.fullscreen);
                    //$('.navbar-header').prepend('<span>fullscreen' + dataObj.fullscreen + '</span>'); // Some iPhone testing code
                    if (dataObj.fullscreen === false) {
                        //if(!cvpInAds && !vidObject.paused){
                        window.turnerVideo.isFullscreen = false;
                        if (window.turnerVideoPageObj.isTrayOpen()) {
                            if (!cvpInAds) {
                                window.turnerVideoPageObj.startAdInTrayReloader();
                            }
                            if ($(window).width() > 600) {
                                // Turn on sync ads
                                window.window.adHelper.manageSyncAds($('#page-video aside .syncAdWrapper'), []);
                            }
                        }
                    } else {
                        window.turnerVideo.isFullscreen = true;
                        // Add html5 controls just to be sure.  May not be needed.
                        turnerVideo.addHTML5VideoControls(); 
                        // Rules are such that, the tray will open if closed on preroll start so only turn off ads if ads are running and user closed tray
                        window.window.adHelper.manageSyncAds([], $('#page-video aside .syncAdWrapper'));
                    }
                },
                onCVPVisibilityChange: function(playerId, visible) {},

                onPageVisibilityChange: function(playerId, visible) {
                    turnerVideo.visible = visible;
                    window.turnerVideoPageObj.stopAdInTrayReloader();
                    if (visible) {
                        //if(!cvpInAds && !vidObject.paused){
                        if (!cvpInAds) {
                            window.turnerVideoPageObj.startAdInTrayReloader();
                        }
                    }
                },
                onViewportVisibilityChange: function(playerId, visible) {}
            });
            turnerVideo.player.embed("playerarea");
        }
    });
    var tntDefaultOpenPaneId = 'pane-info';
    window.turnerVideoPageObj = {
        rrSlider: [],
        currentTrayPaneId: tntDefaultOpenPaneId,
        syncAdWrapperSelector: '.syncAdWrapper',
        firstSyncAdTimer: 0,
        reloadingAdShown: false,
        initTrayAdTimer: 10000,
        flashMsgFlag: false,
        contentErrorMsgShown: false,
        contentErrorHappened: false,
        name4ContentErrorTime: 'contentErrorTime',

        init: function() {
            this.initVideoEvents();
            this.initAside();
        },
        initVideoEvents: function() {
            if (Tn.gup('pageMode') === 'fullscreen') {
                $('body').addClass('fixed-page');
            }

            $('#pausedAreaDiv').on("click", function(event) {
                event.preventDefault();
                event.stopPropagation();

                // Replay the video if the paused div was clicked in up next mode
                if (lastSavedInitOptions && $('#page-video').attr('mode') !== 'full') {
                    turnerVideo.cancelUpNext();
                    turnerVideo.player.replay();
                    return;
                }

                turnerVideo.resume();
            });
            $('#full-screen-btn').on("click", function(event) {
                event.preventDefault();
            });

            $('#page-video .profile-dologin .create').click(function(event) {
                event.preventDefault();
                event.stopPropagation();
                Tn.Users.logIn();
            });

            $('#page-video .profile-dologin .signin').click(function(event) {
                event.preventDefault();
                event.stopPropagation();
                var options = {};
                if ($(this).attr('data-start-screen')) {
                    options.startScreen = $(this).attr('data-start-screen');
                }
                Tn.Users.logIn(options);
            });

            if (isMobile) {
                $('#playerarea').on("click", function() {
                    turnerVideo.play();
                });
            }

            $('body').on('pageresize', function() {
                turnerVideo.watchResize(500);
            });

            $('#page-video aside a[paneid]').on('click', function() {
                //'click' event is sometimes triggered programatically
                var $panel = $('#page-video aside');
                var paneId = $(this).attr('paneid');
                var $thisPane = $panel.find('#' + paneId);
                var $butts = $('#page-video aside a[paneid]');
                var $panes = $panel.find('.pane');
                var vidDiv = document.getElementById('playerDiv');
                var resizeDivFn = function() {
                    turnerVideo.watchResize(1000);
                };
                tnVars.addResizeListener(vidDiv, resizeDivFn);

                // this means you have clicked on the one that is open
                // so it should close and button loses highlight
                if ($(this).hasClass('active')) {
                    window.turnerVideo.closeRailHelper();
                    if ($(window).width() <= 600 && turnerVideo.player) {
                        try {
                            // It could be undefined since it can be neither played or paused for initialized html5 players that don't have autostart
                            if(railAndVideoState.pausedWhenLastOpen_SmallScreen === false){
                                turnerVideo.togglePauseState(false);
                                turnerVideo.play();
                            }
                        } catch (e) {}
                    }
                    return;
                } else {
                    $panel.addClass('open');
                    $('#page-video .player-wrapper').addClass('railopen');
                    window.turnerVideoPageObj.currentTrayPaneId = paneId;
                    window.turnerVideoPageObj.stopAdInTrayReloader();
                    if (!cvpInAds) {
                        window.turnerVideoPageObj.startAdInTrayReloader();
                    }
                    if ($(window).width() > 600 && !window.turnerVideo.isFullscreen) {
                        // Turn on sync ads
                        window.window.adHelper.manageSyncAds($('#page-video aside .syncAdWrapper'), []);
                    } else if ($(window).width() <= 600 && turnerVideo.player) {
                        try {
                            // railAndVideoState.pausedWhenLastOpen_SmallScreen = (vidObject.paused === true)?vidObject.paused:false;
                            railAndVideoState.pausedWhenLastOpen_SmallScreen = (vidObject && typeof(vidObject) == 'object')?vidObject.paused:true;
                            // It could be undefined since it can be neither played or paused for initialized html5 players that don't have autostart
                            if(typeof(railAndVideoState.pausedWhenLastOpen_SmallScreen) !== 'undefined'){
                                turnerVideo.pause();
                            }
                        } catch (e) {}
                    }
                }
                $butts.removeClass('active');
                $butts.each(function() {
                    var $item = $(this);
                    if ($item.attr('paneid') === paneId) {
                        $item.addClass('active');
                        return false;
                    }
                });
                $panes.hide();
                $thisPane.show();
                if (!cvpInAds && !window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector)) {
                    window.turnerVideoPageObj.hideSyncAdInTray(); // We can hide because we can assume we have DE ads
                    window.turnerVideoPageObj.showReloadingAds();
                    window.turnerVideoPageObj.resetBackGroundSkin();
                    window.window.adHelper.loadAds2($thisPane, 'onShow');
                }
                //Turn on 
                turnerVideo.watchResize(1000);

                window.turnerVideoPageObj.locateFreewheelSyncAd();
            });
        },
        initAside: function() {
            if ($(window).width() <= 600) {
                //sync ads are on by default.  Turn them off because this will be closed
                window.window.adHelper.manageSyncAds([], $('#page-video aside .syncAdWrapper'));
                $('#page-video aside #pane-info').hide();
            } else {
                $('#page-video aside').addClass('open');
                $('#page-video aside a[paneid="pane-info"]').addClass('active');
                $('#page-video aside #pane-info').show();
                $('#page-video .player-wrapper').addClass('railopen');
            }
        },
        stopAdInTrayReloader: function() {
            if (window.turnerVideoPageObj.adInTrayTimerId) {
                clearInterval(window.turnerVideoPageObj.adInTrayTimerId);
                delete window.turnerVideoPageObj.adInTrayTimerId;
            }
        },
        startAdInTrayReloader: function() {
            //Load ad right after 10 seconds when there is no preroll ad in tray's selected pane.  We to see a ad in the tray
            if (window.turnerVideoPageObj.isTrayOpen() && window.turnerVideoPageObj.reloadingAdShown !== true &&
                window.turnerVideoPageObj.firstSyncAdShown !== true &&
                window.turnerVideoPageObj.hasTraySyncAd() !== true) {
                // The timer/setTimeout is set to 10 seconds so after contentBegin ( only for first video ) put a ad up after 10 seconds
                // Live is tricky.  We get a bunch of onContentPause events which usually start the ad refresh processes.  Here we use
                // the deltaFirstSyncAdTimer to ignore all those requests for 10 seconds.
                // Additionally for live, we do get a sync ad but not with a onAdPlay Event.  So, checking the DOM as well
                var nowTime = (new Date()).getTime(),
                    deltaFirstSyncAdTimer = nowTime - window.turnerVideoPageObj.firstSyncAdTimer;
                if (deltaFirstSyncAdTimer > (window.turnerVideoPageObj.initTrayAdTimer - 1000)) {
                    window.turnerVideoPageObj.adInTrayReloader();
                }
            }
            if (window.turnerVideoPageObj.isTrayOpen() && !cvpInAds && typeof(window.turnerVideoPageObj.adInTrayTimerId) === "undefined") {
                window.turnerVideoPageObj.adInTrayTimerId = setInterval(function() {
                    if (turnerVideo.visible) {
                        window.turnerVideoPageObj.adInTrayReloader();
                    }
                //}, 120000); // Every two minutes
                }, 30000); // Every 30 seconds
            }

        },
        adInTrayReloader: function() {
            var $panel = $('#page-video aside'),
                $thisPane = $panel.find('#' + this.currentTrayPaneId);

            if (!window.turnerVideoPageObj.hasBackgroundImage(turnerVideo.videoSkinSelector)) {
                this.hideSyncAdInTray();
                this.showReloadingAds();
                if ($(window).width() > 600) {
                    // Tray ads not shown less than 600
                    window.turnerVideoPageObj.reloadingAdShown = true;
                }
                window.adHelper.loadAds2($thisPane.find("." + window.adHelper.reloadingAdClass), 'onPoll');
            }

        },
        isTrayOpen: function() {
            return $('#page-video .player-wrapper').hasClass('railopen');
        },
        initSyncAd: function() {
            // This function handles the corner case where we don't get the onAdPlay event but get a sync ad.  This can happen with live streams.
            if (window.turnerVideoPageObj.reloadingAdShown !== true && window.turnerVideoPageObj.firstSyncAdShown !== true &&
                window.turnerVideoPageObj.hasTraySyncAd() === true) {
                window.turnerVideoPageObj.hideReloadingAds();
                window.turnerVideoPageObj.showSyncAdInTray();
                window.turnerVideoPageObj.locateFreewheelSyncAd();
                window.turnerVideoPageObj.firstSyncAdShown = true;
            }
        },
        hasTraySyncAd: function() {
            var traySyncAdHtmlTmp = $('#page-video aside #_fw_container_medium_rectangle').html(),
                traySyncAdHtml = (traySyncAdHtmlTmp) ? $.trim(traySyncAdHtmlTmp) : '',
                hasTraySyncAd = (traySyncAdHtml.length > 10) ? true : false;
            return hasTraySyncAd;
        },
        showReloadingAds: function() {
            $('#page-video aside .' + window.adHelper.reloadingAdClass).show();
        },
        hideReloadingAds: function() {
            $('#page-video aside .' + window.adHelper.reloadingAdClass).hide();
        },
        showSyncAdInTray: function() {
            $('#page-video aside .syncAdWrapper').show();
        },
        hideSyncAdInTray: function() {
            $('#page-video aside .syncAdWrapper').hide();
        },
        hideAds: function() {
            $('#page-video aside .' + window.adHelper.smallAdClass).hide();
        },
        showAds: function() {
            $('#page-video aside .' + window.adHelper.smallAdClass).show();
        },
        locateFreewheelSyncAd: function() {
            var $currentTray = $('#page-video aside #' + window.turnerVideoPageObj.currentTrayPaneId),
                freewheelDEAdLocationPosition = $currentTray.find('.freewheelDEAdLocation').position(),
                freewheelYOffset = '88px';
            if (freewheelDEAdLocationPosition) {
                freewheelYOffset = freewheelDEAdLocationPosition.top;
            }
            $('#page-video aside .syncAdWrapper').css({
                top: freewheelYOffset + 'px'
            });
        },
        getBackgroundImage: function(videoSkinSelector) {
            var bg_url = $(videoSkinSelector).css('background-image'),
                backgroundImage = '';
            // ^ Either "none" or url("...urlhere..")
            bg_url = /^url\((['"]?)(.*)\1\)$/.exec(bg_url);
            if (bg_url && bg_url[2].length > 5) {
                backgroundImage = bg_url[2];
            }
            return backgroundImage;
        },
        hasBackgroundImage: function(videoSkinSelector) {
            var backgroundImage = this.getBackgroundImage(videoSkinSelector),
                itHasBackgroundImage = (backgroundImage) ? true : false;
            return itHasBackgroundImage;
        },
        resetBackGroundSkin: function() {
            // turnerVideo.watchResize(1500); need to be called with this function.  Since this function is called already in the places this is called
            // it needs to be called outside this function
            $(turnerVideo.videoSkinSelector).css("background-image", "none");
            $('#leftclick, #rightclick').html('');
        },
        needFlashHandler: function(player) {
            // Need to show something since the page is black
            var videoTag = $('#' + player.getId());
            if (videoTag && videoTag.length && turnerVideo.posterImage) {
                videoTag.attr('poster', turnerVideo.posterImage);
                turnerVideo.watchResize(250);
            }
            if (!this.flashMsgFlag) { // No duplicate msgs.  If we upgrade, preventDuplicates will work
                window.toastr.options.onclick = turnerVideoPageObj.gotoFlashPage;
                $.extend(window.toastr.options, {
                    "closeButton": true,
                    "timeOut": "35000",
                    "preventDuplicates": true,
                    "onShown": turnerVideoPageObj.onFlashMsg,
                    "onHidden": turnerVideoPageObj.offFlashMsg,
                    "extendedTimeOut": "5000"
                });
                window.toastr.info('This video requires the Adobe Flash Player. Please enable it in your browser or <u>download it now</u>.');
            }
        },
        gotoFlashPage: function() {
            window.open('https://get.adobe.com/flashplayer/', '_blank');
        },
        onFlashMsg: function() {
            window.turnerVideoPageObj.flashMsgFlag = true;
        },
        offFlashMsg: function() {
            window.turnerVideoPageObj.flashMsgFlag = false;
            window.toastr.options.onclick = undefined;
        },
        contentErrorHandlerHelper: function() {
            if (window.turnerVideoPageObj.contentErrorHappened && !window.turnerVideoPageObj.contentErrorMsgShown) { // No duplicate msgs.  If we upgrade, preventDuplicates will work
                var now = (new Date()).getTime(),
                    name4ContentErrorTime = window.turnerVideoPageObj.name4ContentErrorTime,
                    firstRefreshTime4ContentError = Tn.localStorageWrapper.getItem(name4ContentErrorTime), // Reset with each new video. See showPlayerInternal
                    toastrErrMsg = "Please <u>refresh</u> the page. There was an error loading this video.";
                if (!firstRefreshTime4ContentError) {
                    window.toastr.options.onclick = turnerVideoPageObj.gotoContentErrorPage;
                } else {
                    firstRefreshTime4ContentError = Number(firstRefreshTime4ContentError);
                    var delta = now - firstRefreshTime4ContentError;
                    // For 20 sec to 10 min after the 1st error happened and they refreshed, don't keep telling them to refresh because it is not working
                    if (delta > 20000 && delta < 600000) {
                        toastrErrMsg = "We cannot load this video right now. We apologize for the inconvenience";
                    } else {
                        window.toastr.options.onclick = turnerVideoPageObj.gotoContentErrorPage;
                    }
                }

                $.extend(window.toastr.options, {
                    "closeButton": true,
                    "timeOut": "60000",
                    "preventDuplicates": true,
                    "onShown": window.turnerVideoPageObj.onContentErrorMsg,
                    "onHidden": window.turnerVideoPageObj.offContentErrorMsg,
                    "extendedTimeOut": "10000"
                });
                window.toastr.info(toastrErrMsg);
            }

        },
        contentErrorHandler: function() {
            window.turnerVideoPageObj.contentErrorHappened = true;
            window.setTimeout(window.turnerVideoPageObj.contentErrorHandlerHelper, 600); // Make sure onContentPlayhead doesn't happen
        },
        gotoContentErrorPage: function() {
            var name4ContentErrorTime = window.turnerVideoPageObj.name4ContentErrorTime,
                now = (new Date()).getTime(),
                firstRefreshTime4ContentError = Tn.localStorageWrapper.getItem(name4ContentErrorTime);
            if (!firstRefreshTime4ContentError) {
                Tn.localStorageWrapper.setItem(name4ContentErrorTime, now);
            }
            window.setTimeout(function() {
                window.location.reload(true); // Wait for localStorage to be set.
            }, 200);
        },
        onContentErrorMsg: function() {
            window.turnerVideoPageObj.contentErrorMsgShown = true;
        },
        offContentErrorMsg: function() {
            window.turnerVideoPageObj.contentErrorMsgShown = false;
            window.toastr.options.onclick = undefined;
        }
    };

    showMode('full');
}(jQuery));