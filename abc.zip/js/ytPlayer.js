

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

(function($, undefined) {
    var ytVideo = window.ytVideo = {},
        page = null,
   	    playerWrapper = null,
        rr = null,
   	    playerDiv = null,
        done = false;
        
        

    var isTrayOpen = false;
    var tntDefaultOpenPaneId = 'pane-info';
/*
    function updateSize() {
        //var page = $('#page-embed-video');
        var dim = [0, 0, 0, 0];

        var lastDim = ytVideo.lastDim;
        if (lastDim && lastDim[0] === dim[0] && lastDim[1] === dim[1] && lastDim[2] === dim[2] && lastDim[3] === dim[3]) {
            return;
        }
        ytVideo.lastDim = dim;

        playerWrapper.css({
            left: dim[0],
            right: dim[1],
            top: dim[2],
            bottom: dim[3]
        });
        ytVideo.watchResize(1500);
    }
*/
    function openRail(reset) {
        //if (turnerVideo.currentMode !== "full") {
            //return;
        //}
        var infoPane = $('#page-youtube-video aside a[paneid="pane-info"]'),
            sharePane = $('#page-youtube-video aside a[paneid="pane-share"]');
        if ((!infoPane.hasClass('active') && !sharePane.hasClass('active')) || (!infoPane.hasClass('active') && reset)) {
            infoPane.trigger('click');
        }
    }

    function closeRail() {
        $('.in-player-tray').removeClass('open');
        $('#page-youtube-video aside a[paneid]').removeClass('active');
        $('#page-youtube-video .player-wrapper').removeClass('railopen');
        // setting timeout so the pane does not hide while it is still visible
        // transition in css is set to .5
        window.setTimeout(function() {
            $('#page-youtube-video aside .pane').hide();
        }, 600);
        window.ytVideo.stopAdInTrayReloader();

        window.ytVideo.watchResize(1000);
    }



    $.extend(ytVideo, {
        processedPage: false,
        visible: true,
        extrasList: [],
        extrasListInd: 0,
        videoSkinSelector: '.player-wrapper .videoSkinArea',
        ytPlayer: {},
        isInit: false,
        //playerAreaWidthToSmallForSkin: 900,
        //maxSizeOfVideoWithSkin: 720,
        //maxSizeOfRightRail: 390,
        //maxTopMargin: 40,
        //maxLeftMargin: 96,
        // TODO: if we have an ad skin the rrTimeout needs to be changed maybe
        rrTimeout: 3000,
        videoSkinPatchSelector: '.player-wrapper .videoSkinAreaIconTransparencyPatch',
        curVidData: {},
        redirectTimer: 0,
        currentTrayPaneId: tntDefaultOpenPaneId,
        init: function(){
            // we will init the first time to grab the data from the page, then we will go 
            var that = this;
            document.domain = document.domain;
            if(that.processedPage === false){
                page = $('#page-youtube-video');
                page.find('.videoSkinArea').removeClass('test1').removeClass('test2');
                var testval = getParameterByName('test');
                testval = typeof(testval) === 'undefined' ? '' : testval;
                if(testval === '1'){
                    page.find('.videoSkinArea').addClass('test1');
                } else if(testval === '2'){
                    page.find('.videoSkinArea').addClass('test2');
                }
                
                playerWrapper = page.find('.player-wrapper');
                rr = page.find('aside.in-player-tray');
                playerDiv = page.find('.embedPlayerDiv');

            
            }



            if(!window.tnVars.isMobile()){
                that.initAside();
                that.initVideoPageObj();
            }

            that.setUpYTPlayer();
            that.isInit = true;

            that.initVideoEvents();
       
        },
        setDuration: function(txt){
            var hms = txt.split(':');
            var duration = 0;
            // this converts the duration to seconds
            if (hms.length === 1) {
                duration = parseFloat(hms[0]);
            } else if (hms.length === 2) {
                duration = parseInt(hms[0], 10) * 60 + parseFloat(hms[1]);
            } else if (hms.length === 3) {
                duration = parseInt(hms[0], 10) * 60 * 60 + parseInt(hms[1], 10) * 60 + parseFloat(hms[2]);
            }
            duration = Tn.formatDuration(duration);
            return duration;
            
        },
        setUpYTPlayer: function(){
            var that = this;
            that.getDataFromPage();

            that.ytPlayer = new window.YT.Player('youtubePlayer', {
                height: '100%',
                width: '100%',
                videoId: that.curVidData.videoId,
                playerVars: {
                    showinfo: 0,
                    modestbranding: 1,
                    rel: 0
                },
               
                events: {
                    'onReady': that.onPlayerReady,
                    'onStateChange': that.onPlayerStateChange,
                    'onError': that.onPlayerError
                }
            });

            if(that.curVidData.arkTanId){
                window.Tn.showComments(that.curVidData.arkTanId);
            }
            //that.watchResize(500);

        },
        onPlayerError: function(event) {
            console.log('yt error');
            console.log(event);
        },
        onPlayerReady: function(event) {
            if(!window.tnVars.isIOS()){
                event.target.playVideo();
            }
            
            if(window.turnerVideoPageObj.hasBackgroundImage(window.ytVideo.videoSkinSelector) ){
                closeRail();
            }

        },
        onPlayerStateChange: function(event) {
            var that = this;
            if (event.data === window.YT.PlayerState.PLAYING && !done) {
                setTimeout(that.stopVideo, 6000);
                done = true;
            }
        },
        pausePlayer: function(){
            var that = this;
            if(that.ytPlayer){
                that.ytPlayer.pauseVideo();
            }
        },
        hidePlayer: function(){
            var that = this;
            if(that.ytPlayer){
                that.pausePlayer();
            }
        },
        stopVideo: function() {
            var that = this;
            that.ytPlayer.stopVideo();
        },
        initAside: function() {
            var that = this;
            
            var formattedDuration = that.setDuration(rr.find('#pane-info .metainfo .duration').text());
            rr.find('#pane-info .metainfo .duration').text(formattedDuration);

            if($(window).width() <= 600){
                $('#page-video aside #pane-info').hide();
            } else {
                rr.addClass('open');
                rr.find('a[paneid="pane-info"]').addClass('active');
                rr.find('#pane-info').show(100);
                playerWrapper.addClass('railopen');
                isTrayOpen = true;
                that.watchResize(1000);
                window.ytVideo.startAdInTrayReloader();
            }
           
        },
       
        loadNewVideo: function(elem){
            var that = this;
            // player.loadVideoById
            var currVidInd = that.getCurrentVidInd($(elem).attr('data-id'));
            //var vidId = that.getVideoId(elem);
            var vidId = that.extrasList[currVidInd].sourceId;
            var metaRaw = that.extrasList[currVidInd].analytics;
            console.log('new vid id: ' + vidId);
            that.ytPlayer.stopVideo();
            that.populateInfoRR(currVidInd);
            that.ytPlayer.loadVideoById(vidId);
            window.Tn.parseRawAnalytics(metaRaw, false);
            // TODO - need to populate right rail
        },
        getCurrentVidInd: function(contentId){
            var that = this;
            var ind;
            if(!contentId){
                console.log('YT getCurrentVidInd: there was no contentId passed in');
                return ind;
            }
            
            $.each(that.extrasList, function(i, extra){
                if(extra.contentId === contentId){
                    ind = i;
                    return;
                }
            });
            return ind;
        },

        populateInfoRR: function(i){
            var that = this;
            var vid = that.extrasList[i];
            if(typeof(vid) !== 'undefined'){
                var info = rr.find('#pane-info');
                info.find('h2.title').text(vid.title);
                //console.log("desc node");
                //console.log(info.find('p.desc > span[itemprop="description"]'));
                //console.log('next video desc: ' + nextVid.desc);
                info.find('span[itemprop="description"]').text(vid.desc);
                info.find('.metainfo .duration').text('');
                var duration = vid.duration;
                if(duration !== ''){
                    info.find('.metainfo .duration').text(that.setDuration(duration));
                }
                
            }
        },

        initVideoPageObj: function(){
            if($.cookie('devCVP') === "1"){
                //context = context + '_dev';
                $('.player-wrapper .videoSkinArea').parent().bind('DOMNodeInserted DOMNodeRemoved', function(event) {
                    if (event.type === 'DOMNodeInserted') {
                        console.log('Content added! Current content:' + '\n\n' + $(this).find('.videoSkinArea').html());
                    } else {
                        console.log('Content removed! Current content:' + '\n\n' + $(this).find('.videoSkinArea').html());
                    }
                });
            }

            // this will contain both cvp and YT video
            $('#page-youtube-video aside').find('.extras .playbut').on('click', function(event){
                var mc = $(this).parent();
                //var obj = {};
                if(mc.attr('data-videohref').indexOf('youtube') === -1){
                    return;
                } else {
                    console.log('load new YT video');
                    window.ytVideo.loadNewVideo(this);
                }
                
            });

            $('#page-youtube-video aside a[paneid]').on('click', function() {
                //console.log("page-video aside a[paneid] clicked");

                var page = $('#page-youtube-video');
                var $panel = page.find('aside');
                var paneId = $(this).attr('paneid');
                var $thisPane = $panel.find('#' + paneId);
                var $butts = page.find('aside a[paneid]');
                var $panes = $panel.find('.pane');
                var vidDiv = page.find('.embedPlayerDiv').get(0);
                var resizeDivFn = function() {
                    ytVideo.watchResize(1000);
                };
                window.tnVars.addResizeListener(vidDiv, resizeDivFn);

                window.ytVideo.stopAdInTrayReloader(); // Stop here since with closing or opening the tray, we at least need to start over.

                // this means you have clicked on the one that is open
                // so it should close and button loses highlight
                if ($(this).hasClass('active')) {
                    //close panel
                    window.ytVideo.closeRailHelper();
                    /*
                    // setting timeout so the pane does not hide while it is still visible
                    // transition in css is set to .5
                    window.setTimeout(function() {
                        // hide pane
                        $panes.hide();
                    }, 600);
                    ytVideo.watchResize(500);
                    */
                    /*
                    if(cvpInAds){
                        // Turn off all cvp sync ads in the tray but only in preroll/midroll.  
                        // Need the first ad to run so later ones can come into view later.  Need the instationation when first ad starts.
                        // Rules are such that, the tray will open if closed on preroll start so only turn off ads if ads are running and user closed tray
                        window.adHelper.manageSyncAds([], $('#page-youtube-video aside .syncAdWrapper'));
                    }
                    */
                    return;
                } else {
                    $panel.addClass('open');
                    page.find('.player-wrapper').addClass('railopen');
                    ytVideo.currentTrayPaneId = paneId;
                    window.ytVideo.startAdInTrayReloader();
                    //if(!vidObject.paused && !cvpInAds){
                    /*
                    if(!cvpInAds){
                        window.turnerVideoPageObj.startAdInTrayReloader();
                    }
                    */
                    // Turn on sync ads
                    //window.adHelper.manageSyncAds($('#page-video aside .syncAdWrapper'), []);
                    //window.turnerVideoPageObj.startScroller();
                    //var rrSlider = window.turnerVideoPageObj.rrSlider;
                    //rrSlider.setup();
                }
                $butts.removeClass('active');
                $butts.each(function() {
                    var $item = $(this);
                    if ($item.attr('paneid') === paneId) {
                        $item.addClass('active');
                        return false;
                    }
                });
                $panes.hide();
                $thisPane.show();
                //if(!cvpInAds){
                    //window.turnerVideoPageObj.hideSyncAdInTray(); // We can hide because we can assume we have DE ads
                ytVideo.showReloadingAds();
                //ytVideo.resetBackGroundSkin();
                //window.adHelper.loadAds2($thisPane, 'onShow');
                //}
                //Turn on 
                ytVideo.watchResize(500);

                //window.turnerVideoPageObj.locateFreewheelSyncAd();
            });
        },

        getDataFromPage: function(){
            var that = this;
            that.curVidData.contentId = page.data('contentid');
            that.curVidData.showName = page.data('showname');
            that.curVidData.arkTanId = page.data('arktanstreamid');

            console.log(that.curVidData);
            var spans = page.find('.videodata span');

            $.each(spans, function(i, vid){
                var vObj = {};
                var $vid = $(vid);
                that.curVidData.videoId = $vid.attr('videoSourceId');

                vObj.desc = $vid.attr('description');
                vObj.title = $vid.attr('title');
                vObj.imgStillUrl = $vid.attr('imageStillUrl');
                vObj.contentId = $vid.attr('contentId');
                vObj.sourceId = $vid.attr('videoSourceId');
                vObj.analytics = $vid.attr('anaytics');
                vObj.duration = $vid.attr('duration');
                if(vObj.contentId === that.curVidData.contentId){
                    that.curVidData.videoId = $vid.attr('videoSourceId');
                }
                that.extrasList.push(vObj);
            });
            console.log('extrasList');
            console.log(that.extrasList);
            that.processedPage = true;
        },

        removePlayer: function(){
            var that = this;
            $('#page-youtube-video').remove();
            
            that.processedPage = false;
            that.isInit = false;
            that.extrasList = [];
        },
        
        initVideoEvents: function() {
            $('body').on('pageresize', function() {
                ytVideo.watchResize(500);
            });
            
        },

    	watchResize: function(timeToWatch) {
            var that = this;
	        that.endTime = new Date().getTime() + timeToWatch;
	        that.onResizeTimer();
	    },
	    onResizeTimer: function() {
            var that = this;
	        if (that.videoTimer) {
	            clearTimeout(that.videoTimer);
	            delete that.videoTimer;
	        }

	        that.resize();
	        if (new Date().getTime() > that.endTime) {
	            return;
	        }
	        that.videoTimer = setTimeout($.proxy(that.onResizeTimer, that), 10);
	    },
        
	    resize: function() {
            // Always updated the splash size even if CVP is not ready
            //ytVideo.updateSplashSize();

            //updateSize();
            /*
            playerAreaWidthToSmallForSkin: 900,
            maxSizeOfVideoWithSkin: 740,
            maxTopMargin: 40,
            maxLeftMargin: 96,
             */
            //var w = playerDiv.width();
            //var h = playerDiv.height();
            //
            var iframe = $('iframe#youtubePlayer');
            var w = playerWrapper.width();
            var h = playerWrapper.height();
            //var h = parseInt(w * 360 / 640, 10);
            var ww = w;
            var hh = h;
            var top = 0;
            var left = 0;
            var wWidth = window.tnVars.windowW;

            var videoSkinDiv = $(ytVideo.videoSkinSelector);
            var videoWidth = iframe.length !== 0 ? iframe.width() : 0;
            var videoHeight = iframe.length !== 0 ? iframe.height() : 0;
            if (videoWidth === 0 || videoHeight === 0) { //assume 16:9
                videoWidth = 640;
                videoHeight = 360;
            }
        
            var scale = Math.min(ww / videoWidth, hh / videoHeight);
            ww = videoWidth * scale;
            hh = videoHeight * scale;
            top = (h - hh) / 2;
            left = (w - ww) / 2;
            ww = Math.floor(ww);
            hh = Math.floor(hh);
            top = Math.floor(top);
            left = Math.floor(left);
            var topString = top.toString() + "px";
            var leftString = left.toString() + "px";
            if (ww < 160) {
                ww = 160;
            }
            if (hh < 160) {
                hh = 160;
            }

            var ytWidth = ww,
                ytHeight = hh;

            var skinH,
                skinW, ww2, hh2,
                skinRightClickDiv,
                skinLeftClickDiv;

            // these are used for the margins

            // if the playerwrapper is greater than max video width + max left margin

            if(wWidth > window.turnerVideo.screenWidthTooSmallForSkin && window.turnerVideoPageObj.hasBackgroundImage(ytVideo.videoSkinSelector)){
                var backgroundImage = window.turnerVideoPageObj.getBackgroundImage(ytVideo.videoSkinSelector);
                skinRightClickDiv = $('#rightclick');
                skinLeftClickDiv = $('#leftclick');
                if(backgroundImage.indexOf('?h=1') > 0){
                    skinH = h;
                    skinW = (64/31) * skinH; // Width calculated from aspect ratio of the skin
                } else {
                    skinW = wWidth;
                    skinH = (31/64) * skinW; // Height calculated from aspect ratio of the skin
                }
                scale = Math.min(wWidth / videoWidth, h / videoHeight);
                ww2 = videoWidth * scale;
                hh2 = videoHeight * scale;

                ytWidth = 0.75 * ww2;
                ytHeight = 0.75 * hh2;

                if(ytWidth > ww){
                    ytHeight = Math.round(( ww * ytHeight ) / ytWidth);
                    ytWidth = ww;
                }
                if(ytWidth > window.turnerVideo.maxSizeOfCVPWithSkin){
                    ytHeight = Math.round(( window.turnerVideo.maxSizeOfCVPWithSkin * ytHeight ) / ytWidth);
                    ytWidth = window.turnerVideo.maxSizeOfCVPWithSkin;
                }

                //pausedAreaDiv.width(cvpWidth);
                //pausedAreaDiv.height(cvpHeight);
   
                playerWrapper.addClass('hasSkin');
                playerDiv.addClass('hasSkin');
                // Had to put the div containing the video skin outside the div with the cvp because the cvp was getting corrupted
                // and the next video would not play
                videoSkinDiv.show();
                //videoSkinDiv.width(ww).height(hh);
                videoSkinDiv.width(skinW).height(skinH);
                //videoSkinDiv.css("margin-top", topString);
                //videoSkinDiv.css("margin-left", leftString);
                
                //videoSkinPatchDiv.show();
                skinRightClickDiv.css("left", (ytWidth + 10) + 'px');
                skinRightClickDiv.css("height", (ytHeight + 10) + 'px');
                skinLeftClickDiv.css("top", (ytHeight + 10) + 'px');
                // videoSkinPatchDiv.css("margin-top", topString);
                // videoSkinPatchDiv.css("margin-left", leftString);
                // videoSkinPatchDiv.css("max-height", cvpHeight.toString() + "px");


            } else {
                playerDiv.css("margin-top", topString);
                playerDiv.css("margin-left", leftString);
                //pausedAreaDiv.width('auto');
                //pausedAreaDiv.height('auto');
                playerWrapper.removeClass('hasSkin');
                playerDiv.removeClass('hasSkin');
                videoSkinDiv.hide();
                //videoSkinPatchDiv.hide();
      
            }

            playerDiv.css("margin-top", topString);
            playerDiv.css("margin-left", leftString);
            playerDiv.width(ytWidth).height(ytHeight);

            
        },
        
        stopAdInTrayReloader: function() {
            if( window.ytVideo.adInTrayTimerId){
                clearInterval( window.ytVideo.adInTrayTimerId);
                delete window.ytVideo.adInTrayTimerId;
            }
        },
        startAdInTrayReloader: function() {
            //Load ad right away when there is no preroll ad in tray's selected pane
            //if(that.isTrayOpen() && that.firstSyncAdShown !== true){
            if(window.ytVideo.isTrayOpen()){
                window.ytVideo.adInTrayReloader();
            }
            if(window.ytVideo.isTrayOpen() && typeof(window.ytVideo.adInTrayTimerId) === "undefined"){
                window.ytVideo.adInTrayTimerId = setInterval(function(){
                    if(ytVideo.visible){
                       window.ytVideo.adInTrayReloader();
                    }
                }, 120000); // Every two minutes
            }

        },
        adInTrayReloader: function(){
            var $panel = $('#page-youtube-video aside'),
                $thisPane = $panel.find('#' + this.currentTrayPaneId);
            this.showReloadingAds();
            window.adHelper.loadAds2($thisPane.find("." + window.adHelper.reloadingAdClass), 'onPoll', '&pageload=sync_ref');
        },
        isTrayOpen: function(){
            return $('#page-youtube-video .player-wrapper').hasClass('railopen');
            //return playerWrapper.hasClass('railopen');
        },
        showReloadingAds: function(){
            $('#page-youtube-video aside .' + window.adHelper.reloadingAdClass).show();
        },
        hideReloadingAds: function(){
            $('#page-youtube-video aside .' + window.adHelper.reloadingAdClass).hide();
        },
        resetBackGroundSkin: function(){
            $(ytVideo.videoSkinSelector).css("background-image", "none");
            $('#leftclick, #rightclick').html('');
        },
        closeRailHelper: function(){
            closeRail();
        },
        openRailHelper: function(){
            openRail();
        }
    
	});

    
}(jQuery));

$('body').on('pageshown', function(event, pageId) {
    if (pageId !== 'page-youtube-video') {
        return;
    }

    
    if(document.getElementById('ytjs') === 'null' || document.getElementById('ytjs') === null){
        // call in YT code
        var tag = document.createElement('script');
        tag.src = "https://www.youtube.com/iframe_api";
        tag.id="ytjs";
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    } else if(!window.ytVideo.isInit){
        // we need to do this to trigger it is we are coming from another page and the script has already loaded
        // however, we do not want to reinit if we are still on the page.
        onYouTubeIframeAPIReady();
    }
    
    setTimeout(window.ytVideo.startAdInTrayReloader, 10000);


});

function onYouTubeIframeAPIReady(){
    window.ytVideo.init();
}









