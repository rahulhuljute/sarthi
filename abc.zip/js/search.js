

Tn.movieItemTemplate = [
    '<div class="main-content" id="id-{titleid}" data-content-type="movie" data-id="{titleid}" data-videohref="{videoLink}">',
    '<div class="main playbut {isPlayableClass}"></div>',
    '<img src="{imgSrc}" onerror="javascript:window.onShowOverlayError(this)" style="width:100%; height:100%;">',
    '<div class="caption withleft movie">',
    '    <div class="epinfo">{title}</div>',
    '    <div class="text-wrapper">',
    '        <span class="availexpire">{availExpire}</span>',
    '    </div>',
    '</div>',
    '<div class="icon-group2 {hideOverlayClass}">',
    '    <div class="icon plus"></div>',
    '    <div class="icon info"></div>',
    '</div>',
    '<div class="info-overlay">',
    '    <div class="icon-group">',
    '        <div class="icon plus"></div>',
    '        <div class="icon info" data-href="{infoLink}"></div>',
    '        <div class="icon playbut {isPlayableClass}"></div>',
    '    </div>',
    '    <div class="meta">',
    '        <div class="above-fold">',
    '            <div class="title">',
    '                <span>{title}</span>',
    '            </div>',
    '            <div class="specs">',
    '                <div class="season">',
    '                    <span></span>',
    '                </div>',
    '                <div class="ep">',
    '                    <span></span>',
    '                </div>',
    '                <div class="time left">',
    '                    <span>{duration}</span>',
    '                </div>',
    '            </div>',
    '        </div>',
    '        <div class="below-fold">',
    '            <div class="blurb truncate-h" style="">',
    '                {blurb}<div class="more" data-href="{infoLink}" style="display: inline;">More...</div>',
    '            </div>',
    '        </div>',
    '<div class="footer {footerClass}">',
    '            <span class="availexpire">{availExpireHover}</span>',
    '        </div>',
    '    </div>',
    '</div>',
    '</div>'
].join('');

//Idol search API location
(function(tnVars, Tn, $, undefined) {
    //var tnSearchQueryUrl = "/includes/searchproxy.html?query=";

    var searchImagePath = "http://i.cdn.turner.com/v5cache/TBS/Images/Dynamic/";
    if (window.siteDefaults.name === "TNT") {
        searchImagePath = "http://i.cdn.turner.com/v5cache/TNT/Images";
    }

    // we need an external way to call deSearch()
    window.searchObj = {
        doSearch: function() {
            doSearch();
        },
        updateSearchSize: function() {
            updateSearchSize();
        }
    };
    /* end of window.search{} */

    var searchQueryUrlTemplate = [
        "/includes/searchproxy.html?query={query}&type={type}&offset={offset}&length={length}"
    ].join('');

    

    var defaultItemTemplate = [
        '<div class="main-content" id="id-{titleid}" data-content-type="movie" data-id="{titleid}" data-videohref="{videoLink}">',
        '<div class="main playbut {isPlayableClass}"></div>',
        '<img src="{imgSrc}" onerror="javascript:window.onShowOverlayError(this)" style="width:100%; height:100%;">',
        '<div class="caption withleft movie">',
        '    <div class="epinfo">{title}</div>',
        '    <div class="text-wrapper">',
        '        <span class="availexpire">{availExpire}</span>',
        '    </div>',
        '</div>',
        '<div class="icon-group2 {hideOverlayClass}">',
        '    <div class="icon plus"></div>',
        '    <div class="icon info"></div>',
        '</div>',
        '<div class="info-overlay">',
        '    <div class="icon-group">',
        '        <div class="icon plus"></div>',
        '        <div class="icon info" data-href="{infoLink}"></div>',
        '        <div class="icon playbut"></div>',
        '    </div>',
        '    <div class="meta">',
        '        <div class="above-fold">',
        '            <div class="title">',
        '                <span>{title}</span>',
        '            </div>',
        '            <div class="specs">',
        '                <div class="season">',
        '                    <span></span>',
        '                </div>',
        '                <div class="ep">',
        '                    <span></span>',
        '                </div>',
        '                <div class="time left">',
        '                    <span>{duration}</span>',
        '                </div>',
        '            </div>',
        '        </div>',
        '        <div class="below-fold">',
        '            <div class="blurb truncate-h" style="">',
        '                {blurb}<div class="more" data-href="{infoLink}" style="display: inline;">More...</div>',
        '            </div>',
        '        </div>',
        '<div class="footer {footerClass}">',
        '            <span class="availexpire">{availExpireHover}</span>',
        '        </div>',
        '    </div>',
        '</div>',
        '</div>'
    ].join('');

    var sportItemTemplate = [
        '<div class="main-content" id="id-{titleid}" data-content-type="sport" data-id="{titleid}" data-videohref="{videoLink}">',
        '<div class="main playbut {isPlayableClass}"></div>',
        '<img src="{imgSrc}" onerror="javascript:window.onShowOverlayError(this)" style="width:100%; height:100%;">',
        '<div class="caption withleft sport">',
        '    <div class="epinfo">{title}</div>',
        '    <div class="text-wrapper">',
        '        <span class="availexpire">{availExpire}</span>',
        '    </div>',
        '</div>',
        '<div class="icon-group2 {hideOverlayClass}">',
        '    <div class="icon plus"></div>',
        '    <div class="icon info"></div>',
        '</div>',
        '<div class="info-overlay">',
        '    <div class="icon-group">',
        '        <div class="icon plus"></div>',
        '        <div class="icon info" data-href="{infoLink}"></div>',
        '        <div class="icon playbut {isPlayableClass}"></div>',
        '    </div>',
        '    <div class="meta">',
        '        <div class="above-fold">',
        '            <div class="title">',
        '                <span>{overlayTitle}</span>',
        '            </div>',
        '            <div class="specs">',
        '                <div class="season">',
        '                    <span></span>',
        '                </div>',
        '                <div class="ep">',
        '                    <span></span>',
        '                </div>',
        '                <div class="time left">',
        '                    <span>{duration}</span>',
        '                </div>',
        '            </div>',
        '        </div>',
        '        <div class="below-fold">',
        '            <div class="ep-title">',
        '                <span>{epTitle}</span>',
        '            </div>',
        '            <div class="blurb truncate-h" style="">',
        '                {blurb}<div class="more" data-href="{infoLink}" style="display: inline;">More...</div>',
        '            </div>',
        '        </div>',
        '<div class="footer {footerClass}">',
        '            <span class="availexpire">{availExpireHover}</span>',
        '        </div>',
        '    </div>',
        '</div>',
        '</div>'
    ].join('');


    var isPhone = tnVars.isPhone();
    var maxShowMoreResults = 24;
    var defaultLength = tnVars.isMobile() ? 24 : 48;
    var titleIdTmpSched;
    var displayObj = {};

    // function formatDuration() has become Tn.formatDuration() and lives on show.js;
    // it is used to format all seconds to mins durations except the video page
    // 
    function getMovieData(item) {
        var vidUrl = (item.pretty_video_url !== null && item.pretty_video_url !== '') ? item.pretty_video_url : "/videos" + item.pretty_url;
        var availExpireHover = typeof(item.available_on) !== 'undefined' ? item.available_on : '';
        var availExpire = typeof(item.available_on) !== 'undefined' ? item.available_on : '';
        var footerClass = availExpireHover.length === 0 ? 'tn-hidden' : '';
        // imgPath = item.image_300;
        var imgPath = isPhone && !window.tnVars.isRetinaScreen ? item.image_300 : item.image_600;
        var imgRetinaPath = item.image_600;
        imgPath = imgPath.length > 0 ? searchImagePath + imgPath : window.siteDefaults.defaultEpisodeImagePath;
        imgRetinaPath = imgRetinaPath.length === 0 ? searchImagePath + imgRetinaPath : window.siteDefaults.defaultEpisodeImagePath;
        var movieData = {
            contentType: "movie",
            titleid: item.title_id,
            videoLink: vidUrl,
            imgSrc: imgPath,
            retinaImgSrc: imgRetinaPath,
            title: item.title,
            availExpire: availExpire,
            availExpireHover: availExpireHover,
            infoLink: item.pretty_url,
            duration: Tn.formatDuration(item.duration),
            footerClass: footerClass,
            isPlayableClass: '',
            blurb: item.movie_description,
            isTileLinkableClass: 'hide'
        };
        //console.log(movieData);
        return movieData;
    }

    function getEpisodeData(item) {
        var availExpireHover = typeof(item.available_on_hover) !== 'undefined' ? item.available_on_hover : '';
        var availExpire = typeof(item.available_on) !== 'undefined' ? item.available_on : '';
        var footerClass = availExpireHover.length === 0 ? 'tn-hidden' : '';
        var epInfoLink = item.pretty_url;
        var playable = item.isplayable === 'true' ? true : false;
        //var imgPath = item.image_300;
        var imgPath = isPhone && !window.tnVars.isRetinaScreen ? item.image_300 : item.image_600;
        var imgRetinaPath = item.image_600;
        imgPath = imgPath.length > 0 ? searchImagePath + imgPath : window.siteDefaults.defaultEpisodeImagePath;
        imgRetinaPath = imgRetinaPath.length === 0 ? searchImagePath + imgRetinaPath : window.siteDefaults.defaultEpisodeImagePath;

        // right now we don't have season tiles for search

        if (!playable) {
            var mwtwtext = item.moreways2watch;
            if (mwtwtext.length > 0) {
                var mwtw = Tn.getMwtwContent({
                    mwtwtext: item.moreways2watch,
                    epInfoLink: epInfoLink,
                    limit: Tn.mwtwLimitInd,
                    playable: playable,
                    type: 'front',
                    isSeasonTile: false
                });
                var mwtwOverlay = Tn.getMwtwContent({
                    mwtwtext: item.moreways2watch,
                    epInfoLink: epInfoLink,
                    limit: Tn.mwtwLimitOverlayInd - 1,
                    playable: playable,
                    type: 'overlay',
                    isSeasonTile: false
                });
                if (mwtw !== "") {
                    availExpire = mwtw;
                    availExpireHover = mwtwOverlay;
                    footerClass = '';
                }
            }
        }
        var episodeData = {
            contentType: "episode",
            titleid: item.title_id,
            videoId: item.title_id,
            videoLink: item.pretty_video_url,
            isPlayableClass: playable ? '' : 'tn-hidden',
            belowFoldTitle: '',
            imgSrc: imgPath,
            retinaImgSrc: imgRetinaPath,
            epinfo: '<span>S' + item.season_number + ' | E' + item.episode_number + '</span><span class="rating">' + item.tv_rating + '</span>',
            airOn: item.air_on,
            availExpireHover: availExpireHover,
            availExpire: availExpire,
            footerClass: footerClass,
            hideOverlayClass: '',
            theAdHTML: '',
            epInfoLink: epInfoLink,
            showTitle: item.series_name,
            alt: item.series_name,
            title: item.title,
            duration: Tn.formatDuration(item.duration),
            blurb: item.episode_description,
            isTileLinkableClass: 'hide',
            dataContentType: 'show'
        };
        //console.log(episodeData);
        return episodeData;
    }

    function getClipData(item) {
        var footerClass = 'tn-hidden';
        var epInfo = Tn.clipPrefixText + item.title;
        // on the search dev server i saw a clip without images, so putting a default here just in case
        //var imgPath = item.image_300;
        var imgPath = isPhone && !window.tnVars.isRetinaScreen ? item.image_300 : item.image_600;
        var imgRetinaPath = item.image_600;
        imgPath = imgPath.length > 0 ? searchImagePath + imgPath : window.siteDefaults.defaultEpisodeImagePath;
        imgRetinaPath = imgRetinaPath.length === 0 ? searchImagePath + imgRetinaPath : window.siteDefaults.defaultEpisodeImagePath;
        var clipData = {
            contentType: "clip",
            titleid: item.content_id,
            videoId: item.content_id,
            videoLink: item.pretty_video_url,
            isPlayableClass: '',
            imgSrc: imgPath,
            retinaImgSrc: imgRetinaPath,
            epinfo: epInfo,
            belowFoldTitle: '',
            airOn: '',
            availExpireHover: '',
            availExpire: '',
            theAdHTML: '',
            footerClass: footerClass,
            hideOverlayClass: '',
            epInfoLink: item.pretty_video_url.replace('/videos/', '/shows/'),
            title: item.title,
            duration: Tn.formatDuration(item.duration),
            blurb: item.clip_description,
            isTileLinkableClass: 'hide',
            dataContentType: 'clip',
            alt: item.title,
            showTitle: item.series_name
        };
        // jhillmann: added series name for clips for the umbel tags
        //console.log(clipData);
        return clipData;
    }

    function getTuneInText(dateStr, isLive) {
        /*
        For non-live events (as in, not sports): 
        Midnight to 11:59am = xAM/(x-1)C (e.g. 9AM/8C, 10:30AM/9:30C) 
        Noon to 11:59pm = x/(x-1)C (e.g. 8/7C, 3:30/2:30C) 
          
        For live events (as in, sports): 
        Midnight to 11:59am = xAM/ET (e.g. 9AM/ET, 10:30AM/ET) 
        Noon to 11:59pm = xPM/ET (e.g. 8PM/ET, 10:30PM/ET)
        */
        var tuneInText = '';
        dateStr = dateStr.replace('Z', '');
        var utcDt = moment(dateStr).utc().format();


        var eDate = Tn.getAdjustedStartTime(utcDt, 'America/New_York', "MMMM D");
        var eTime = Tn.getAdjustedStartTime(utcDt, 'America/New_York', "h:mm A");
        eTime = eTime.indexOf(':00') !== -1 ? eTime.replace(':00','') : eTime;
        var cDate = Tn.getAdjustedStartTime(moment(dateStr).utc().add(-1, 'h').format(), 'America/New_York', "h:mm");
        cDate = cDate.indexOf(':00') !== -1 ? cDate.replace(':00','') : cDate;

        if (isLive) {
            tuneInText = eDate + ' &nbsp;&nbsp;' + eTime + ' / ET ';
        } else {
            tuneInText = eDate + ' &nbsp;&nbsp;' + eTime + ' / ' + cDate + 'c';
        }

        return tuneInText;
    }

    function getSchedData(item) {
        //var epType = item.pretty_url.indexOf('/movies/') !== -1 ? 'movie' : (item.pretty_url.indexOf('/sports/') !== -1 ? 'sport' : 'episode');
        var data = {};
        var titleType = item.title_type;
        var availExpireHover, availExpire, footerClass;
        //var imgPath = item.image_360x203;
        //var imgPath = item.image_720x406;
        var imgPath = isPhone && !window.tnVars.isRetinaScreen ? item.image_360x203 : item.image_720x406;
        var imgRetinaPath = item.image_720x406;
        var isLive = item.whats_on_now_flag === "true" ? true : false;

        var vidUrl = (item.pretty_video_url !== null && item.pretty_video_url !== '') ? item.pretty_video_url : "/videos" + item.pretty_url;
        vidUrl = isLive ? '/' + window.siteDefaults.liveLoc + '/east.html' : vidUrl;

        var isPlayableClass = item.whats_on_now_flag === "true" ? '' : 'tn-hidden';
        
        //imgPath = imgPath.length > 0 ? imgPath : window.siteDefaults.defaultEpisodeImagePath;
        //imgRetinaPath = imgRetinaPath.length === 0 ? imgRetinaPath : window.siteDefaults.defaultEpisodeImagePath;

        if (titleType === 'SP') {
            //vidUrl = (item.pretty_video_url !== null && item.pretty_video_url !== '') ? item.pretty_video_url : "/videos" + item.pretty_url;
            //vidUrl = isLive ? '/' + window.siteDefaults.liveLoc + '/east.html' : vidUrl;
            availExpireHover = typeof(item.available_on) !== 'undefined' ? item.available_on : '';
            availExpire = getTuneInText(item.schedule_date, isLive);
            footerClass = availExpireHover.length === 0 ? 'tn-hidden' : '';
            imgPath = imgPath.length > 0 ? searchImagePath + imgPath : window.siteDefaults.defaultEpisodeImagePath;
            imgRetinaPath = imgRetinaPath.length === 0 ? searchImagePath + imgRetinaPath : window.siteDefaults.defaultEpisodeImagePath;
            var prettyUrl = item.pretty_url;
            if (prettyUrl === '') {
                var franchiseId = item.franchise_id;
                prettyUrl = Tn.franchiseIdToPrettyUrlMap[franchiseId] ? Tn.franchiseIdToPrettyUrlMap[franchiseId] : prettyUrl;
                //console.log('series level: ' + prettyUrl);
            }
            var hideOverlayClass = prettyUrl.length === 0 ? 'tn-hidden' : '';
            //var hasPrettyUrlClass = typeof(prettyUrl) !== 'undefined' && prettyUrl.length !== 0 ? '' : Tn.hideClass;
            data = {
                contentType: "sport",
                titleid: item.title_id,
                videoLink: vidUrl,
                imgSrc: imgPath,
                retinaImgSrc: imgRetinaPath,
                title: item.title,
                epTitle: item.title,
                overlayTitle: item.series_name,
                alt: item.title,
                availExpire: availExpire,
                availExpireHover: availExpireHover,
                infoLink: prettyUrl,
                duration: item.duration + ' minutes',
                footerClass: footerClass,
                isPlayableClass: isPlayableClass,
                blurb: item.description,
                isTileLinkableClass: 'hide',
                hideOverlayClass: hideOverlayClass
            };
        } else if (titleType === 'FF') {
            //vidUrl = (item.pretty_video_url !== null && item.pretty_video_url !== '') ? item.pretty_video_url : "/videos" + item.pretty_url;
            //vidUrl = isLive ? '/' + window.siteDefaults.liveLoc + '/east.html' : vidUrl;
            availExpireHover = typeof(item.available_on) !== 'undefined' ? item.available_on : '';
            availExpire = getTuneInText(item.schedule_date, isLive);
            footerClass = availExpireHover.length === 0 ? 'tn-hidden' : '';
            imgPath = imgPath.length > 0 ? searchImagePath + imgPath : window.siteDefaults.defaultEpisodeImagePath;
            imgRetinaPath = imgRetinaPath.length === 0 ? searchImagePath + imgRetinaPath : window.siteDefaults.defaultEpisodeImagePath;
            data = {
                contentType: "movie",
                titleid: item.title_id,
                videoLink: vidUrl,
                imgSrc: imgPath,
                retinaImgSrc: imgRetinaPath,
                title: item.title,
                alt: item.title,
                availExpire: availExpire,
                availExpireHover: availExpireHover,
                infoLink: item.pretty_url,
                duration: item.duration + ' minutes',
                footerClass: footerClass,
                isPlayableClass: isPlayableClass,
                blurb: item.description,
                isTileLinkableClass: 'hide',
                hideOverlayClass: hideOverlayClass
            };

        } else if (titleType === 'E' || titleType === 'EA') {

            availExpireHover = typeof(item.available_on_hover) !== 'undefined' ? item.available_on_hover : '';
            availExpire = getTuneInText(item.schedule_date, isLive);
            footerClass = availExpireHover.length === 0 ? 'tn-hidden' : '';
            imgPath = imgPath.length > 0 ? searchImagePath + imgPath : (item.series_image_500.length > 0 ? searchImagePath + item.series_image_500 : window.siteDefaults.defaultEpisodeImagePath);
            imgRetinaPath = imgRetinaPath.length === 0 ? searchImagePath + imgRetinaPath : (item.series_image_500.length > 0 ? searchImagePath + item.series_image_500 : window.siteDefaults.defaultEpisodeImagePath);
            //vidUrl = (item.pretty_video_url !== null && item.pretty_video_url !== '') ? item.pretty_video_url : "/videos" + item.pretty_url;
            //vidUrl = vidUrl = isLive ? '/' + window.siteDefaults.liveLoc + '/east.html' : vidUrl;

            // for the schedule, the duration is in minutes
            var durationSecs = item.duration * 60;

            var epInfo = item.season_number.length > 0 ? '<span>S' + item.season_number + ' | E' + item.episode_number + '</span><span class="rating">' + item.tv_rating + '</span>' : '<span class="rating">' + item.tv_rating + '</span>';
            //var isPlayableClass = item.whats_on_now_flag === "true" ? '' : 'tn-hidden';


            // we will not use the airs on field here.
            data = {
                contentType: "episode",
                titleid: item.title_id,
                videoLink: vidUrl,
                isPlayableClass: isPlayableClass,
                belowFoldTitle: '',
                imgSrc: imgPath,
                retinaImgSrc: imgRetinaPath,
                epinfo: epInfo,
                airOn: '',
                availExpireHover: availExpireHover,
                availExpire: availExpire,
                footerClass: footerClass,
                hideOverlayClass: '',
                theAdHTML: '',
                epInfoLink: item.pretty_url,
                showTitle: item.series_name,
                alt: item.series_name,
                title: item.title,
                duration: Tn.formatDuration(durationSecs),
                blurb: item.description,
                isTileLinkableClass: 'hide',
                dataContentType: 'show',
                hideOverlayClass: hideOverlayClass

            };
        } else {
            console.log('this must be a special show');
            console.log(item.title);
            availExpireHover = typeof(item.available_on) !== 'undefined' ? item.available_on : '';
            availExpire = getTuneInText(item.schedule_date, isLive);
            footerClass = availExpireHover.length === 0 ? 'tn-hidden' : '';
            imgPath = imgPath.length > 0 ? searchImagePath + imgPath : window.siteDefaults.defaultEpisodeImagePath;
            imgRetinaPath = imgRetinaPath.length === 0 ? searchImagePath + imgRetinaPath : window.siteDefaults.defaultEpisodeImagePath;
            data = {
                contentType: "special",
                titleid: item.title_id,
                videoLink: vidUrl,
                imgSrc: imgPath,
                retinaImgSrc: imgRetinaPath,
                title: item.title,
                alt: item.title,
                availExpire: availExpire,
                availExpireHover: availExpireHover,
                infoLink: item.pretty_url,
                duration: item.duration + ' minutes',
                footerClass: footerClass,
                isPlayableClass: isPlayableClass,
                blurb: item.description,
                isTileLinkableClass: 'hide',
                hideOverlayClass: hideOverlayClass
            };
        }
        return data;
    }

    function updateSearchSize() {
        if (Tn.currentPage !== 'page-search') {
            return;
        }


        $('#page-search .search-item .main-content').each(function() {
            var el = $(this);
            var w = el.width();
            var h = parseInt(w * 360 / 640, 10);
            el.height(h);
            var captionHt = el.find('.caption').outerHeight();
            el.parent().height(h + captionHt);
            window.tnOverlays.resizeOverlay(el);
        });

    }

    function showLessSearch(elem) {
        //console.log('showLessSearch5');
        var $elem = $(elem);
        var resultsSel = $elem.data('section');
        console.log(resultsSel);
        // we want to remove all but the first result
        // 
        var searchItems = $(resultsSel).find('.search-item');
        for (var s = 1; s < searchItems.length; s++) {
            var item = $(searchItems[s]);
            item.remove();
        }

        // we are scrolling #page-search so the header of the section we just closed is in view
        var hdrSel = resultsSel.replace('.results', '');
        var hdr = $('.section-hdr' + hdrSel);
        //var topPos = hdr.data('toppos');
        //console.log(topPos);
        
        

        //$('#page-search').scrollTop(-topPos);

        if (resultsSel.indexOf('.airingsoon.') !== -1) {
            // we need to set the titleIdTmpSched value to be the last one displayed in the section
            // this is because we are deduping the schedule data so only the next airing instance of a
            // particular episode is displayed
            titleIdTmpSched = $(resultsSel).find('.search-item').last().find('.main-content').attr('data-id');
        }


        $elem.addClass('tn-hidden');
        var moreBtn = $elem.parent().find('.showMoreBtn.morebtn[data-section="' + resultsSel + '"]');
        // reset the data-page to original value
        // if we decide to do more paging instead of just show all or none, this will need to be adjusted
        moreBtn.attr('data-page', 1);
        moreBtn.removeClass('tn-hidden');

        scrollPageToSection(hdr);
    }

    function scrollPageToSection($elem){
        //console.log('scrollPageToSection');
        
        var page = $('#page-search');
        var container = page.find(' > .container');
        // this is the top position of the section header relative to document
        var hdrOffset = $elem.offset().top;
        var contOffset = container.offset().top;
        var pagePadding = 0;
        try{
            pagePadding = page.css('paddingTop').replace('px', '').replace('em','');
            pagePadding = parseInt(pagePadding, 10);
        } catch(e){}
        
        var scrollToPos;
        // we will subtract the smaller number from the larger number to find
        // the distance between the top of the scrolling .container (inside page element) and
        // the top of the section header
        if(hdrOffset > contOffset){
            scrollToPos = hdrOffset - contOffset;
        } else {
            scrollToPos = contOffset - hdrOffset;
        }
        /*
        console.log('hdrOffset: ' + hdrOffset);
        console.log('contOffset: ' + contOffset );
        console.log('pagePadding: ' + pagePadding );
        */

        page.animate({
            scrollTop: scrollToPos + pagePadding
        }, 500);
    }

    function showMoreSearch(elem) {
        //console.log('showMoreSearch');
        //console.log(elem);

        // this needs to get the query info needed and call doSearch()
        var options = {};
        var $elem = $(elem);

        // this will also need to adjust the toggle button
        // assuming we are loading all or closing the area

        options.resultsSel = $elem.data('section');
        var hdrSel = options.resultsSel.replace('.results', '');
        var hdr = $('.section-hdr' + hdrSel);
        scrollPageToSection(hdr);


        var nextPage = parseInt($elem.data('page'), 10) + 1;
        $elem.attr('data-page', nextPage);

        options.pageIndex = nextPage;

        // we need the type
        if (options.resultsSel.indexOf('.watch-now') !== -1) {
            options.type = 'movie|episode|clip';
            options.section = 'watch-now';
            options.offset = 1;
        } else if (options.resultsSel.indexOf('.airingsoon') !== -1) {
            options.type = 'schedule';
            options.section = 'airingsoon';
            options.offset = nextPage;
        } else if (options.resultsSel.indexOf('.mwtw-search') !== -1) {
            options.type = 'mwtw';
            options.section = 'mwtw';
            options.offset = nextPage;
        }
        if (!options.type) {
            console.error('search type was not defined');
            return;
        }

        //console.log(options);
        Tn.isSearchShowMore = true;
        $elem.addClass('tn-hidden');
        var lessBtn = $elem.parent().find('.showMoreBtn.less[data-section="' + options.resultsSel + '"]');
        //console.log('showMore');
        lessBtn.removeClass('tn-hidden');
        lessBtn.off('click').on('click', function() {
            showLessSearch(this);
        });
        doSearch(options);


    }



    function doSearch(options) {
        delete Tn.searchTimer;
        var val = $('.search-field').val(),
            learnMoreTxt = "",
            results = [],
            resultsSched = [],
            resultsMwtw = [];

        var resultsEl = $('#page-search').find('.search-results');
        var maxDisplayedResults = isPhone ? 1 : (tnVars.isMobile() ? 24 : 48);
        var offset, type, dataLength;
        var opts = options ? options : {};
        dataLength = defaultLength;
        offset = 1;

        // we are assuming here there is only up to 2 pages
        if (opts.offset) {
            dataLength = defaultLength - opts.offset;
            offset = opts.offset;
        }

        type = opts.type ? opts.type : 'show|movie|episode|clip|schedule|mwtw';

        var typeArr = type.split('|');
        //console.log(typeArr);

        Tn.searchQueryVal = val;
        if (!Tn.isSearchShowMore) {
            // this is a new search
            titleIdTmpSched = null;
            resultsEl.empty();
            if (!val || val.length === 0) {
                resultsEl.append('<div class="section-hdr">Enter a phrase to search for</div>');
                return;
            }
        } else {
            // this is show more of the current search
            maxDisplayedResults = tnVars.isMobile() ? 24 : 48;
            //resultsEl = $(options.resultsSel);
        }

        var searchParams = {
            type: type,
            offset: offset,
            length: dataLength,
            query: val
        };

        val = val.toLowerCase();
        var searchQueryTmp = Tn.fm(searchQueryUrlTemplate, searchParams);

        //var resultsToDisplay = !Tn.isSearchShowMore ? maxDisplayedResults : maxShowMoreResults;
        //console.log('resultsToDisplay: ' + resultsToDisplay);
        var searchQuery = searchQueryTmp.replace(/ /g, "_");
        //console.log(searchQueryTmp);
        //console.log(searchQuery);


        $.ajax({
            url: searchQuery,
            dataType: 'json'
        }).done(function(data) {
            //console.log('data retrieved');
            //first grab the info on result types and numbers from the data
            var numShows = data.metaResults.show;
            var numMovies = data.metaResults.movie;
            var numEpisodes = data.metaResults.episode;
            var numClips = data.metaResults.clip;
            //var totalAvailableResults = numShows + numMovies + numEpisodes + numClips;
            var totalAvailableResults = numMovies + numEpisodes + numClips;
            var maxResults = (totalAvailableResults < maxDisplayedResults) ? totalAvailableResults : maxDisplayedResults;

            var totalSchedResults = data.metaResults.schedule;
            var maxResultsSchedule = (totalSchedResults < maxDisplayedResults) ? totalSchedResults : maxDisplayedResults;

            // mwtw section vars - TODO - this is not calculated correctly
            var totalMwtwResults = data.metaResults.mwtw;
            var maxResultsMwtw = (totalMwtwResults < maxDisplayedResults) ? totalMwtwResults : maxDisplayedResults;


            //console.log ('shows: '+ numShows + 'episodes: ' + numEpisodes);

            var resultsDisplayed = 0;
            var schedResultsDisplayed = 0;
            var mwtwResultsDisplayed = 0;


            var showInd, movieInd, epInd, clipInd, schedInd, mwtwInd;
            for (var a = 0; a < typeArr.length; a++) {
                if (typeArr[a] === 'show') {
                    showInd = a;
                } else if (typeArr[a] === 'movie') {
                    movieInd = a;
                } else if (typeArr[a] === 'episode') {
                    epInd = a;
                } else if (typeArr[a] === 'clip') {
                    clipInd = a;
                } else if (typeArr[a] === 'schedule') {
                    schedInd = a;
                } else if (typeArr[a] === 'mwtw') {
                    mwtwInd = a;
                } else {
                    console.log('some weird search type was passed in: ' + typeArr[a]);
                }
            }


            // since we are passing in different type queries, we will need to generate these based on the metaResults

            //showInd, movieInd, epInd, clipInd, schedInd, mwtwInd;

            var showData = typeof(showInd) !== 'undefined' ? data.results[showInd] : [];
            var movieData = typeof(movieInd) !== 'undefined' ? data.results[movieInd] : [];
            var epData = typeof(epInd) !== 'undefined' ? data.results[epInd] : [];
            var clipData = typeof(clipInd) !== 'undefined' ? data.results[clipInd] : [];
            var schedData = typeof(schedInd) !== 'undefined' ? data.results[schedInd] : [];
            var mwtwData = typeof(mwtwInd) !== 'undefined' ? data.results[mwtwInd] : [];

            var watchNowData = [];

            // we are combinging these into one array of objects
            for(var e=0;e<epData.length; e++){
                watchNowData.push(epData[e]);
            }
            for(var e=0;e<clipData.length; e++){
                watchNowData.push(clipData[e]);
            }
            for(var e=0;e<movieData.length; e++){
                watchNowData.push(movieData[e]);
            }

            //console.log(watchNowData);


            //now iterate over the results to populate learn more text and video results
            for (var i = 0; i < showData.length; i++) {
                var result = showData[i];
                //this result is for learnMore
                var showTitle = result.title;
                var showURL = result.pretty_url;
                var divider = i === showData.length -1 ? '' : ', ';
                learnMoreTxt += Tn.fm('<span class="shows"><a href="{1}">{0}</a>{2}</span>', showTitle, showURL, divider);
                //console.log(learnMoreTxt);
            }

            // we want franchise matches to display first, so we are looking at movies and clips before movies
            // for the watch now section, we need to pull in the same result set
            // we cannot use the offset because we are pulling multiple search types and the offset 
            // applies to each type instead of the total results set
            // so if there is only one clip and we set the offset to 2, the 1 clip will not be retrieved
            // 

            
            var start = 0;
            if (Tn.isSearchShowMore) {
                start = 1;
            }

            for (var i = start; i < watchNowData.length && (resultsDisplayed < maxResults); i++) {
                var result = watchNowData[i];
                //console.log(result.title + " " + result.contentType +  " " + result.isplayable); 

                if (resultsDisplayed < maxResults && (result.is_playable === "true" || result.isplayable === "true")) {
                    var ep;
                    if (result.contentType === "episode") {
                        ep = getEpisodeData(result);
                        //console.log(ep);
                        results.push({
                            contentType: ep.contentType,
                            ep: ep
                        });
                    } else if (result.contentType === "clip") {
                            ep = getClipData(result);
                        //console.log(ep);
                        results.push({
                            contentType: ep.contentType,
                            ep: ep
                        });
                    } else if(result.contentType === "movie") {
                        ep = getMovieData(result);
                        //console.log(ep);
                        results.push({
                            contentType: ep.contentType,
                            ep: ep
                        });
                        
                    }
                    resultsDisplayed++;
                }

            }

            var onNowFlagIndex = 0;
            // if there is a live show in the results, we do not want to display what came on before it
            for (var i = 0; i < schedData.length; i++) {
                if (schedData[i].whats_on_now_flag === 'true') {
                    onNowFlagIndex = i;
                }
            }

            for (var i = onNowFlagIndex; i < schedData.length && (schedResultsDisplayed < maxResultsSchedule); i++) {
                var result = schedData[i];
                if (result.contentType === "schedule" && result.isplayable === 'false') {
                    var titleId = result.title_id;
                    if (titleId !== titleIdTmpSched) {
                        //console.log(result.title + " " + result.contentType +  " " + result.isplayable); 

                        if (schedResultsDisplayed < maxResultsSchedule) {
                            var ep = getSchedData(result);
                            titleIdTmpSched = titleId;
                            //console.log(ep);
                            resultsSched.push({
                                contentType: ep.contentType,
                                ep: ep
                            });
                            schedResultsDisplayed++;
                        }

                    }
                }

            }

            for (var i = 0; i < mwtwData.length && (mwtwResultsDisplayed < maxResultsMwtw); i++) {
                var result = mwtwData[i];
                //console.log(result.title);
                if (result.contentType === "mwtw" && result.isplayable === 'false') {
                    if (mwtwResultsDisplayed < maxResultsMwtw) {
                        var ep = getEpisodeData(result);
                        //console.log(ep);
                        resultsMwtw.push({
                            contentType: ep.contentType,
                            ep: ep
                        });
                        mwtwResultsDisplayed++;
                    }
                }
            }

            if (learnMoreTxt.length > 0) {
                resultsEl.append('<div class="learnmore"><span class="title">Learn More About</span>' + learnMoreTxt + '</div>');
                resultsEl.find('.shows a').on('click', function(event) {
                    event.preventDefault();
                    Tn.setUrl($(this).attr("href"), true, 'page-generic');
                });
            }

            // for analytics we want the total displayed results of all sections
            // var resultsDisplayed = 0;
            //var schedResultsDisplayed = 0;
            //var mwtwResultsDisplayed = 0;

            var totalAnalyticsResults = resultsDisplayed + schedResultsDisplayed + mwtwResultsDisplayed;
            var container;

            // display watch now results
            if (results.length > 0) {
                if (!Tn.isSearchShowMore) {
                    resultsEl.append('<div class="section-hdr withresults watch-now">Watch Now</div>');
                    //console.log( resultsEl.find('.section-hdr.watch-now').position() );
                    container = $('<div class="results watch-now row"></div>');
                    container.appendTo(resultsEl);
                    
                } else {
                    container = $(options.resultsSel);
                }


                $.each(results, function(key, sr) {
                    var item = $('<div class="search-item col-xs-6 col-sm-6 col-md-6 col-lg-4"></div>');
                    item.appendTo(container);
                    //console.log ('ep:\n ' + sr.ep);
                    if (sr.contentType === "episode" || sr.contentType === "clip") {
                        //load episode div
                        Tn.initializeShowOverlay(item, sr.ep);
                    } else {
                        //load movie div
                        var divItem = Tn.fm(Tn.movieItemTemplate, sr.ep);
                        item.append(divItem);
                        window.tnOverlays.init(item.find('.main-content'));
                    }


                    //container.append('<div class="search-item col-xs-6 col-sm-4 col-md-3 col-lg-3"><img style="width:100%;height:100%;" src="http://placehold.it/640x360&text=Falling%20skies" /></div>');
                });
                if (isPhone && !Tn.isSearchShowMore && totalAvailableResults > maxResults) {
                    resultsEl.append('<div class="showMoreBtn morebtn" data-section=".results.watch-now" data-page="1"><span>Show More <i class="fa fa-caret-down arrow-selector"></i></span></div>');
                    resultsEl.append('<div class="showMoreBtn less tn-hidden" data-section=".results.watch-now"><span>Show Less <i class="fa fa-caret-up arrow-selector"></i></span></div>');
                }
            }

            // display airing soon results
            if (resultsSched.length > 0) {

                if (!Tn.isSearchShowMore) {
                    resultsEl.append('<div class="section-hdr withresults airingsoon">Airing Soon</div>');
                    container = $('<div class="results airingsoon row"></div>');
                    container.appendTo(resultsEl);
                } else {
                    container = $(options.resultsSel);
                }

                $.each(resultsSched, function(key, sr) {
                    var item = $('<div class="search-item col-xs-6 col-sm-6 col-md-6 col-lg-4"></div>');
                    item.appendTo(container);
                    var divItem;
                    if (sr.contentType === "episode") {
                        //load episode div
                        Tn.initializeShowOverlay(item, sr.ep);
                    } else if (sr.contentType === "movie") {
                        //load movie div
                        divItem = Tn.fm(Tn.movieItemTemplate, sr.ep);
                        item.append(divItem);
                        window.tnOverlays.init(item.find('.main-content'));
                    } else if (sr.contentType === "sport") {
                        divItem = Tn.fm(sportItemTemplate, sr.ep);
                        item.append(divItem);
                        window.tnOverlays.init(item.find('.main-content'));
                    } else {
                        divItem = Tn.fm(defaultItemTemplate, sr.ep);
                        item.append(divItem);
                        window.tnOverlays.init(item.find('.main-content'));
                    }

                    if (sr.ep.isPlayableClass === '') {
                        item.find('.main-content').prepend('<div class="on-now ">On Now</div>');
                    }
                    //<div class="on-now ">On Now</div>
                    //container.append('<div class="search-item col-xs-6 col-sm-4 col-md-3 col-lg-3"><img style="width:100%;height:100%;" src="http://placehold.it/640x360&text=Falling%20skies" /></div>');
                });
                if (isPhone && !Tn.isSearchShowMore && totalSchedResults > maxResultsSchedule) {
                    resultsEl.append('<div class="showMoreBtn morebtn" data-section=".results.airingsoon" data-page="1"><span>Show More <i class="fa fa-caret-down arrow-selector"></span></div>');
                    resultsEl.append('<div class="showMoreBtn less tn-hidden" data-section=".results.airingsoon"><span>Show Less <i class="fa fa-caret-up arrow-selector"></span></div>');
                }
            }

            // display mwtw results
            if (resultsMwtw.length > 0) {
                if (!Tn.isSearchShowMore) {
                    resultsEl.append('<div class="section-hdr withresults mwtw-search">More Ways To Watch</div>');
                    container = $('<div class="results mwtw-search row"></div>');
                    container.appendTo(resultsEl);
                } else {
                    container = $(options.resultsSel);
                }

                $.each(resultsMwtw, function(key, sr) {
                    var item = $('<div class="search-item col-xs-6 col-sm-6 col-md-6 col-lg-4"></div>');
                    item.appendTo(container);
                    //console.log ('ep:\n ' + sr.ep);
                    // we are assuming that thesea are all episodes
                    Tn.initializeShowOverlay(item, sr.ep);

                    //container.append('<div class="search-item col-xs-6 col-sm-4 col-md-3 col-lg-3"><img style="width:100%;height:100%;" src="http://placehold.it/640x360&text=Falling%20skies" /></div>');
                });
                if (isPhone && !Tn.isSearchShowMore && totalMwtwResults > maxResultsMwtw) {
                    resultsEl.append('<div class="showMoreBtn morebtn" data-section=".results.mwtw-search" data-page="1"><span>Show More <i class="fa fa-caret-down arrow-selector"></span></div>');
                    resultsEl.append('<div class="showMoreBtn less tn-hidden" data-section=".results.mwtw-search"><span>Show Less <i class="fa fa-caret-up arrow-selector"></span></div>');
                }
            }

            if (results.length === 0 && resultsMwtw.length === 0 && resultsSched.length === 0) {
                resultsEl.append('<div class="section-hdr">No results found</div>');
            } else {
                updateSearchSize();
            }

            // get top positions of headers
            resultsEl.find('.showMoreBtn.morebtn').off('click').on('click', function() {
                showMoreSearch(this);
            });
            

            try {
                tntSearchResults(searchQueryTmp, totalAnalyticsResults);
            } catch (e) {}
        }).fail(function() {
            resultsEl.append('<div class="section-hdr">No results found</div>');
            // the analytics team is looking at this to see if we want a call on failed attempts...which would include the stop words
            tntSearchResults(searchQueryTmp, 0);
            //Tn.alert("Failed to load idol search data");
        });
        //});

    }
}(window.tnVars, window.Tn, jQuery));

$('body').on('pageresize', window.searchObj.updateSearchSize);
$('body').on('pageshown', function(event, pageId) {
    if (pageId !== 'page-search') {
        return;
    }
    var page = $('#' + pageId);


    // Set the focus on the search field
    // 
    // 
    setTimeout(function() {
        //console.log('setting focus on the search field');
        page.find('.search-field').focus().blur().focus().select();
    }, 1000);


    // Page was already shown, so just call an update when the page is shown again
    if (Tn.searchPageInitialized) {
        window.searchObj.updateSearchSize();
        return;
    }

    Tn.searchPageInitialized = true;
    Tn.isSearchShowMore = false;



    // See if there is a search field on this page

    page.find('.search-field').keyup(function(e) {
        //console.log('keyup');
        //console.log(e.keyCode);
        if (Tn.searchTimer) {
            clearTimeout(Tn.searchTimer);
        }

        Tn.isSearchShowMore = false;
        Tn.searchTimer = setTimeout(window.searchObj.doSearch, 500);

        if (window.tnVars.isMobile() && e.keyCode === 13) {
            // this will blur the field if the user presses Go on the keyboard
            $(this).blur();
        }
    });

    window.searchObj.doSearch();

    function androidSoftKeyHideFix(page, selectorName) {
        page.find(selectorName).on('focus', function(event) {
            page.find(selectorName).off('focus');
            console.log('androidSoftKeyHideFix');
            $('body').on('touchmove', function(event) {
                $('body').off('touchmove');
                $('#focusHack').focus();
                console.log('focusing on focusHack');
                setTimeout(function() {
                    $('#focusHack').blur();
                    $('#focusHack').focus();
                    $('#focusHack').blur();
                    androidSoftKeyHideFix(page, selectorName);
                }, 300);
            });
        });
    }

    // we are fixing an issue with some android phones where the search field is not releasing focus when the keyboard is closed
    // either from the back button or by scrolling the results list
    // so we are force closing the keyboard br focusing an another element on the page (#focusHack)
    // this did not work on touchstart, but seems to work decently on touch move
    if (window.tnVars.isAndroid && !window.tnVars.isAndroidChrome && window.tnVars.isPhone()) {
        androidSoftKeyHideFix(page, '.search-field');
    }


});