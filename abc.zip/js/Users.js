/**
 * @class Tn.Users
 * @singleton
 * Library for dealing with users from the [Gigya platform](http://www.gigya.com/).
 * It allows you to use the capabilities of Gigya without having to know the internal specifics.
 * Make sure to call Tn.Users.initialize when you page starts up
 *
 * Example of initializing the users class and checking for logged in user :
 *
 *     @example
 *     $("body").append("<p>Initializing user class...</p>");
 *     Tn.Users.initialize({
 *      onStartup: function(uid) {
 *          if (!uid) {
 *              $("body").append("<p>No user logged in</p>");
 *              return;
 *          }
 *          $("body").append(Tn.fm("<p>Logged in user is {0}</p>", uid));
 *      }
 *     });
 *
 * This example shows how to initiate a login when a link is clicked
 *
 *     @example
 *     $('body').append('<a href"#">Click me to log in</a>').click(function() {
 *      Tn.Users.logIn();
 *     });
 */
(function(Tn, jQuery, gigya, document, window, undefined) {
    if (!gigya) {
        console.error("Gigya not installed, user library not loaded!");
        return;
    }

    // Resets any UI forms with the latest values

    function updateProfileNames(firstName, lastName, email) {
        $('.editProfile').not('.noupdate').html(Tn.fm("Hi, {firstName}", {
            firstName: firstName || lastName || email || 'unknown user'
        }));
        $('.profile-fullname').html(Tn.fm("{firstName} {lastName}", {
            firstName: firstName,
            lastName: lastName
        }));
        $('.profile-firstname-value').val(firstName || "");
        $('.profile-lastname-value').val(lastName || "");
        $('.profile-email-value').val(email || "");
        $('.profile-info-oldpassword, .profile-info-newpassword, .profile-info-confirmpassword').val("");
    }

    function updateProfileSize() {
        $('#profile-contents-three .search-item .main-content').each(function() {
            var el = $(this);
            var w = el.width();
            var h = parseInt(w * 360 / 640, 10);
            el.height(h);

            window.tnOverlays.resizeOverlay(el);
        });
    }

    function updateProfileInfo() {
        if (!Tn.currentUser) {
            return;
        }
        updateProfileNames(Tn.currentUser.profile.firstName, Tn.currentUser.profile.lastName, Tn.currentUser.profile.email);
        $('#profile-dialog').attr('provider', Tn.Users.getPref("provider", "")).toggleClass('social', Tn.currentUser.provider.length === 0 ? false : true);
    }

    Tn.Users = {
        prefs: {},
        emailAlreadyExistsMsgKey: 'email_already_exists',
        emailAlreadyExistsMsg: 'An account with this email address already exists. Please log in using this email address or a social account. You may also request a new password using this email address.',
        defaultLoginError: 'We experienced a problem with your profile. Please try again.',
        loginPasswordInvalidErrMsg: 'We could not find a profile with that email address and password combination.',
        vidHistoryPrefix: 'id',
        setBrowser: function(uid, uidSignature, signatureTimestamp){
            var browserInfo = Tn.Users.getBrowser();
            //console.log('setBrowser: ' + browserInfo);
            var response = $.ajax({
                url: "/profile/index.json",
                method: "get",
                data: {
                    browser: browserInfo,
                    uid: uid,
                    uidSignature: uidSignature,
                    signatureTimestamp: signatureTimestamp
                },
                cache: true, // Only need this set once
                dataType: "json",
                success: function(data) {
                    if(data.status == '200'){
                        console.log('setBrowser ' + JSON.stringify(data));
                    } //else {
                    //     console.log('setBrowser failed.  data:' + JSON.stringify(data));
                    // }
                },
                error: function() {
                    console.error("Failed setBrowser: ", arguments);
                }
            });
        },
        getBrowser: function(){
            var unknown = 'unknown';
            //browser
            var nVer = navigator.appVersion;
            var nAgt = navigator.userAgent;
            var browser = navigator.appName;
            var version = '' + parseFloat(navigator.appVersion);
            var majorVersion = parseInt(navigator.appVersion, 10);
            var nameOffset, verOffset, ix, browserInfo;

            // Opera
            if ((verOffset = nAgt.indexOf('Opera')) != -1) {
                browser = 'Opera';
                version = nAgt.substring(verOffset + 6);
                if ((verOffset = nAgt.indexOf('Version')) != -1) {
                    version = nAgt.substring(verOffset + 8);
                }
            }
            // MSIE
            else if ((verOffset = nAgt.indexOf('MSIE')) != -1) {
                browser = 'Microsoft Internet Explorer';
                version = nAgt.substring(verOffset + 5);
            }

            //IE 11 no longer identifies itself as MS IE, so trap it
            //http://stackoverflow.com/questions/17907445/how-to-detect-ie11
            else if ((browser == 'Netscape') && (nAgt.indexOf('Trident/') != -1)) {

                browser = 'Microsoft Internet Explorer';
                version = nAgt.substring(verOffset + 5);
                if ((verOffset = nAgt.indexOf('rv:')) != -1) {
                    version = nAgt.substring(verOffset + 3);
                }

            }

            // Chrome
            else if ((verOffset = nAgt.indexOf('Chrome')) != -1) {
                browser = 'Chrome';
                version = nAgt.substring(verOffset + 7);
            }
            // Safari
            else if ((verOffset = nAgt.indexOf('Safari')) != -1) {
                browser = 'Safari';
                version = nAgt.substring(verOffset + 7);
                if ((verOffset = nAgt.indexOf('Version')) != -1) {
                    version = nAgt.substring(verOffset + 8);
                }

                // Chrome on iPad identifies itself as Safari. Actual results do not match what Google claims
                //  at: https://developers.google.com/chrome/mobile/docs/user-agent?hl=ja
                //  No mention of chrome in the user agent string. However it does mention CriOS, which presumably
                //  can be keyed on to detect it.
                if (nAgt.indexOf('CriOS') != -1) {
                    //Chrome on iPad spoofing Safari...correct it.
                    browser = 'Chrome';
                    //Don't believe there is a way to grab the accurate version number, so leaving that for now.
                }
            }
            // Firefox
            else if ((verOffset = nAgt.indexOf('Firefox')) != -1) {
                browser = 'Firefox';
                version = nAgt.substring(verOffset + 8);
            }
            // Other browsers
            else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) < (verOffset = nAgt.lastIndexOf('/'))) {
                browser = nAgt.substring(nameOffset, verOffset);
                version = nAgt.substring(verOffset + 1);
                if (browser.toLowerCase() == browser.toUpperCase()) {
                    browser = navigator.appName;
                }
            }
            // trim the version string
            if ((ix = version.indexOf(';')) != -1) version = version.substring(0, ix);
            if ((ix = version.indexOf(' ')) != -1) version = version.substring(0, ix);
            if ((ix = version.indexOf(')')) != -1) version = version.substring(0, ix);

            majorVersion = parseInt('' + version, 10);
            if (isNaN(majorVersion)) {
                version = '' + parseFloat(navigator.appVersion);
                majorVersion = parseInt(navigator.appVersion, 10);
            }

            // mobile version
            var mobile = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/.test(nVer);

            // system
            var os = unknown;
            var clientStrings = [
                {s:'Windows 3.11', r:/Win16/},
                {s:'Windows 95', r:/(Windows 95|Win95|Windows_95)/},
                {s:'Windows ME', r:/(Win 9x 4.90|Windows ME)/},
                {s:'Windows 98', r:/(Windows 98|Win98)/},
                {s:'Windows CE', r:/Windows CE/},
                {s:'Windows 2000', r:/(Windows NT 5.0|Windows 2000)/},
                {s:'Windows XP', r:/(Windows NT 5.1|Windows XP)/},
                {s:'Windows Server 2003', r:/Windows NT 5.2/},
                {s:'Windows Vista', r:/Windows NT 6.0/},
                {s:'Windows 7', r:/(Windows 7|Windows NT 6.1)/},
                {s:'Windows 8.1', r:/(Windows 8.1|Windows NT 6.3)/},
                {s:'Windows 8', r:/(Windows 8|Windows NT 6.2)/},
                {s:'Windows NT 4.0', r:/(Windows NT 4.0|WinNT4.0|WinNT|Windows NT)/},
                {s:'Windows ME', r:/Windows ME/},
                {s:'Android', r:/Android/},
                {s:'Open BSD', r:/OpenBSD/},
                {s:'Sun OS', r:/SunOS/},
                {s:'Linux', r:/(Linux|X11)/},
                {s:'iOS', r:/(iPhone|iPad|iPod)/},
                {s:'Mac OS X', r:/Mac OS X/},
                {s:'Mac OS', r:/(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/},
                {s:'QNX', r:/QNX/},
                {s:'UNIX', r:/UNIX/},
                {s:'BeOS', r:/BeOS/},
                {s:'OS/2', r:/OS\/2/},
                {s:'Search Bot', r:/(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask Jeeves\/Teoma|ia_archiver)/}
            ];
            for (var id in clientStrings) {
                var cs = clientStrings[id];
                if (cs.r.test(nAgt)) {
                    os = cs.s;
                    break;
                }
            }

            var osVersion = unknown;

            if (/Windows/.test(os)) {
                osVersion = /Windows (.*)/.exec(os)[1];
                os = 'Windows';
            }

            switch (os) {
                case 'Mac OS X':
                    osVersion = /Mac OS X (10[\.\_\d]+)/.exec(nAgt)[1];
                    break;

                case 'Android':
                    osVersion = /Android ([\.\_\d]+)/.exec(nAgt)[1];
                    break;

                case 'iOS':
                    osVersion = /OS (\d+)_(\d+)_?(\d+)?/.exec(nVer);
                    osVersion = osVersion[1] + '.' + osVersion[2] + '.' + (osVersion[3] | 0);
                    break;

            }
            // Need to handle quotes since they want a string in the gigya field
            browserInfo = JSON.stringify({
                    browser: browser.replace(/"/g, '&quote'),
                    browserVersion: version.replace(/"/g, '&quote'),
                    mobile: mobile,
                    os: os.replace(/"/g, '&quote'),
                    osVersion: osVersion.replace(/"/g, '&quote')
                });
            browserInfo = browserInfo.replace(/"/g, '\\"');
            return browserInfo;
        },


        /**
         * Set the terms flad with first login
         */
        setTerms: function() {
            var dataObj = { "terms": true, "terms072315": true };
            gigya.accounts.setAccountInfo({
                data: dataObj,
                callback: function(o) {
                    if (o.errorCode != 0) { // Change from '!==' to '!=' per Gigya
                        console.error("Error adding preferences", o.errorDetails);
                        return;
                    } else {
                        console.error("Terms were save for first time users");
                    }
                }
            });
        },
        /**
         * Sets a preference on the system
         * @param {String} name  The name of the preference
         * @param {Mixed} value The value of the preference
         */
        setPref: function(name, value) {
            if (!this.prefs) {
                this.prefs = {};
            }
            if ($.isPlainObject(name)) {
                $.extend(this.prefs, name);
            } else {
                this.prefs[name] = value;
            }
            this.syncPrefs();
        },

        /**
         * Returns the preference by the given name
         * @param  {String} name     The name of the preference
         * @param  {Mixed} defValue The default value of the preference if not found
         * @return {Mixed}          The value of the preference
         */
        getPref: function(name, defValue) {
            if (!this.prefs) {
                return defValue;
            }
            if (this.prefs[name] !== undefined) {
                return this.prefs[name];
            }
            return defValue;
        },

        /**
         * Removes the preference specified
         * @param  {String} name The name of the preference
         */
        removePref: function(name) {
            var me = this;
            name = $.isArray(name) ? name : [name];
            $.each(name, function(key, val) {
                delete me.prefs[val];
            });
            this.syncPrefs();
        },

        preloadDataForUserVideoHistory: function(){
            if (!Tn.movieData) {
                Tn.getMovieCarouselData(Tn.Users.preloadDataForUserVideoHistory, true);
            } else if(!Tn.showData){
                Tn.getCarouselData(Tn.Users.preloadDataForUserVideoHistory, true);
            }
        },

        /**
         * Clears all preferences from the queue
         */
        clearPrefs: function() {
            this.prefs = {};
            this.syncPrefs();
        },

        /**
         * @private
         * Syncs all preferences with the user service if logged in
         */
        syncPrefs: function() {
            if (!this.syncTimeout) {
                this.syncTimeout = setTimeout($.proxy(this.syncPrefsImmediately, this), 2000);
            }
            //this.syncPrefsImmediately();
        },

        /**
         * Synchs the preferences immediately, regardless of timer
         */
        syncPrefsImmediately: function() {
            // remove the sync timeout 
            if (this.syncTimeout) {
                clearTimeout(this.syncTimeout);
                delete this.syncTimeout;
            }

            // If no user currently logged in, we can't sync
            if (!Tn.currentUser) {
                return;
            }
            var newCurrentVideo = ($.isPlainObject(this.prefs.currentVideo))?this.getNewCurrentVideoFromOldCurrentVideoType(this.prefs.currentVideo):{},
                accountDataObj = $.extend({ prefs: JSON.stringify(this.prefs)}, newCurrentVideo),
                currentVideoTimeStamp = ($.isPlainObject(newCurrentVideo.myCurrentVideo) && parseInt(newCurrentVideo.myCurrentVideo.dt))?parseInt(newCurrentVideo.myCurrentVideo.dt):(new Date()).getTime();

            if($.isPlainObject(this.prefs.currentVideo) && !$.isEmptyObject(this.prefs.currentVideo)){
                Tn.localStorageWrapper.setItem('currentVideo', JSON.stringify(this.prefs.currentVideo));
                // Ensure that local storage is the most recent by adding 1.  Easiest to get to
                Tn.localStorageWrapper.setItem('currentVideoTimeStamp', currentVideoTimeStamp);
            }

            gigya.accounts.setAccountInfo({
                data: accountDataObj,
                callback: function(o) {
                    if (o.errorCode != 0) { // Change from '!==' to '!=' per Gigya
                        console.error("Error adding preferences", o.errorDetails);
                        return;
                    }
                }
            });
        },
        /**
         * Create the new current video object from the existing current video object
         */
        getNewCurrentVideoFromOldCurrentVideoType: function(currentVideoAsOldType){
            var newCurrentVideo = {};
            if(currentVideoAsOldType.playhead && currentVideoAsOldType.fullEpId && typeof(currentVideoAsOldType.url) == 'string'){
                var newCurrentVideoTimeStamp = this.getBestGuessForNewCurrentVideoTS(currentVideoAsOldType.fullEpId);
                newCurrentVideo.playhead = currentVideoAsOldType.playhead;
                newCurrentVideo.vid = currentVideoAsOldType.fullEpId;
                newCurrentVideo.type = (currentVideoAsOldType.url.indexOf('/movies/') > 0)?'movie':'episode';
                newCurrentVideo.dt = newCurrentVideoTimeStamp;
                return { myCurrentVideo: newCurrentVideo };
            }
            return {};
        },
        /**
         * Takes the current history obtained from a non-logged in session and combines it to the logged in history
         * @param  object unsavedVHPrefs unsaved video history
         * @param  object savedVHPrefs   saved video history
         * @return object                merged history
         */
        mergeVideoHistoryPref: function(unsavedVHPrefs, savedVHPrefs){
            $.each(unsavedVHPrefs, function(key, val) {
                var savedVidItem = savedVHPrefs[key],
                    playArr;
                if(!savedVidItem){
                    savedVHPrefs[key] = val;
                } else {
                    var savedVidItemPlayArr = savedVidItem.play || {},
                        unsavedVidItemPlayArr = val.play || [],
                        resortPlayArray = false;
                    for (var i = 0; i < unsavedVidItemPlayArr.length; i++) {
                        var found = false,
                            unsavedPlayItem = unsavedVidItemPlayArr[i];
                        for (var j = 0; j < savedVidItemPlayArr.length; j++) {
                            var savedPlayItem = savedVidItemPlayArr[j];
                            if(unsavedPlayItem.st == savedPlayItem.st){ // Since start time is in msec, I am assuming {}.os will match and don't need to test that it does
                                found = true;
                            }
                        }
                        if(!found){
                            savedVidItemPlayArr.push(unsavedPlayItem);
                            resortPlayArray = true;
                        }
                    }
                    if(resortPlayArray){
                        savedVidItemPlayArr.sort(function(b, a) {
                            if (a.st > b.st) {
                                return -1;
                            }
                            if (a.st < b.st) {
                                return 1;
                            }
                            return 0;
                        });
                    }
                }
            });
            return savedVHPrefs;
        },
        /**
         * Takes the current live history obtained from a non-logged in session and combines it to the logged in history
         * @param  array unsavedLHArr unsaved video history
         * @param  array savedLHArr   saved video history
         * @return array              merged history
         */
        mergeLiveHistoryPref: function(unsavedLHArr, savedLHArr){
            var resortPlayArray = false;
            for (var i = 0; i < unsavedLHArr.length; i++) {
                var found = false,
                    unsavedPlayItem = unsavedLHArr[i];
                for (var j = 0; j < savedLHArr.length; j++) {
                    var savedPlayItem = savedLHArr[j];
                    if(unsavedPlayItem.dt == savedPlayItem.dt){ // Since start time is in msec, I am assuming {}.ai will match and don't need to test that it does
                        found = true;
                    }
                }
                if(!found){
                    savedLHArr.push(unsavedPlayItem);
                    resortPlayArray = true;
                }
            }
            if(resortPlayArray){
                savedLHArr.sort(function(b, a) {
                    if (a.dt > b.dt) {
                        return -1;
                    }
                    if (a.dt < b.dt) {
                        return 1;
                    }
                    return 0;
                });
            }
            return savedLHArr;
        },

        /**
         * currentVideo is being moved and updated based on suggestions from analytics and legal.  During transition, some platforms can 
         * use the old way to store it so we need to grab that if it is the latest.  Here we do a comparison of dates in videoHistory and in 
         * thr new currentVideo location.  The latest timestamp has the 'currentVideo' to use.
         * @param  object currentVideoBeforeLogin The currentVideo recorded before they were logged in.  Can be null
         * @param  object savedUserCurrentVideoInPrefs The currentVideo recorded in Gigya's prefs object.  Can be null
         * @param  object savedUserCurrentVideoNotInPrefs The currentVideo recorded in new Gigya location.  Can be null
         * @param  object videoHistory The videoHistory stored 
         */
        getCurrentVideoHelper: function(currentVideoBeforeLogin, savedUserCurrentVideoNotInPrefs, savedUserCurrentVideoInPrefs, useThisCurrentVideo, videoHistory, user, cb){
            var that = this;
            if($.isPlainObject(useThisCurrentVideo)){
                return useThisCurrentVideo;
            } else if($.isPlainObject(currentVideoBeforeLogin)){
                return currentVideoBeforeLogin;
            } else {
                var latestTSInVideoHistory = this.getLatestTSInVideoHistory(videoHistory),
                    latestTSInNewCurrentVideo = ($.isPlainObject(savedUserCurrentVideoNotInPrefs) && savedUserCurrentVideoNotInPrefs.dt)?parseInt(savedUserCurrentVideoNotInPrefs.dt):-1,
                    timeStampInLocalStorageCurrentVideo = this.getTSInLocalStorageCurrentVideo(),
                    // Add '1' to localStorage.  All things equal, localStorage is easiest to process.
                    sortedCurrentVideoTypes = [
                        {type: 'useCurrentVideoInPrefs', ts: latestTSInVideoHistory },
                        {type: 'newCurrentVideo', ts: latestTSInNewCurrentVideo},
                        {type: 'localStorage', ts: ((timeStampInLocalStorageCurrentVideo>0)?(timeStampInLocalStorageCurrentVideo + 1):timeStampInLocalStorageCurrentVideo)}];

                //Find the most recent timestamp and use that one
                sortedCurrentVideoTypes.sort(function(a, b) {
                    return parseInt(b.ts) - parseInt(a.ts);
                });
                if(sortedCurrentVideoTypes[0].ts === -1){
                    //Intial scenario
                    return {};
                } else if(sortedCurrentVideoTypes[0].type === 'useCurrentVideoInPrefs'){
                    // Current video in prefs does not have a time stamp so search times stamps in the associated part of prefs
                    // ( the videoHistory ) 
                    return savedUserCurrentVideoInPrefs;
                } else if(sortedCurrentVideoTypes[0].type === 'localStorage' && tnVars.canUseStorage){
                    return this.getCurrentVideoInLocalStorage();
                } else if(sortedCurrentVideoTypes[0].type === 'newCurrentVideo'){
                    // We have to use a currentVideo object without any title information.  So get the title information.
                    Tn.Users.getCurrentVideoMetaInfo(savedUserCurrentVideoNotInPrefs, user, cb);
                    return {isWaiting4MetaData: true};
                } 
            }
            console.log('HOW DID we get here?', currentVideoBeforeLogin, savedUserCurrentVideoNotInPrefs, savedUserCurrentVideoInPrefs, useThisCurrentVideo, videoHistory, user);
            return {};
        },

        getLatestTSInVideoHistory: function(videoHistory, matchThisVid){
            // find the most recent video in videoHistory.  If we need to match a vid then mathc it.
            var vHistoryTs = -1,
                done = false;
            if($.isPlainObject(videoHistory)){
                for (var vHistoryVid in videoHistory) {
                    if (!done && videoHistory.hasOwnProperty(vHistoryVid) && $.isPlainObject(videoHistory[vHistoryVid]) && videoHistory[vHistoryVid].dt) {
                        var timeStampCorrection = this.getTSCorrection4VideoHistory(videoHistory[vHistoryVid]),
                            videoHistoryTS = parseInt(videoHistory[vHistoryVid].dt) + timeStampCorrection;
                        if(videoHistoryTS && videoHistoryTS > vHistoryTs){
                            if(typeof (matchThisVid) === 'undefined'){
                                vHistoryTs = videoHistoryTS;
                            } else {
                                if(typeof(vHistoryVid) == "string" && vHistoryVid.length > 0){
                                    vHistoryVid = vHistoryVid.split(/^\D*/).pop(); // remove the id prefix just in case
                                }
                                if(matchThisVid == vHistoryVid){
                                    vHistoryTs = videoHistoryTS;
                                    done = true;
                                }
                            }
                        }
                    }
                }
            }
            return vHistoryTs;
        },

        getTSCorrection4VideoHistory: function(videoHistoryItemObj){
            var timeStampCorrection = 0,
                iosTSCorrection = 18000000;
            if($.isArray(videoHistoryItemObj.play) ){
                var playArray = videoHistoryItemObj.play,
                    mostRecentPlayItem,
                    testPlayArray = [],
                    os;
                // iOS is 5 hours off when storing dates
                for (var i = 0; i < playArray.length; i++) {
                    var playArrayItem = playArray[i],
                        testPlayArrayItem = { os: playArrayItem.os, st: playArrayItem.st};
                    if($.isPlainObject(testPlayArrayItem) && typeof(testPlayArrayItem.os) === 'string'){
                        os = testPlayArrayItem.os.toLowerCase();
                        if(os.indexOf(' ios') >= 0 && parseInt(testPlayArrayItem.st)){
                            testPlayArrayItem.st = parseInt(testPlayArrayItem.st) + iosTSCorrection; // Yes, iOS is 5 hours off
                        }
                    }
                    if(!parseInt(testPlayArrayItem.st)){
                        testPlayArrayItem.st = -1; // If it can't parseInt then we can't sort.  Make this item irrelevant inthe sort
                    }
                    testPlayArray.push(testPlayArrayItem);
                }
                testPlayArray.sort(function(a, b) {
                    return parseInt(b.st) - parseInt(a.st);
                });
                mostRecentPlayItem = testPlayArray[0];
                if(mostRecentPlayItem && typeof(mostRecentPlayItem.os) === 'string' && mostRecentPlayItem.st >0 ){
                    os = mostRecentPlayItem.os.toLowerCase();
                    if(os.indexOf(' ios') >= 0){
                        timeStampCorrection = iosTSCorrection;
                    }
                }

            }
            return timeStampCorrection;
        },

        getTSInLocalStorageCurrentVideo: function(matchThisVid){
            // find the timestamp stored in localStorage for the currentVideo
            // Local storage will hold the old type currentVideo that doesn't have a timestamp
            // Use the other localStorage entry for the timestamp'
            
            var timeStampInLocalStorageCurrentVideo = -1,
                lsCurrentVideo = this.getCurrentVideoInLocalStorage();

            if(tnVars.canUseStorage && lsCurrentVideo.fullEpId && (typeof(matchThisVid) === 'undefined' || lsCurrentVideo.fullEpId == matchThisVid)){
                var timeStampInLocalStorageCurrentVideoTmp = parseInt(Tn.localStorageWrapper.getItem('currentVideoTimeStamp'));
                timeStampInLocalStorageCurrentVideo = (timeStampInLocalStorageCurrentVideoTmp)?timeStampInLocalStorageCurrentVideoTmp:-1;
            }
            return timeStampInLocalStorageCurrentVideo;
        },
        getCurrentVideoInLocalStorage: function(){
            var lsCurrentVideo = {};
            if(tnVars.canUseStorage){
                var lsCurrentVideoTmp = Tn.localStorageWrapper.getItem('currentVideo');
                if(lsCurrentVideoTmp!=undefined){
                    console.log('Found currentVideo In local Storage');
                    if(typeof(lsCurrentVideoTmp) == 'string'){
                        lsCurrentVideo=JSON.parse(lsCurrentVideoTmp);
                    } else if(typeof(lsCurrentVideoTmp) == 'object'){
                        lsCurrentVideo=lsCurrentVideoTmp;
                    } else {
                        console.log('Problem using local storage.');
                    }
                } else {
                    console.log('Problem using local storage');
                }
            }
            return lsCurrentVideo;
        },

        getBestGuessForNewCurrentVideoTS: function(vid){
            var theTSInMatchingVideoHistory = this.getLatestTSInVideoHistory(this.prefs.videoHistory, vid),
                theTSInLocalStorageCurrentVideo = this.getTSInLocalStorageCurrentVideo(vid);
            if(theTSInMatchingVideoHistory === -1 && theTSInLocalStorageCurrentVideo === -1){
                return (new Date()).getTime();
            } else if(theTSInMatchingVideoHistory >= theTSInLocalStorageCurrentVideo){
                return theTSInMatchingVideoHistory;
            } else {
                return theTSInLocalStorageCurrentVideo;
            }
        },
        /**
         * currentVideo is being moved and updated based on suggestions from analytics and legal.  During transition, some platforms can 
         * use the old way to store it so we need to grab that if it is the latest.  Here we did a comparison of dates in videoHistory  
         * and in the new currentVideo location already.  The latest timestamp has the 'currentVideo' to use.  We discovered the new currentVideo
         * is the latest so we are pulling the meta data.
         * @param  object currentVideoBeforeLogin The currentVideo recorded before they were logged in.
         * @param  object savedUserCurrentVideoInPrefs The currentVideo recorded in Gigya's prefs object.
         * @param  object savedUserCurrentVideoNotInPrefs The currentVideo recorded in new Gigya location.
         * @param  object videoHistory The videoHistory stored 
         */
        getCurrentVideoMetaInfo: function(currentVideo, user, cb){
            var urlTemplate = 'http://www.tntdrama.com/service/api/v2/movies/{vid}',
                urlTemplateData, url,
                gotCurrentVideoMetaInfo = false;
            if($.isPlainObject(currentVideo) && $.isNumeric(currentVideo.vid) && (currentVideo.type == "episode" || currentVideo.type == "movie")){
                // else get the json via ajax and call the callback
                if(currentVideo.type == "episode"){
                    urlTemplate = '/service/api/v2/episodes/{vid}';
                } else {
                    urlTemplate = '/service/api/v2/movies/{vid}';
                }
                url = Tn.fm(urlTemplate, {vid: currentVideo.vid});
                //url = '/service/api/v2/episodes/2011910';
                $.ajax({
                    url: url,
                    dataType: 'json'
                }).done(function(data){
                    var jsonData = {},
                        currentVideoForPrefs = {};
                    if(typeof(data) == 'string'){
                        jsonData=JSON.parse(data);
                    } else if(typeof(data) == 'object'){
                        jsonData=data;
                    } else {
                        jsonData = {};
                        currentVideoForPrefs = jsonData;
                    }
                    //continue here
                    if(jsonData.title && jsonData.videoUrl && jsonData.videoUrl.indexOf('/videos/') >= 0 && jsonData.isPlayable == true){
                        // Likely have good JSON back so populate now
                        currentVideoForPrefs.title = (jsonData.videoUrl.indexOf('/movies/') >= 0)?jsonData.title:jsonData.showName;
                        currentVideoForPrefs.fullEpId = currentVideo.vid;
                        currentVideoForPrefs.url = (jsonData.videoUrl)?jsonData.videoUrl:'/';
                        currentVideoForPrefs.playhead = (currentVideo.playhead)?currentVideo.playhead:0;
                        currentVideoForPrefs.duration = (jsonData.duration)?jsonData.duration:-1;
                        currentVideoForPrefs.season = (jsonData.seasonNum)?'Season ' + jsonData.seasonNum:'';
                        currentVideoForPrefs.episode = (jsonData.episodeNum)?'Episode ' + jsonData.episodeNum:'';
                    }
                    cb(user, currentVideoForPrefs);
                }).fail(function() {
                    cb(user, {});
                });
                // Then we need to start thinking about sending data to gigya
            } else {
                cb(user, {});
            }
        },
        /**
         * The videoHistory keys can no longer be numbers so prefix them with a string
         * @param  object videoHistory The videoHistory to be patched
         * @return object              The videoHistory to be patched
         */
        patchVideoHistoryKeys: function(videoHistory){
            var that = this;
            if(videoHistory.NaN){
                delete videoHistory.NaN;
            }
            for (var key in videoHistory) {
                if (videoHistory.hasOwnProperty(key) && key.indexOf(that.vidHistoryPrefix) === -1 ) {
                    videoHistory[that.vidHistoryPrefix + key] = videoHistory[key];
                    delete videoHistory[key];
                }
            }
            return videoHistory;
        },
        /**
         * The default set of reactions to be used across the board
         * @cfg {Array}
         */
        defaultReactions: [{
            text: 'Inspiring',
            ID: 'inspiring',
            iconImgUp: 'https://cdns.gigya.com/gs/i/reactions/icons/Inspiring_Icon_Up.png',
            tooltip: 'This is inspiring',
            feedMessage: 'Inspiring!',
            headerText: 'You think this is inspiring'
        }, {
            text: 'Innovative',
            ID: 'innovative',
            iconImgUp: 'https://cdns.gigya.com/gs/i/reactions/icons/Innovative_Icon_Up.png',
            tooltip: 'This is innovative',
            feedMessage: 'This is innovative',
            headerText: 'You think this is Innovative'
        }, {
            text: 'LOL',
            ID: 'lol',
            iconImgUp: 'https://cdns.gigya.com/gs/i/reactions/icons/LOL_Icon_Up.png',
            tooltip: 'LOL',
            feedMessage: 'LOL!',
            headerText: 'You LOL'
        }, {
            text: 'Amazing',
            ID: 'amazing',
            iconImgUp: 'https://cdns.gigya.com/gs/i/reactions/icons/Amazing_Icon_Up.png',
            tooltip: 'This is amazing',
            feedMessage: 'This is amazing!',
            headerText: 'You think this is Amazing'
        }],

        /**
         * The link to be used for the default reaction
         * @cfg {String} [reactionLink='http://tbs.com']
         */
        reactionLink: 'http://tbs.com',

        /**
         * The title to be used for the default reaction
         * @cfg {String}
         */
        reactionTitle: 'TBS Superstation',

        /**
         * The id of the container to be used to show reactions, or undefined for no reactions
         * @cfg {String}
         */
        reactionContainerId: undefined,

        /**
         * The server defined category, or undefined for no default comment
         * @cfg {String} [commentCategory=undefined]
         */
        commentCategory: undefined,

        /**
         * The container id to display default comments, or undefined for no comments
         * @cfg {String}
         */
        commentId: undefined,

        /**
         * Returns whether a user is logged
         * @return {Boolean} True if their is a user already logged in
         */
        isUserLoggedIn: function() {
            return Tn.currentUser ? true : false;
        },

        /**
         * Sets up a reaction bar at the id specified
         * @param  {String} id    The id of the div to add the reaction bar to
         * @param  {String} link  The link for the user action
         * @param  {String} title The title for the user action
         */
        setupReactions: function(id, link, title) {
            var act = new gigya.socialize.UserAction();
            act.setLinkBack(link);
            act.setTitle(title);

            gigya.socialize.showReactionsBarUI({
                barID: 'barID',
                showCounts: 'top',
                containerID: id,
                reactions: this.defaultReactions,
                userAction: act,
                showSuccessMessage: true,
                noButtonBorders: false
            });
        },

        onBeforeScreenLoadCb: function(d) {

            switch (d.nextScreen) {
                case "gigya-register-screen":
                    Tn.parseAnalytics({
                        "url_section": "/",
                        "section": "profile",
                        "subsection": "profile:" + window.siteDefaults.name.toLowerCase() + " create profile",
                        "template_type": "adbp:misc",
                        "content_type": "other:overlay",
                        "search.keyword": "",
                        "search.number_results": "",
                        "friendly_name": window.siteDefaults.name.toLowerCase() + " create profile",
                        "series_name": ""
                    }, false);
                    break;
                case "gigya-login-screen":
                    Tn.parseAnalytics({
                        "url_section": "/",
                        "section": "profile",
                        "subsection": "profile:" + window.siteDefaults.name.toLowerCase() + " login",
                        "template_type": "adbp:misc",
                        "content_type": "other:overlay",
                        "search.keyword": "",
                        "search.number_results": "",
                        "friendly_name": window.siteDefaults.name.toLowerCase() + " profile login",
                        "series_name": ""
                    }, false);
                    break;
                case "gigya-thank-you-screen":
                    console.log('This can be a place where we can set the browser info in gigya.  It is called before onAfterScreenLoad()... then gigya-log-in-dialog-loaded ... for social we could use accounts.socialLogin');
                    break;
            }
            //$('body').trigger('gigya-before-screen-load');
        },


        onGigyaLoginHelperCb: function(user, useThisCurrentVideo) {
            Tn.currentUser = user;
            $('body').addClass('profile-signed-in').removeClass('profile-signed-out');
            $('.logIn, .signUp, .visible-logged-out').addClass('tn-hidden');
            $('.logOut, .editProfile, .visible-logged-in').removeClass('tn-hidden');
            // updateProfileNames(user.profile.firstName, user.profile.lastName, user.profile.email);
            // $('#profile-dialog').attr('provider', user.provider).toggleClass('social', user.provider.length === 0 ? false : true);

            var savedUserPrefs = JSON.parse(user.data.prefs || "{}"),
                savedUserCurrentVideoInPrefs = savedUserPrefs.currentVideo,
                savedUserCurrentVideoNotInPrefs = user.data.myCurrentVideo,
                currentVideoBeforeLogin = Tn.Users.prefs.currentVideo,
                videoHistory = Tn.Users.mergeVideoHistoryPref(Tn.Users.prefs.videoHistory || {}, savedUserPrefs.videoHistory || {}),
                currentVideo = Tn.Users.getCurrentVideoHelper(currentVideoBeforeLogin, savedUserCurrentVideoNotInPrefs, savedUserCurrentVideoInPrefs, useThisCurrentVideo, videoHistory, user, Tn.Users.onGigyaLoginHelperCb);//(Tn.Users.prefs.currentVideo || savedUserPrefs.currentVideo || {}),
                liveHistory = Tn.Users.mergeLiveHistoryPref(Tn.Users.prefs.liveHistory || [], savedUserPrefs.liveHistory || []);

            //If we are waiting to get meta data via ajax because we only have the video id, we will skip this work and return when we do
            if($.isPlainObject(currentVideo) && typeof(currentVideo.isWaiting4MetaData) == 'undefined'){
                //See http://jordan.gigya-cs.com/turner/
                //Check if the Turner_Brand field is set to the correct value.  Initially set during registration but here during transition
                if (!user.data.hasOwnProperty('Turner_Brand') || 
                        (user.data.hasOwnProperty('Turner_Brand') && user.data.Turner_Brand != window.siteDefaults.gigyaBrand)) {
                    user.data.Turner_Brand = window.siteDefaults.gigyaBrand;

                    gigya.accounts.setAccountInfo({
                        data: {
                            Turner_Brand: window.siteDefaults.gigyaBrand
                        },
                        callback: function(o) {
                            if (o.errorCode != 0) { // Change from '!==' to '!=' per Gigya
                                console.error("Error setting Turner_Brand", o.errorDetails);
                                return;
                            } else {
                                console.log('set Turner_Brand to ' + window.siteDefaults.gigyaBrand);
                            }
                        }
                    });
                }

                if(!$.isArray(liveHistory)){
                    /* Patching problem where gigya has objects stored for liveHistroy */
                    liveHistory = [];
                }
                
                videoHistory = Tn.Users.patchVideoHistoryKeys(videoHistory);

                Tn.Users.prefs = savedUserPrefs;
                Tn.Users.setPref('videoHistory', videoHistory);
                Tn.Users.setPref('currentVideo', currentVideo);
                Tn.Users.setPref('liveHistory', liveHistory);

                if (Tn.Users.onStartupWatch) {
                    clearTimeout(Tn.Users.onStartupWatch);
                    Tn.Users.onStartupWatch = null;
                    Tn.Users.onStartup(Tn.currentUser.UID);
                }
                if (Tn.Users.onLoginCB) {
                    Tn.Users.onLoginCB(Tn.currentUser.UID);
                }
                $('body').trigger('gigya-log-in');

                if (Tn.lockUserProvider) {
                    delete Tn.lockUserProvider;
                } else {
                    Tn.Users.setPref("provider", user.provider);
                }
                if (!Tn.Users.getPref('lastLogin')) { // After submitted email form
                    // face book: gigya-link-account-screen when they found the email address already
                    Tn.Users.setBrowser(user.UID, user.UIDSignature, user.signatureTimestamp);
                    // New users would have seen terms so check it
                    Tn.Users.setTerms();
                }
                Tn.Users.setPref("lastLogin", new Date().getTime());

                updateProfileInfo();

                window.setTimeout(function(){
                    Tn.Users.preloadDataForUserVideoHistory();
                }, 2000); // Make sure the site is not busy before making it do more work.  Let garbage collection happen.


                // // Grab the user settings so that they are available as preferences before notifying of login
                // gigya.socialize.getUserSettings({
                //     group: 'preferences',
                //     callback: function(o) {
                //         if (o.errorCode !== 0) {
                //             console.error("Gigya::Error getting user settings", o);
                //         } else {
                //             Tn.Users.prefs = o.settings;
                //             if (!Tn.Users.getPref('lastLogin')) {
                //                 Tn.success("Welcome " + user.profile.firstName + ", your profile was sucecssfully created.");
                //                 Tn.Users.setPref("lastLogin", new Date().getTime());
                //             }
                //             console.error("Found prefs", o.settings);
                //         }
                //     }
                // });
            } else {
                console.log('isWaiting4MetaData to be filled in.  Making Ajax call');
            }
        },


        setErrorMessage: function(errorKey, errorMsg){
            if(gigya.i18n && gigya.i18n["gigya.services.accounts.plugins.screenSet.js"] && gigya.i18n["gigya.services.accounts.plugins.screenSet.js"].en){
                gigya.i18n["gigya.services.accounts.plugins.screenSet.js"].en[errorKey] = errorMsg;
            }
        },
        getErrorMessages: function(errorKey){
            var msg;
            if(gigya.i18n && gigya.i18n["gigya.services.accounts.plugins.screenSet.js"] && gigya.i18n["gigya.services.accounts.plugins.screenSet.js"].en){
                msg = gigya.i18n["gigya.services.accounts.plugins.screenSet.js"].en[errorKey];
            }
            return msg;
        },
        setInputTextPointerEvents: function(value) {
            $('#profile-dialog').find('input').css('pointer-events', value);
        },
        setupProfileDialog: function(){
            if(window.tnVars.isIOS()){
                //Taking care of the issue where scrolling over text boxes is not working.
                //Ref: https://code.google.com/p/iscroll-js/issues/detail?id=24
                //TENDP-11943
                $('#profile-dialog').on('touchstart.profileDialog', function() {
                    Tn.Users.setInputTextPointerEvents('auto');
                });

                $('#profile-dialog').on('touchmove.profileDialog', function() {
                    Tn.Users.setInputTextPointerEvents('none');
                });

                $('#profile-dialog').on('touchend.profileDialog', function() {
                    setTimeout(function() {
                        Tn.Users.setInputTextPointerEvents('none');
                    }, 0);
                });
                Tn.Users.setInputTextPointerEvents('none');
            }
        },
        cleanUpProfileDialog: function(){
            $('#profile-dialog').off('.profileDialog');
        },

        /**
         * Ensures that the screenset html is loaded before triggering the callback
         * @param  {Function} cb The method to be called once the screenset is loaded
         */
        ensureScreenSetLoaded: function(cb) {
            if ($('#profile-dialog').length > 0) {
                cb();
                Tn.Users.setupProfileDialog();
                return;
            }
            Tn.showPjaxSplash(true);
            $.ajax({
                url: "/includes/gigya.html",
                dataType: 'text'
            }).always(function() {
                Tn.showPjaxSplash(false);
            }).fail(function() {
                Tn.alert("Could not load login screenset");
            }).success(function(data) {
                data = data.replace(/SITE_ID/g, window.siteDefaults.name);
                $('body').append(data);

                // Buidl our recent history list every time we expand the frame
                $('#profile-contents-three').on('shown.bs.collapse', function() {
                    Tn.Users.showVideosViewed();
                });

                $('#profile-dialog').find(".mvpd-show-picker").on("click", function(event) {
                    event.preventDefault();
                    //closing profile dialog box on this click since it disables some functionality in auth box
                    $('#profile-dialog').modal('hide');
                    Tn.Auth.getAuthentication(window.currentPageUrl);
                });

                $('#profile-dialog').find(".mvpd-sign-out").on("click", function(event) {
                    event.preventDefault();
                    Tn.Auth.logout();
                });

                //.modal('hide')
                // this is a hack because the close button on Android is not showing
                // it does not seem to like z-index with 2 fixed position elements (modal and close button)
                if(window.tnVars.isAndroid && !window.tnVars.isAndroidChrome){
                     $('#gigya-user-profile-close').addClass('android-no-chrome');
                }
                $('#gigya-user-profile-close').on('click', function(event){
                    event.preventDefault();
                    $('#profile-dialog').modal('hide');
                    Tn.Users.cleanUpProfileDialog();
                });

                Tn.Users.setupProfileDialog();

                $('#profile-dialog').find('.profile-save-changes').click(function(event) {
                    event.preventDefault();
                    var oldPassword = $('.profile-oldpassword-value').val() || '',
                        newPassword = $('.profile-newpassword-value').val() || '',
                        confirmPassword = $('.profile-confirmpassword-value').val() || '',
                        data = {
                            profile: {
                                firstName: $('.profile-firstname-value').val(),
                                lastName: $('.profile-lastname-value').val(),
                                email: $('.profile-email-value').val()
                            },
                            callback: function(o) {
                                Tn.showPjaxSplash(false);
                                if (o.errorCode != 0) { // Change from '!==' to '!=' per Gigya
                                    if(o.errorCode == 403042){
                                        Tn.profileerror(Tn.Users.loginPasswordInvalidErrMsg);
                                    } else {
                                        Tn.profileerror("We experienced a problem with your profile. Please try again.<br>" + o.errorDetails);
                                    }
                                    console.error("Gigya::Error getting user settings", o);
                                } else {
                                    updateProfileNames($('.profile-firstname-value').val(), $('.profile-lastname-value').val(), $('.profile-email-value').val());
                                    Tn.success("Your " + window.siteDefaults.name + " Profile has been updated!");
                                }
                            }
                        };

                    if (oldPassword.length > 0 || newPassword.length > 0 || confirmPassword.length > 0) {
                        if (newPassword.length < 8){
                            Tn.profileerror("Your password must contain at least 8 characters.");
                            return;
                        } else if(newPassword !== confirmPassword) {
                            Tn.profileerror("Please enter two new passwords that match.");
                            return;
                        } else if(newPassword === oldPassword) {
                            Tn.profileerror("Old password cannot be the same as new password.");
                            return;
                        }
                        data.password = oldPassword;
                        data.newPassword = newPassword;
                    }

                    Tn.showPjaxSplash(true);
                    gigya.accounts.setAccountInfo(data);
                });

                Tn.Users.setupLogin($('#profile-dialog'));
                updateProfileInfo();

                Tn.updateBrandImage();
                // Call our callback method
                cb();
            });
        },
        
        showVideosViewed: function(){
            if (!Tn.movieData) {
                Tn.getMovieCarouselData(Tn.Users.showVideosViewed, false);
                return;
            } else if(!Tn.showData){
                Tn.getCarouselData(Tn.Users.showVideosViewed, false);
                return;
            }


            var shows = {},
                results = [],
                resultsEl = $('.profile-videos');

            resultsEl.empty();

            $.each(Tn.movieData.carousels, function(carouselIndex) {
                $.each(Tn.movieData.carousels[carouselIndex], function(moviePairIndex) {
                    $.each(Tn.movieData.carousels[carouselIndex][moviePairIndex], function(index, movieData) {
                        if (!movieData.playable) {
                            return;
                        }
                        var videoHistoryKey = ( movieData.videoId )?Tn.Users.vidHistoryPrefix + movieData.videoId:'noMvykey';
                        shows[videoHistoryKey] = movieData;
                    });
                });
            });

            $.each(Tn.showData.rowHdr, function(showIndex) {
                $.each(Tn.showData.carousels[showIndex], function(index, ep) {
                    if (!ep.playable) {
                        return;
                    }
                    var videoHistoryKey = ( ep.videoId )?Tn.Users.vidHistoryPrefix + ep.videoId:'noSKey';
                    //console.log(videoHistoryKey);
                    shows[videoHistoryKey] = ep;
                });
            });

            //TODO: Do the same thing for a movie hash/object.  Plus make sure you preload the data after login.

            var history = Tn.Users.getPref('videoHistory', {});
            $.each(history, function(videoHistoryKey, val) {
                if (shows[videoHistoryKey]) {
                    // Add our result and include the date so we know where to start off at
                    var num = typeof(val.dt) === 'string' ? parseInt(val.dt, 10) : val.dt;
                    results.push($.extend(shows[videoHistoryKey], {
                        dt: num
                    }));
                }
            });

            // Sort the results in date order
            results.sort(function(b, a) {
                if (a.dt > b.dt) {
                    return 1;
                }
                if (a.dt < b.dt) {
                    return -1;
                }
                return 0;
            });

            // Add our results to the profile video container
            if (results.length > 0) {
                var container = $('<div class="results row"></div>');
                container.appendTo(resultsEl);
                $.each(results, function(key, tileDataOriginal) {

                    // Only display the last 6 results
                    if (key >= 6) {
                        return false;
                    }
                    var tileData = jQuery.extend({}, tileDataOriginal),
                        item = $('<div class="search-item col-xs-12 col-sm-6 col-md-6 col-lg-6"></div>');

                    item.appendTo(container);
                    if(tileData.videoType !== 'movie'){
                        var epText = tileData.epinfo;
                        epText = epText.replace(/Season\s/gi, "S").replace(/Episode\s/gi, "E");
                        tileData.epinfo = epText;

                        Tn.initializeShowOverlay(item, tileData);
                    } else {
                        Tn.initializeMovieOverlay(item, tileData);
                    }

                    if ($('#profile.contents-three a[data-toggle="collapse"]:not(.collapsed)')) {
                        $('#profile-dialog .showTitle').show();
                    } else {
                        $('#profile-dialog .showTitle').hide();
                    }
                });
            } else {
                resultsEl.append('<div class="watchnow">No history available</div>');
            }

            updateProfileSize();

            //TODO: Clean up.  Reduce what we save in prefs in Gigya

        },

        /**
         * @private
         * Sets up callbacks on the default login methods
         */
        setupLogin: function(item) {
            item.find('.signUp').click(function(event) {
                event.preventDefault();
                Tn.Users.ensureScreenSetLoaded(function() {
                    gigya.accounts.showScreenSet({
                        screenSet: 'Mobile-login',
                        mobileScreenSet: 'Mobile-login',
                        onBeforeScreenLoad: Tn.Users.onBeforeScreenLoadCb
                    });
                });
            });
            item.find('.logIn').click(function(event) {
                event.preventDefault();
                $('body').trigger('gigya-log-in-clicked');
                var options = {};
                // email registration verifies a users account, so we want them to get the login screen first
                // instead of the registration screen
                if( $(this).attr('data-start-screen') ){
                    options.startScreen = $(this).attr('data-start-screen');
                }
                Tn.Users.logIn(options);
            });
            item.find('.editProfile').click(function(event) {
                event.preventDefault();
                $('body').trigger('gigya-edit-profile-clicked');
                Tn.Users.ensureScreenSetLoaded(function() {
                    $('#profile-dialog').modal('show');
                    Tn.parseAnalytics({
                        "url_section": "/",
                        "section": "profile",
                        "subsection": "profile:" + window.siteDefaults.name.toLowerCase() + " profile info",
                        "template_type": "adbp:misc",
                        "content_type": "other:overlay",
                        "search.keyword": "",
                        "search.number_results": "",
                        "friendly_name": window.siteDefaults.name.toLowerCase() + " profile info",
                        "series_name": ""
                    }, false);
                });
            });
            item.find('.logOut').click(function(event) {
                event.preventDefault();
                Tn.Users.logOut();
                $('#profile-dialog').modal('hide');
            });
        },

        /**
         * Logs the user into the system
         */
        logIn: function(options) {
            var screenSet = 'Login-web';
            var opts = options ? options : {};
            var startScreen = opts.startScreen ? opts.startScreen : 'gigya-register-screen';
            Tn.Users.ensureScreenSetLoaded(function() {
                Tn.screenSetShown = true;

                $('body').trigger('gigya-log-in-dialog');

                gigya.accounts.showScreenSet({
                    screenSet: screenSet,
                    startScreen: startScreen,
                    onLogin: function() {
                        console.log('################## onLogin');
                    },
                    onError: function(obj) {
                        var emailError = false,
                            emailErrorMsg = Tn.Users.getErrorMessages(Tn.Users.emailAlreadyExistsMsgKey),
                            defaultErrorMsg = Tn.Users.defaultLoginError;
                        if($.isArray(obj.response.validationErrors)){
                            for(var i=0;i < obj.response.validationErrors.length; i++){
                                var validationError = obj.response.validationErrors[i];
                                if(obj.errorCode == 400009 && validationError.errorCode == 400003){
                                    emailError = true;
                                }
                            }
                        }
                        if(emailError) { // Unique identifier exists
                            Tn.profileerror(emailErrorMsg);
                            $('#'+obj.form + ' .gigya-form-error-msg').hide(); // http://tickets.turner.com/browse/TENDP-11807 : they want to hide this message in special cases
                        } else if(obj.errorCode == 403042){
                            Tn.profileerror(Tn.Users.loginPasswordInvalidErrMsg);
                            $('#'+obj.form + ' .gigya-form-error-msg').hide();  
                        } else {
                            $('#'+obj.form + ' .gigya-form-error-msg').show(); // http://tickets.turner.com/browse/TENDP-11807 
                            Tn.profileerror(defaultErrorMsg);
                        }

                        console.error("Gigya::logIn", arguments);
                    },
                    onAfterScreenLoad: function(obj) {
                        $('body').trigger('gigya-log-in-dialog-loaded');
                        if (!Tn.Users.getPref('lastLogin') && obj.currentScreen == "gigya-thank-you-screen" && obj.response && obj.response.UID) { // After submitted email form
                            // face book uses gigya-link-account-screen when they found the email address already
                            //Call service where I can set the browser information. 
                            Tn.Users.setBrowser(obj.response.UID, obj.response.UIDSignature, obj.response.signatureTimestamp);
                            // New users would have seen terms so check it
                            Tn.Users.setTerms();
                        } else if(!Tn.Users.getPref('lastLogin') && obj.currentScreen == "gigya-complete-registiration-screen" 
                            && obj.response && obj.response.response && obj.response.response.UID 
                            && obj.response.response.UIDSignature && obj.response.response.signatureTimestamp ) { // After twitter or facebook ( email prohibitted ) click
                            //Call service where I can set the browser information.
                            Tn.Users.setBrowser(obj.response.response.UID, obj.response.response.UIDSignature, obj.response.response.signatureTimestamp);
                            // New users would have seen terms so check it
                            Tn.Users.setTerms();
                        }  
                        Tn.Users.setErrorMessage(Tn.Users.emailAlreadyExistsMsgKey, Tn.Users.emailAlreadyExistsMsg);
                    },
                    beforeRequest: function(){
                        console.log('################## beforeRequest');
                    },
                    onHide: function() {
                        Tn.screenSetShown = false;
                        $('body').trigger('gigya-screen-set-hidden');
                    },
                    onBeforeScreenLoad: Tn.Users.onBeforeScreenLoadCb
                });
            });
        },

        /**
         * Closes the login screenset if shown
         */
        cancelLogin: function() {
            if (!Tn.screenSetShown) {
                return;
            }
            Tn.screenSetShown = false;
            gigya.accounts.hideScreenSet({
                screenSet: 'Login-web'
            });
            $('body').trigger('gigya-cancel-log-out-dialog');
        },

        /**
         * Logs any logged in user out of the system
         */
        logOut: function() {
            console.error("Logging out of gigya");
            this.syncPrefsImmediately();
            //setTimeout to avoid race condition
            setTimeout( function(){
                gigya.accounts.logout({});}, 2000);
            $('body').trigger('gigya-log-out-dialog');
        },



        /**
         * Adds a comment UI at the id specified
         * @param  {String} id       The id of the dom element to place comments
         * @param  {String} category The server generated id for the comment
         */
        setupComments: function(id, category) {
            gigya.comments.showCommentsUI({
                categoryID: category,
                streamID: '',
                containerID: id,
                deviceType: 'mobile',
                cid: '',
                version: 2,
                useSiteLogin: true
                    //,enabledShareProviders: 'facebook,twitter,yahoo,linkedin'
            });
        },

        /**
         * Initializes the user management system
         * @param  {Object} config overrides to our default configuration values
         */
        initialize: function(config) {
            var me = this;
            jQuery.extend(Tn.Users, config || {});

            // Setup reactions if there is a container id specified
            if (me.reactionContainerId) {
                me.setupReactions(me.reactionContainerId, me.reactionLink, me.reactionTitle);
            }

            if (me.commentCategory && me.commentId) {
                me.setupComments(me.commentId, me.commentCategory);
            }

            // Add our callbacks for logging in/out
            me.setupLogin($('body'));

            // When dealing with RaaS, we have to notify social that we're logged in otherwise the plugins won't retain current user
            gigya.accounts.getAccountInfo({
                callback: function(user) {
                    if (user.errorCode == 0) { // Change from '===' to '==' per Gigya

                        // We won't get a provider here, so lock the last provider since that's who logged in
                        Tn.lockUserProvider = true;

                        gigya.socialize.notifyLogin({
                            siteUID: user.UID,
                            timestamp: user.signatureTimestamp,
                            UIDSig: user.UIDSignature
                        });

                        if (Tn.Users.onStartup) {
                            // Wait 30 seconds for preferences and such to be pulled down before calling the startup method
                            Tn.Users.onStartupWatch = setTimeout(function() {
                                delete Tn.Users.onStartupWatch;
                                console.error("Gigya: Error loading user preferences");
                                Tn.Users.onStartup(Tn.currentUser.UID);

                                if (Tn.Users.onLoginCB) {
                                    Tn.Users.onLoginCB(Tn.currentUser.UID);
                                }

                            }, 30000);
                        }
                    } else {
                        if (Tn.Users.onStartup) {
                            Tn.Users.onStartup(null);
                        }
                        return;
                    }
                }
            });
        }
    };

    // Run the following commands when the application first starts up
    Tn.onReady(function() {

        $('body').on('pageresize', updateProfileSize);

        // Hide the logout and edit profile UI's until we authenticate for the first time
        $('.logOut, .editProfile, .visible-logged-in').addClass('tn-hidden');

        // Add event handlers to look for then the user logs in/out of gigya
        gigya.accounts.addEventHandlers({
            onLogin: Tn.Users.onGigyaLoginHelperCb,
            onLogout: function() {
                var tempCurrentVideo = Tn.Users.prefs.currentVideo || {},
                    tempVideoHistory = Tn.Users.prefs.videoHistory || {},
                    tempLiveHistory = Tn.Users.prefs.liveHistory || [];
                delete Tn.currentUser;
                if(!$.isArray(tempLiveHistory)){
                    /* Patching problem where gigya has objects stored for liveHistroy */
                    tempLiveHistory = [];
                }
                $('body').addClass('profile-signed-out').removeClass('profile-signed-in');
                $('.logIn, .signUp, .visible-logged-out').removeClass('tn-hidden');
                $('.logOut, .editProfile, .visible-logged-in').addClass('tn-hidden');
                Tn.Users.prefs = {};
                Tn.Users.prefs.currentVideo = tempCurrentVideo;
                Tn.Users.prefs.videoHistory = tempVideoHistory;
                Tn.Users.prefs.liveHistory = tempLiveHistory;
                $('body').trigger('gigya-log-out');
                if (Tn.Users.onLogoutCB) {
                    Tn.Users.onLogoutCB();
                }
            }
        });
    });

})(Tn, jQuery, window.gigya, document, window);
