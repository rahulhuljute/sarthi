var UUID;
var gaWrapper = {};
var googleAnalyticsTrackingId = 'UA-3507894-33';
var isNativeApplication = (document.URL.indexOf('http://') === -1 && document.URL.indexOf('https://') === -1);

// loading mobile app files if application.type is mobile
//if (isNativeApplication) {
//
//    //if mobile device detected
//    //Load cordova.js dynamically
//    var cordovaScript = document.createElement('script');
//    cordovaScript.setAttribute('src', 'cordova.js');
//    document.head.appendChild(cordovaScript);
//
//    //Load mobile-app.js dynamically
//    var mobileScript = document.createElement('script');
//    mobileScript.setAttribute('src', 'Assets/js/mobile-app.js');
//    document.body.appendChild(mobileScript);
//} else {
 if (!isNativeApplication) {(function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments);
        };
        i[r].l = 1 * new Date();
        a = s.createElement(o);
        m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m);
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
    ga('create', googleAnalyticsTrackingId, 'auto');
    ga('send', 'pageview');
    gaWrapper = function (send, event, category, action, label) {
        ga(send, event, category, action, label);
    };
}
var setHeight = function (){
    var view = viewHeight();
    var mh;
    mh = (view - $('header').outerHeight() - $('footer').outerHeight());
    $(".fullscreen-spacer").css("min-height", mh);
};
$(function() {
  $( "#accordion" ).accordion();
  $( "#accordion2" ).accordion();
  $("#chosen").chosen({width: "100%"});
  $("#chosenSingle").chosen({width: "100%"});


// to render html in an auto complete you must extend it.
// https://api.jqueryui.com/autocomplete/#method-_renderItem

});
  $(function() {
    $( "#slider" ).slider({
      value:100,
      min: 0,
      max: 500,
      step: 50,
      slide: function( event, ui ) {
        $( "#amount" ).val( "$" + ui.value );
      }
    });
    $( "#amount" ).val( "$" + $( "#slider" ).slider( "value" ) );
  });
    $(function() {
    $( "#datepicker" ).datepicker();
  });
  $(function() {
   $( "#spinner" ).spinner();
 });
  $(document).ready(function() {
// input text focus moved after next/go/return key press End.
 // Code to transfer focus on keypad click event, should be done on document.ready() only.
      // Start
      (function ($) {
          $.fn.enterAsTab = function (options) {
              var settings = $.extend({
                               'allowSubmit': false
                               }, options);
              try {
                  $('input').keypress(function (event) {
                      if (settings.allowSubmit) {
                          var type = $(this).attr("type");
                          if (type == "submit") {
                              return true;
                          }
                      }
                      if (event.keyCode == 13) {
                          var inputs = $(this).parents("body").eq(0).find(":input,select,a,button");
                          var idx = inputs.index(this);
                          if (idx == inputs.length - 1) {
                              idx = -1;
                          }
                          else {
                              inputs[idx].blur();
                              inputs[idx + 1].focus(); // handles submit buttons
                          }
                          return true;
                      }
                });
                return this;
            }
            catch (error) {}
        };
    })(jQuery);
  
    $("#body").enterAsTab({
                        'allowSubmit': true
                        });
    // End
  
    // input text focus moved after next/go/return key press End.
  

    // http://anovi.github.io/selectonic/
    $("#ButtonGroup").selectonic(
      {
              multi:false,
      mouseMode: "standard",
        keyboard: false,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
      }
    );
    $("#Toggle").selectonic(
      {
              multi:false,
      mouseMode: "standard",
        keyboard: false,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
      }
    );
    var $holder = $("#PanelSelector"),panels = $holder.find('.panel-selector'), parent_panel = $holder.find('.parent ul'), child_panel = $holder.find('.child ul');
    parent_panel.selectonic({
      multi:false,
      mouseMode: "standard",
        keyboard: true,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
        create:function(){
           this.selectonic('disable')
        },
        unselect:function(event,ui){

        },
        select: function(event, ui) {

        },
    });
    parent_panel.mouseenter(function(){
        parent_panel.selectonic('enable');

    });
    parent_panel.mouseleave(function(){
        parent_panel.selectonic('disable');
    });
    child_panel.selectonic({
        multi:false,
        mouseMode: "standard",
        keyboard: true,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
        create:function(){
            this.selectonic('disable')
        },
        unselect:function(event,ui){

        },
        select: function(event, ui) {

        },
    });
    child_panel.mouseenter(function(){
        child_panel.selectonic('enable');

    });
    child_panel.mouseleave(function(){
        child_panel.selectonic('disable');
    });
    panels.mouseenter(function(){
        panels.removeClass('active-focus');
        $(this).addClass('active-focus');
    });

    panels.mouseleave(function(){
        panels.removeClass('active-focus');

    });


});


  ko.bindingHandlers.toggle = {
      'after': ['value', 'attr'],
      'init': function (element, valueAccessor, allBindings, viewModel, bindingContext) {
          // This updates the model selection array when the DOM element is clicked
          function updateModel() {

              //supporting both binding to boolean property and arrays
              if (isValueArray) {
                  var index = ko.utils.arrayIndexOf(underlyingValue, viewModel);
                  if(index > -1){
                      underlyingValue.splice(index, 1);
                  }else{
                      underlyingValue.push(viewModel);
                  }
                  if(isObservable){
                      modelProperty.valueHasMutated();
                  }
              } else {
                  if(isObservable && isWritable){
                      //flip the true/false value of an observable
                      modelProperty(!modelProperty());
                  }else{
                      //flip the true/false value of a property
                      viewModel[modelProperty] = !viewModel[modelProperty];
                  }
              }
          };

          var modelProperty = valueAccessor();
          var underlyingValue = ko.utils.unwrapObservable(modelProperty);
          var isValueArray = underlyingValue instanceof Array;
          var isObservable = ko.isObservable(modelProperty);
          var isWritable = ko.isWriteableObservable(modelProperty);

          // Set up a computed to update the binding:
          ko.utils.registerEventHandler(element, "click", updateModel);
      }
  };

 var panelScrollTop = function(data, event){
    var offset = $(event.currentTarget).parent().parent().offset().top -50;
    var winOffset = $(window).scrollTop();
    var newScroll = ( offset <= winOffset)? offset : 0;
    $(window).scrollTop(newScroll);
    };
  var pageScrollTop = function(data, event){
    $(window).scrollTop(0);
    }
  var panelVisibleToggle = function(data,event){
    var parentSection = $(data).parents('section.group-section').attr('id');
    if($('.accordion ' + data).hasClass('selected')){
        $('.accordion ' + data).removeClass('selected');
        $('.accordion ' + data + ' .collapsable-panel').removeClass('selected');
    }else{
        $('.accordion ' + data).addClass('selected');
        $('.accordion ' + data + ' .collapsable-panel').addClass('selected');
    }
    var target = '.accordion ' + data + ' .collapsable-panel';
    $(target).slideToggle();


    if($('#' + parentSection + ' .collapsable-panel.selected').length != 0){
           $('#'+parentSection+'_action').attr('data-action', 'collapse');
           $('#'+parentSection+'_action').html('');
           $('#'+parentSection+'_action').html('Collapse All');
    }else{
           $('#'+parentSection+'_action').attr('data-action', 'expand');
           $('#'+parentSection+'_action').html('');
           $('#'+parentSection+'_action').html('Expand All');
    }

    return true;
  };


  var OptimizeToggle = function(data, event){
       var action = $(data).attr('data-action');
       var accr = $(data).attr('data-accr');
       var id = $(data).attr('id');
       if(action == 'expand'){
           $('#'+id).attr('data-action', 'collapse');
           $('#'+id).html('');
           $('#'+id).html('Collapse All');
           $('#'+accr+' .accordion div').addClass('selected');
           $('#'+accr+' .accordion .collapsable-panel').slideDown();
       }else{
           $('#'+id).attr('data-action', 'expand');
           $('#'+id).html('');
           $('#'+id).html('Expand All');
           $('#'+accr+' .accordion div').removeClass('selected');
           $('#'+accr+' .accordion .collapsable-panel').slideUp();
       }
  };

  var panelHide = function(data, event){
    $(event.currentTarget).parents('.collapsable-panel').hide();
    $(event.currentTarget).parents('.selected').removeClass('selected');
  };
  var panelShow = function(data,event){
    var target = data + ' .collapsable-panel'
    $(target).show();
  };

  var listchange = function(data, event){
    var hash = location.hash;
    $('.split-sidebar .nav-list li').each(function(){
      var that = $(this);
      that[ $('a', this).attr( 'href' ) === hash ? 'addClass' : 'removeClass' ]( 'selected' );
      }
    );
  };


 var PanelSelectorKO = function(){
      var self = this;
      self.repeatedItems  = [
          {name:'Freckle', selected: ko.observable(false)},
          {name:'Beanstalk', selected: ko.observable(false)},
          {name:'DropBox', selected: ko.observable(false)},
          {name:'Postmark', selected: ko.observable(false)}
      ];
          self.repeatedItems2  = [
          {name:'IOS', selected: ko.observable(false)},
          {name:'Window Mobile', selected: ko.observable(false)},
          {name:'Andriod', selected: ko.observable(false)},
          {name:'RIM', selected: ko.observable(false)}
      ];
      self.hasAPI = ko.observableArray([]);
      self.hasFreePlan = ko.observableArray([]);
  };
  //var appmodel = new PanelSelectorKO();
 // ko.applyBindings(appmodel);

function viewHeight() {
    var viewportheight;

    // the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerWidth and window.innerHeight
    if (typeof window.innerWidth !== 'undefined') {
        viewportheight = window.innerHeight;
    }

        //	 IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
    else if (typeof document.documentElement !== 'undefined' && typeof document.documentElement.clientWidth !== 'undefined' && document.documentElement.clientWidth !== 0) {
        viewportheight = document.documentElement.clientHeight;
    }

        //	 older versions of IE
    else {
        viewportheight = document.getElementsByTagName('body')[0].clientHeight;
    }
    return viewportheight;
}


function HideAccordion(id) {
  $('#'+id).find('.accordion').find('div.collapsable-panel').hide();
  $('#'+id).find('.accordion').find('div').removeClass('selected');
}



var tabchange = function (data) {
    var hash = location.hash;
    $('.header .tabs li').removeClass('selected');
    $('.footer .tabs li').removeClass('selected');
    var string = '#' + data.page.currentId + '-Tab';
    $(string).addClass('selected active');

    if (hash.indexOf('advice') > -1 || hash.indexOf('statin') > -1 || hash.indexOf('clinician') > -1 || hash.indexOf('nonstatinagent') > -1) {
        $(document).foundation();
        var string = '#advice-Tab';
        $(string).addClass('selected active');
        $('.score-bar-holder').css('display', 'block');
    }else{
        $('.score-bar-holder').css('display', 'none');
    }

	if(hash.indexOf('advice') > -1 || hash.indexOf('calculator') > -1){
		notification.callWebApi('get',notification.criticalNotificationInputURL(),null, notification.notificationType.critical);
	}

    if(hash.indexOf('disclaimer') > -1)
        window.location.replace('../index.html#!/content/disclaimer/');
    else if(hash.indexOf('resources') > -1){
        window.location.replace('../index.html#!/content/resources/');
    }else if(hash.indexOf('about') > -1){
        window.location.replace('../index.html#!/content/about/');
    }

    setHeight();
    $('.tooltip').hide();
    $('#nonstatin .accordion div, #optimize .accordion div').removeClass('selected');
    $('#nonstatin .accordion .collapsable-panel, #optimize .accordion .collapsable-panel').slideUp();
    $('#optimize_action, #nonstatin_action').html('');
    $('#optimize_action, #nonstatin_action').html('Expand All');
    $('#optimize_action, #nonstatin_action').attr('data-action', 'expand');

};
window.onresize = function(event) {
    setHeight();
};
var pageScrollTop = function () {
    $(window).scrollTop(0);
};

var pageScrollTop = function () {
    $(window).scrollTop(0);
};

dateFormatter = function(i){
    if (i < 10) {
        i = '0' + i;
    }else{
        i = i;
    }
    return i;
};
