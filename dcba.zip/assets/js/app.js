var UUID;
var gaWrapper = {};
var googleAnalyticsTrackingId = 'UA-3507894-33';
var isNativeApplication = (document.URL.indexOf('http://') === -1 && document.URL.indexOf('https://') === -1);
// loading mobile app files if application.type is mobile
//if (isNativeApplication) {
//
//    //if mobile device detected
//    //Load cordova.js dynamically
//    var cordovaScript = document.createElement('script');
//    cordovaScript.setAttribute('src', 'cordova.js');
//    document.head.appendChild(cordovaScript);
//
//    //Load mobile-app.js dynamically
//    var mobileScript = document.createElement('script');
//    mobileScript.setAttribute('src', 'Assets/js/mobile-app.js');
//    document.body.appendChild(mobileScript);
//} else {
  if (!isNativeApplication) {  (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments);
        };
        i[r].l = 1 * new Date();
        a = s.createElement(o);
        m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m);
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
    ga('create', googleAnalyticsTrackingId, 'auto');
    ga('send', 'pageview');
    gaWrapper = function (send, event, category, action, label) {
        ga(send, event, category, action, label);
    };
}
var setHeight = function (){
    var view = viewHeight();
    var mh;
    mh = (view - ($('header').outerHeight() + $('footer').outerHeight()));
    $(".fullscreen-spacer").css("min-height", mh);
};
var footerChange = function () {
var hash = location.hash;
$('.footer li').removeClass('selected');
$('#footerLinks li').each(function () {
                    var that = $(this);
                    if($('a', this).attr('href') === hash){
                            that.addClass('selected');
                    }
                    else{
                            that.removeClass('selected');
                    }
            }
    );
    if (hash.indexOf('about') > -1 || hash.indexOf('notifications') > -1 || hash.indexOf('disclaimer') > -1 || hash.indexOf('resources') > -1) {
        $('header .tabs-primary').css('visibility', 'visible');
        $('header .tabs-primary').css('margin-left', '');
    }else{
        $('header .tabs-primary').css('visibility', 'hidden');
        $('header .tabs-primary').css('margin-left', '-61px');
        $('.off-canvas.position-left').removeClass('is-open').parent().removeClass('is-off-canvas-open is-open-left');

    }

	if(hash.indexOf('notifications') > -1){
		notification.callWebApi('get',notification.nonCriticalNotificationInputURL(),null, notification.notificationType.nonCritical);
	}
    setHeight();
};
var resizeTimer;
window.onresize = function(event) {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
        setHeight();
    }, 250);
};

var pageScrollTop = function () {
    $(window).scrollTop(0);
};
function viewHeight() {
    var viewportheight;

    // the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerWidth and window.innerHeight
    if (typeof window.innerWidth !== 'undefined') {
        viewportheight = window.innerHeight;
    }

        //	 IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
    else if (typeof document.documentElement !== 'undefined' && typeof document.documentElement.clientWidth !== 'undefined' && document.documentElement.clientWidth !== 0) {
        viewportheight = document.documentElement.clientHeight;
    }

        //	 older versions of IE
    else {
        viewportheight = document.getElementsByTagName('body')[0].clientHeight;
    }
    return viewportheight;
}
