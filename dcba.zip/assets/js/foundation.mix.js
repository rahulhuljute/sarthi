@import '../../bower_components/foundation/js/foundation/foundation.js';

/*
 * You should really comment out any of the following not being used
 * Mixture will then output a new combined and minified file
 */
@import '../../bower_components/foundation/js/foundation/foundation.alert.js';
@import '../../bower_components/foundation/js/foundation/foundation.accordion.js';
@import '../../bower_components/foundation/js/foundation/foundation.clearing.js';
@import '../../bower_components/foundation/js/foundation/foundation.abide.js';
@import '../../bower_components/foundation/js/foundation/foundation.dropdown.js';
@import '../../bower_components/foundation/js/foundation/foundation.equalizer.js';
@import '../../bower_components/foundation/js/foundation/foundation.interchange.js';
@import '../../bower_components/foundation/js/foundation/foundation.joyride.js';
@import '../../bower_components/foundation/js/foundation/foundation.magellan.js';
@import '../../bower_components/foundation/js/foundation/foundation.offcanvas.js';
@import '../../bower_components/foundation/js/foundation/foundation.orbit.js';
@import '../../bower_components/foundation/js/foundation/foundation.reveal.js';
@import '../../bower_components/foundation/js/foundation/foundation.tab.js';
@import '../../bower_components/foundation/js/foundation/foundation.tooltip.js';
@import '../../bower_components/foundation/js/foundation/foundation.topbar.js';
@import '../../bower_components/foundation/js/foundation/foundation.slider.js';