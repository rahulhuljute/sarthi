/*global debugLog , $, Connection, cordova*/

var mobileApp = {
    
    // App Constructor
initialize: function () {
    mobileApp.bindEvents();
},
    
    // bind events that are required on startup
bindEvents: function () {
    document.addEventListener('deviceready', mobileApp.onDeviceReady, false);
},
    
onDeviceReady: function () {
}
    
};
mobileApp.initialize();
