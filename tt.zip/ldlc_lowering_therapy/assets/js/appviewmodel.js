isNativeApplication = false;
ko.extenders.required = function(target, overrideMessage) {
    var newValue;
    //add some sub-observables to our observable
    target.warningClass = ko.observable();
    target.validationMessage = ko.observable();
    //define a function to do validation
    function validate(newValue) {
        if(newValue === undefined || appmodel === undefined)
            return false;
        
        if(newValue !== '')
            newValue = newValue.replace(/\,/g, '.');
        
        var pattrn;
        if(!appmodel.Form().UnitOfMeasure()){
            pattrn = /^\d+(\.\d{1,3})?$/;
            if (newValue === '' || newValue === 'undefined') {
                target.warningClass(' warning');
            }else if(newValue < 40 || newValue > 999){
                target('');
                target.warningClass(' warning');
                return false;
            }else if (!(pattrn.test(newValue))) {
                target('');
                target.warningClass(' error');
                return false;
            }else{
                target(newValue);
                target.warningClass('');
            }
        }else{
            pattrn = /^\d+(\.\d{1,3})?$/;
            if (newValue === '' || newValue === 'undefined') {
                target.warningClass(' warning');
            }else if(newValue < 1.036 || newValue > 25.874){
                target('');
                target.warningClass(' warning');
                return false;
            }else if (!(pattrn.test(newValue))) {
                target('');
                target.warningClass(' error');
                return false;
            }else{
                target(newValue);
                target.warningClass('');
            }            
        }    
    }
 
    //initial validation
    validate(target());
 
    //validate whenever the value changes
    target.subscribe(validate);
 
    //return the original observable
    return target;
};
function viewModel(){
	var self = this;	
	self.Form = ko.observable(new formObject());
/* doNavigation() function is for toggling selected active css class on header and footer tab navigation.
* @param data: contains the current element selector value.
*/ 
    self.tabNavigation = function(data) {
		$(window).scrollTop($('body').offset().top);
        if(data === 'advice'){  
            if(appmodel.Form().showAdviceBtn()){
                window.location.href = '#!/content/advice/';
                $('#calculator-Tab, #disclaimer-Tab, #about-Tab, #resources-Tab').removeClass('selected');
                $('#recommendation-Tab').addClass('selected');
            }else{
                window.location.href = '#!/content/calculator/';
                $('#recommendation-Tab, #disclaimer-Tab, #about-Tab, #resources-Tab').removeClass('selected');
                $('#calculator-Tab').addClass('selected');                 
            }
		}else{
            window.location.href = '#!/content/calculator/';
            $('#recommendation-Tab, #disclaimer-Tab, #about-Tab, #resources-Tab').removeClass('selected');
            $('#calculator-Tab').addClass('selected');            
        }
    };
/**
 * this function is used to draft email
 */     
    self.sendEmail = function() {
    //gaWrapper("send", "event", "Mailto", "Clicked", "Email");
    var breakline = '%0D%0A';     
    var linebreak = "%0D%0A";
    var doublelinebreak = linebreak + linebreak;        
    var emailText, subject, message, group_type, group_options, statin, dose, intensity;
    var datetime = new Date();
    var timestamp = (datetime.getMonth()+1) + '/' + datetime.getDate() + '/' + datetime.getFullYear() + ' ' + dateFormatter(datetime.getHours()) + ':' + dateFormatter(datetime.getMinutes());
    emailText = self.Form().FormData().emailTemplate;
    
    if(self.Form().patientGroupType() == 'primary'){
        group_type = 'Primary Prevention';
    }else{
        group_type = 'Secondary Prevention'; 
    }
    var patientGroupID = self.Form().patientBenefitGroup();
    if(patientGroupID === 'group2c' || patientGroupID === 'group3'){
        if(self.Form().UnitOfMeasure()){
            self.Form().groupBaselineLDLC(' ≥ 4.921 µmol/L');
        }else{
            self.Form().groupBaselineLDLC(' ≥ 190 mg/dL');
        }
        if(self.Form().additionalReduction() > 20){
            if(patientGroupID === 'group2c'){
                patientGroupID = 'group2c_pcsk9';
            }else{
                patientGroupID = 'group3_pcsk9';
            }
        }else{
            if(patientGroupID === 'group2c'){
                patientGroupID = 'group2c_ezetimibe';
            }else{
                patientGroupID = 'group3_ezetimibe';
            }            
        }
    }else{
        if(self.Form().UnitOfMeasure()){
            self.Form().groupBaselineLDLC(' 1.813-4.895 µmol/L');
        }else{
            self.Form().groupBaselineLDLC(' 70-189 mg/dL');
        }
    }
    var LDLReduction = encodeURIComponent(self.Form().LDLReduction()?self.Form().LDLReduction():'Not Calculated'); 
    var currentLDLC = self.Form().currentLDLC() + ' ' + self.Form().UnitOfMeasureType(); 
    var baselineLDLC = self.Form().baselineLDLC()?self.Form().baselineLDLC() + ' ' + self.Form().UnitOfMeasureType():'None Entered'; 
   
    var AccSuggestedLDLReduction = encodeURIComponent(self.Form().LDLTherapyTable().recommended_reduction);
    var AccSuggestedLDLC;
    var AccSuggestedHDLC;       
    if(self.Form().UnitOfMeasure()){
        AccSuggestedLDLC = self.Form().LDLTherapyTable().recommended_LDL_C_mmol;
        AccSuggestedHDLC = self.Form().LDLTherapyTable().recommended_non_HDL_C_mmol;       
    }else{
        AccSuggestedLDLC = self.Form().LDLTherapyTable().recommended_LDL_C_mg;  
        AccSuggestedHDLC = self.Form().LDLTherapyTable().recommended_non_HDL_C_mg;        
    }   
   
    subject = emailText.subjectLine;
    subject = subject.replace('#groupType#', group_type);
    subject = subject.replace('#timestamp#', timestamp);
    //message = subject;
    message = emailText.headLine.replace('#timestamp#', timestamp);
    
    if(patientGroupID != 'group4_1'){
        currentStatin   = emailText.currentStatin.replace('#statin#', self.Form().currentStatin());
        currentStatin   = currentStatin.replace('#dose#', self.Form().currentStatinDose());
        currentStatin   = currentStatin.replace('#intensity#', self.Form().doseValueChange());
        message += currentStatin;
    }
    patientGroup = emailText.patientGroup.replace('#groupType#', group_type);
    message += patientGroup;
    groupAdvice = self.Form().FormData().emailGroupAdvice[patientGroupID];
    groupAdvice = groupAdvice.replace('#groupBaselineLDLC#', self.Form().groupBaselineLDLC());
    patientNumbers = emailText.patientNumbers.replace('#LDLCReduction#', LDLReduction);
    patientNumbers = patientNumbers.replace('#CurrentLDLC#', currentLDLC);
    patientNumbers = patientNumbers.replace('#BaselineLDLC#', baselineLDLC);
    groupAdvice = groupAdvice.replace('#patientNumbers#', patientNumbers);
    accSuggestedNumbers = emailText.accSuggestedNumbers.replace('#AccSuggestedLDLReduction#', AccSuggestedLDLReduction);
    accSuggestedNumbers = accSuggestedNumbers.replace('#AccSuggestedLDLC#', AccSuggestedLDLC);
    accSuggestedNumbers = accSuggestedNumbers.replace('#AccSuggestedHDLC#', AccSuggestedHDLC);
    groupAdvice = groupAdvice.replace('#accSuggestedNumbers#', accSuggestedNumbers);
    message += groupAdvice;
    message += doublelinebreak;
    message += doublelinebreak;
    message += emailText.disclaimer;
      if(isNativeApplication) {
       cordova.plugins.email.open({
        to:'',
        cc:'',
        bcc:'',
        subject:subject,
        body:decodeURI(message.replace(new RegExp('%0D%0A', 'g'), '<br>')),
        isHtml:  true
       });
      } else {
       mymail = 'mailto:?subject=' + subject +'&body=' + message +'';
       window.location.href = mymail;
      }
    }; 
}
var appmodel = new viewModel();
pager.Href.hash = '#!/';
pager.extendWithPage(appmodel);

// apply your bindings
ko.applyBindings(appmodel);
// run this method - listening to hashchange
pager.start();
var path = '#!/content/calculator/';
pager.navigate(path);
$('#calculator-Tab').addClass('selected active');

function formObject(data) {
    var self = this, yes = true, no = false, isSession = true;
    var unit = 0.0259;    
    self.FormData = ko.observable(formdata);
    self.UnitOfMeasure = ko.observable(false);
    self.UnitOfMeasureType = ko.observable('mg/dL');    
    self.calculatedBenefitGroup = ko.observable('');
    self.patientGroupType = ko.observable('');
    self.patientBenefitGroup = ko.observable(''); 
    self.groupBaselineLDLC = ko.observable(''); 
    self.takeAstatin = ko.observable('');
    self.baselineLDLC_range = ko.observable('');
    self.ascvd = ko.observable('');
    self.ageRange = ko.observable('');
    self.comorbidities = ko.observable('');
    self.diabetes = ko.observable('');
    self.ascvd10yr = ko.observable('');
    self.showAgeRange = ko.observable(false);
    self.showComorbidities = ko.observable(false);
    self.showDiabetes = ko.observable(false);
    self.showAscvd10yr = ko.observable(false);
    self.helpMeChooseWarningMsg = ko.observable(false);
    self.showHelpmeChooseAction = ko.observable(false);
    self.showPatientDetails = ko.observable(false);
    self.showNonHDLC = ko.observable(false);
    self.ldlArray = ko.observableArray([]);
    self.currentLDLC = ko.observable().extend({ required: "" });
    self.currentLDLCValue = ko.observable();    
    self.nonHDLC = ko.observable().extend({ required: "" });
    self.nonHDLCLock = ko.observable(false);
    self.totalCholesterol = ko.observable().extend({ required: "" });
    self.hdlCholesterol = ko.observable().extend({ required: "" });
    self.triglycerides = ko.observable().extend({ required: "" });
    self.currentStatin = ko.observable('');
    self.statinValues = ko.observable(self.FormData().statins);
    self.statinSelectedValue = ko.observable();
    self.currentStatinDose = ko.observable('');
    self.doseValues = ko.observable([{'title': '', 'intensity': ''}]);
    self.doseValueChange = ko.observable();
    self.baselineLDLC = ko.observable().extend({ required: "" }); 
    self.baselineValueMgDL = ko.observable();
    self.LDLTherapyTable = ko.observable([]);
    self.LDLReduction = ko.observable();
    self.isAcceptedTreatment = ko.observable('');
    self.showIsAcceptedTreatment = ko.observable(false); 
    self.highRiskMarkers = ko.observable('');
    self.showHighRiskMarker = ko.observable(false);
    self.reductionWarningClass = ko.observable('');
    self.showAdditionalReduction = ko.observable(false);
    self.additionalReduction = ko.observable('');
    self.reductionPercent = ko.observable('');
    self.showAdviceBtn = ko.observable(false);
    self.showWarningMsg = ko.observable(false);
    self.showLDLTherapyTable = ko.observable(false);
    self.showLDLTherapyBtn = ko.observable(false);
    self.showNoAdvice = ko.observable(false);
    
    self.calculatedBenefitGroup.subscribe(function(data){
        if(data !== ''){
            self.showHelpmeChooseAction(true);
            self.showNoAdvice(false);
        }else{
            self.showHelpmeChooseAction(false);
        }
    });
    self.patientGroupType.subscribe(function(data){
        sessionStorage.setItem('patientGroupType', data);
        self.patientBenefitGroup('');
    });    
    self.patientBenefitGroup.subscribe(function(data){
        if(data !== '' || data !== undefined){
            self.showPatientDetails(true);
        }else{
            self.showPatientDetails(false);
        } 
        if(data === 'group2b' || data === 'group4_1' || data === 'group4_2'){
            self.showNonHDLC(true);
        }else{
            self.showNonHDLC(false);
        }        
        self.setGroup(data);
        //self.resetPatientDetails();
        sessionStorage.setItem('patientBenefitGroup', data);
    });
    self.showPanel = function(ageRange, comorbidities, diabetes, ascvd10yr){
        self.showAgeRange(ageRange);
        self.showComorbidities(comorbidities);
        self.showDiabetes(diabetes);
        self.showAscvd10yr(ascvd10yr);    
    };    
    self.setHelpMeChooseOptions = function(takeAstatin, baselineLDLC_range, ascvd, age, comorbidities, diabetes, ascvd10yr){
        self.showPanel(age?true:false, comorbidities?true:false, diabetes?true:false, ascvd10yr?true:false);        
        self.setTakeAstatin(takeAstatin?takeAstatin:'');
        self.setASCVD(ascvd?ascvd:'');
        self.setBaselineLDLC_range(baselineLDLC_range?baselineLDLC_range:'');        
        self.setAge(age?age:'');
        self.setDiabetes(diabetes?diabetes:'');
        self.setComorbidities(comorbidities?comorbidities:'');
        self.setAscvd10yr(ascvd10yr?ascvd10yr:'');    
    };
    self.helpmeChooseAction = function(data){
        if(self.calculatedBenefitGroup()!==''){
             if(self.calculatedBenefitGroup() === 'group2a' || self.calculatedBenefitGroup() === 'group2b' || self.calculatedBenefitGroup() === 'group2c'){
                    self.patientGroupType('secondary');
            }else{
                    self.patientGroupType('primary');               
            }
            self.patientBenefitGroup(self.calculatedBenefitGroup());
        }
    };    
    self.setGroup = function(data){
        if(data == 'group5'){
            self.setHelpMeChooseOptions('yes', '70to189', 'no', '40to75', '', 'no', 'yes');
            self.showHelpmeChooseAction(true);
        }else if(data == 'group2a'){
            self.setHelpMeChooseOptions('yes', '40to189', 'yes', '', 'no', '', '');
            self.showHelpmeChooseAction(true);
        }else if(data == 'group2b'){
            self.setHelpMeChooseOptions('yes', '40to189', 'yes', '', 'yes', '', '');
            self.showHelpmeChooseAction(true);
        }else if(data == 'group2c'){
            self.setHelpMeChooseOptions('yes', 'gte190', 'yes', '', '', '', '');
            self.showHelpmeChooseAction(true);
        }else if(data == 'group3'){
            self.setHelpMeChooseOptions('yes', 'gte190', 'no', '', '', '', '');
            self.showHelpmeChooseAction(true);
        }else if(data == 'group4_1'){
            self.setHelpMeChooseOptions('yes', '70to189', 'no', '40to75', '', 'yes', 'yes');
            self.showHelpmeChooseAction(true);
        }else if(data == 'group4_2'){
            self.setHelpMeChooseOptions('yes', '70to189', 'no', '40to75', '', 'yes', 'no');
            self.showHelpmeChooseAction(true);
        }else{
            self.setHelpMeChooseOptions();
            self.showHelpmeChooseAction(false);
        }        
    };    
    self.UnitOfMeasure.subscribe(function(data){
        var baselineLDLC = self.baselineLDLC()
        var currentLDLC = self.currentLDLC();
        var nonHDLC = self.nonHDLC();
        var totalCholesterol = self.totalCholesterol();
        var hdlCholesterol = self.hdlCholesterol();
        var triglycerides = self.triglycerides();
        if(data){
            self.UnitOfMeasureType('µmol/L');
            sessionStorage.setItem('UnitOfMeasureType', 'µmol/L');
            if(baselineLDLC != '' && baselineLDLC != undefined)
                self.baselineLDLC( (baselineLDLC * unit).toFixed(3));
            if(currentLDLC != '' && currentLDLC != undefined)
                self.currentLDLC( (currentLDLC * unit).toFixed(3));
            if(nonHDLC != '' && nonHDLC != undefined)
                self.nonHDLC( (nonHDLC * unit).toFixed(3));            
            if(totalCholesterol != '' && totalCholesterol != undefined)
                self.totalCholesterol( (totalCholesterol * unit).toFixed(3));
            if(hdlCholesterol != '' && hdlCholesterol != undefined)
                self.hdlCholesterol( (hdlCholesterol * unit).toFixed(3));
            if(triglycerides != '' && triglycerides != undefined)
                self.triglycerides( (triglycerides * unit).toFixed(3));            
        }else{
            sessionStorage.setItem('UnitOfMeasureType', 'mg/dL');
            self.UnitOfMeasureType('mg/dL');            
            if(baselineLDLC != '' && baselineLDLC != undefined)
                self.baselineLDLC( (baselineLDLC / unit).toFixed(2) );
            if(currentLDLC != '' && currentLDLC != undefined)
                self.currentLDLC( (currentLDLC / unit).toFixed(2) );
            if(nonHDLC != '' && nonHDLC != undefined)
                self.nonHDLC( (nonHDLC / unit).toFixed(2));            
            if(totalCholesterol != '' && totalCholesterol != undefined)
                self.totalCholesterol( (totalCholesterol / unit).toFixed(2));
            if(hdlCholesterol != '' && hdlCholesterol != undefined)
                self.hdlCholesterol( (hdlCholesterol / unit).toFixed(2));
            if(triglycerides != '' && triglycerides != undefined)
                self.triglycerides( (triglycerides / unit).toFixed(2));             
        }
    });
    self.setTakeAstatin = function(data){
        self.setASCVD('');        
        if(data !== ''){
            self.takeAstatin(data);
            self.evaluateBenefitGroup('takeAstatin', data);
        }    
        else{
            self.removeClassWarning('takeAstatin');
            self.removeClassActive('takeAstatin');
            self.takeAstatin('');
        }
    };
    self.baselineLDLC.subscribe(function(data){
        if(self.UnitOfMeasure()){
            self.baselineValueMgDL(self.baselineLDLC()/unit);
        }else{
            self.baselineValueMgDL(self.baselineLDLC());
        }
        if(data!='' && self.baselineLDLC.warningClass()!=' error')
        {
            if(self.baselineLDLC_range() == '40to189'){
                if(self.baselineValueMgDL() > 40 && self.baselineValueMgDL() < 189.999){
                    self.baselineLDLC('');
                    self.baselineLDLC.warningClass(' warning');                
                }else{
                    self.baselineLDLC.warningClass(' ');
                }                
            }else if(self.baselineLDLC_range() == '40to69'){
                if(self.baselineValueMgDL() > 40 && self.baselineValueMgDL() < 70){
                    self.baselineLDLC('');
                    self.baselineLDLC.warningClass(' warning');                
                }else{
                    self.baselineLDLC.warningClass(' ');
                }                
            }else if(self.baselineLDLC_range() == '70to189'){
                if(self.baselineValueMgDL() >= 70 && self.baselineValueMgDL() <= 189){
                    self.baselineLDLC.warningClass(' ');                
                }else{
                    self.baselineLDLC('');
                    self.baselineLDLC.warningClass(' warning');                
                }            
            }else if(self.baselineLDLC_range() == 'gte190'){
                if(self.baselineValueMgDL() < 190){
                    self.baselineLDLC('');
                    self.baselineLDLC.warningClass(' warning');                
                }else{
                    self.baselineLDLC.warningClass(' ');
                }            
            }else{
                self.setBaselineLDLC_range('');
            }
        }else if(data=='' && self.baselineLDLC.warningClass()!=' error'){
            self.baselineLDLC.warningClass(''); 
        }    
        self.getLDLTherapyData();
        sessionStorage.setItem('baselineLDLC', data);
    });
    self.setBaselineLDLC_range = function(data){
        self.setAge('');
        self.setComorbidities('');      
        if(data!=''){
            self.baselineLDLC_range(data);
            self.evaluateBenefitGroup('baselineLDLC_range', data);
        }else{
            self.removeClassWarning('baselineLDLC_range');
            self.removeClassActive('baselineLDLC_range');
            self.baselineLDLC_range('');
        }
    };    
    self.setASCVD = function(data){
        self.setBaselineLDLC_range('');
        if(data!=''){
            self.ascvd(data);
            self.evaluateBenefitGroup('ascvd', data);
        }else{
            self.removeClassWarning('ascvd');
            self.removeClassActive('ascvd');
            self.ascvd('');
        }
    };
    self.setAge = function(data){
        if(self.showAgeRange()){
            self.setComorbidities('');
            self.setDiabetes('');
        }
        if(data!=''){
            self.ageRange(data);
            self.evaluateBenefitGroup('ageRange', data);
        }else{
            self.removeClassWarning('ageRange');
            self.removeClassActive('ageRange');
            self.ageRange('');
        }
    };
    self.setComorbidities = function(data){
        if(self.showComorbidities()){
            self.setDiabetes('');
        }
        
        if(data!=''){
            self.comorbidities(data);
            self.evaluateBenefitGroup('comorbidities', data);
        }else{
            self.removeClassWarning('comorbidities');
            self.removeClassActive('comorbidities');
            self.comorbidities('');
        }
    };
    self.setDiabetes = function(data){
        if(self.showDiabetes()){
            self.setAscvd10yr('');
        }
        if(data!=''){
            self.diabetes(data);
            self.evaluateBenefitGroup('diabetes', data);
        }else{
            self.removeClassWarning('diabetes');
            self.removeClassActive('diabetes');
            self.diabetes('');
        }
    };
    self.setAscvd10yr = function(data){
        if(data!=''){
            self.ascvd10yr(data);
            self.evaluateBenefitGroup('ascvd10yr', data);
        }else{
             self.removeClassWarning('ascvd10yr');
             self.removeClassActive('ascvd10yr');
             self.ascvd10yr('');
        }
    };
    self.currentLDLC.subscribe(function(data){
        if(data == ''){
            self.nonHDLC('');
        }
        self.getReductionTableValues();  
        self.getLDLTherapyData();
        sessionStorage.setItem('currentLDLC', data);
    });
     self.nonHDLC.subscribe(function(data){
        self.evaluateBenefitGroup();
        sessionStorage.setItem('nonHDLC', data);
    });    
    self.statinSelectedValue.subscribe(function(data){
        self.currentStatin('');
        if(isSession){
            self.doseValueChange('');
        }
        var statin = $.grep(self.FormData().statins, function (item, index) {
            item.index = index;
            return item.id === data;
        });
        if(statin.length !== 0){
            var doseValues = self.FormData().statins[statin[0].index].dose;
            self.currentStatin(statin[0].title);
            self.doseValues(doseValues);
        }else{
            self.doseValues([            
                {'title': '', 'intensity': ''}                
            ]);
        }
        sessionStorage.setItem('statinSelectedValue', data);
    });
    self.doseValueChange.subscribe(function(data){
        var dose = $.grep(self.doseValues(), function (item, index) {
            item.index = index;
            return item.intensity === data;
        }); 
        if(dose.length !== 0){
            self.currentStatinDose(dose[0].dose);
        }else{
            self.currentStatinDose('');
        }        
        self.getLDLTherapyData();
        sessionStorage.setItem('doseValueChange', data);
    });
    /*self.questions = ko.observableArray();
    self.questions(questions);
    */
    self.setIsAcceptedTreatment = function(data){
        if(self.showLDLTherapyTable()){
            self.highRiskMarkers('');
            self.additionalReduction('');
            self.reductionPercent('');
        }
        if(data!=''){
            self.isAcceptedTreatment(data);
            self.evaluateBenefitGroup('isAcceptedTreatment', data);
        }else{
            self.isAcceptedTreatment('');
        }        
    };
    self.setHighRiskMarkers = function(data){
        if(self.showHighRiskMarker()){
                /*TODO add dependent field*/      
        }
        if(data!=''){
            self.highRiskMarkers(data);
            self.evaluateBenefitGroup('highRiskMarkers', data);
        }else{
            self.highRiskMarkers('');
        }
    };
    self.additionalReduction.subscribe(function(data, options){
        var newValue = data;
        pattrn = /^\d+(\.\d{1,3})?$/;
        if (newValue === '' || newValue === 'undefined') {
            self.reductionWarningClass(' warning');
        }else if(newValue < 1 || newValue > 100){
            self.additionalReduction('');
            self.reductionWarningClass(' warning');
        }else if (!(pattrn.test(newValue))) {
            self.additionalReduction('');
            self.reductionWarningClass(' error');
        }else{
            self.reductionWarningClass('');
        }
        //self.getReductionTableValues(data);
        self.evaluateBenefitGroup('additionalReduction', data);
    });
    self.reductionPercent.subscribe(function(data){
        self.additionalReduction(data);
    });    
    self.getReductionTableValues = function(data){
        var Rvalue = parseInt(self.currentLDLC());
        self.ldlArray([]);
        var cnt = 10;
        var isDataPush = true;
        var percent = 0.1;
        var ldlc = 40;
        if(self.UnitOfMeasure()){
            ldlc = 1.036;
        }
        while (Rvalue >= ldlc) {
            Rvalue = self.currentLDLC() - (self.currentLDLC() * percent);
            if(data && isDataPush){
                
                if(cnt>data && cnt != data){
                    var newPercent = data;
                    var newValue =  self.currentLDLC() - (self.currentLDLC() * (newPercent/100))
                    self.ldlArray.push({'checked':ko.observable('true'), 'perecent':ko.observable(newPercent.toFixed(3)),'value':ko.observable(newValue)});
                    isDataPush = false;
                }else if(cnt<data){
                    
                }
                
            }
            if (Rvalue >= ldlc) {
                self.ldlArray.push({'checked':ko.observable('true'), 'perecent':ko.observable(cnt),'value':ko.observable(Rvalue.toFixed(3))});
                percent = percent + 0.1;
                cnt +=10;
            }else if(Rvalue <= ldlc){
                percent = ((self.currentLDLC() - ldlc)/self.currentLDLC())*100;
                self.ldlArray.push({'checked':ko.observable('true'), 'perecent':ko.observable(percent.toFixed(3)),'value':ko.observable(ldlc)});
            }
            else{
                break;
            }
        }         
    };
    self.lipidPanelAction = function(data){
        if(data === 'save'){
            var totalCholesterol = self.totalCholesterol();
            var hdlCholesterol = self.hdlCholesterol();
            if(hdlCholesterol != '' && 
               hdlCholesterol != undefined && 
               totalCholesterol != '' && 
               totalCholesterol != undefined){
                self.nonHDLC((totalCholesterol - hdlCholesterol).toString());
                self.nonHDLCLock(true);
            }
        }else{
            self.nonHDLCLock(false);
            self.nonHDLC('');
            self.totalCholesterol('');
            self.hdlCholesterol('');
            self.nonHDLC.warningClass('');
            self.totalCholesterol.warningClass('');
            self.hdlCholesterol.warningClass('');
        }            
    };
    self.getLDLTherapyData = function(){
        self.showLDLTherapyTable(false);
        self.setIsAcceptedTreatment('');
        self.showHighRiskMarker(false);
        self.showAdviceBtn(false);
        self.setHighRiskMarkers('');
        var currentLDLC = self.currentLDLC();
        if((currentLDLC !== 0 && currentLDLC !== undefined && currentLDLC !== "") && ((self.doseValueChange() !== 0 && self.doseValueChange() !== undefined) || self.patientBenefitGroup() == 'group4_1')){
            var benefitGroup = self.patientBenefitGroup();
            var intensity = self.doseValueChange();
            var data = $.grep(self.FormData().LDLTherapyData, function (item, index) {
                item.index = index;
                return item.benefitGroup === benefitGroup;
            });
            if(data.length !== 0){
                if(benefitGroup == 'group5' && intensity != ''){
                    self.LDLTherapyTable(data[0]['intensity'][intensity]);
                }else{
                    self.LDLTherapyTable(data[0]);
                }
                self.showLDLTherapyBtn(true);
                //self.showLDLTherapyTable(true);
            }else{
                self.LDLTherapyTable([]);
            }
            
            if(self.baselineLDLC() != '' && self.baselineLDLC() !== undefined){
                var  LDLReductionValue = ((self.baselineLDLC() - currentLDLC)/self.baselineLDLC())*100
                self.LDLReduction((parseFloat(LDLReductionValue.toFixed(1)) + '%'));
            }else{
                self.LDLReduction('[Enter Baseline LDL-C to calculate]');
            }
            
        }else{
            //self.showLDLTherapyTable(false);
            self.showLDLTherapyBtn(false);
        }
        self.evaluateBenefitGroup();
    };
    self.LDLTherapyBtnAction = function(){
        self.showLDLTherapyTable(true);
    };
    self.resetPatientDetails = function(){
        self.currentLDLC('');
        self.currentLDLC.warningClass('');
        self.nonHDLC('');
        self.nonHDLC.warningClass('');  
        self.totalCholesterol('');
        self.totalCholesterol.warningClass('');
        self.hdlCholesterol('');
        self.hdlCholesterol.warningClass('');
        self.triglycerides('');     
        self.triglycerides.warningClass('');
        self.statinSelectedValue('');
        self.baselineLDLC('');
        self.baselineLDLC.warningClass('');
    };
    self.resetAll = function(data){
        self.patientGroupType('');
        self.patientBenefitGroup('');
        self.setGroup('');
        self.nonHDLCLock(false);
        self.showPatientDetails(false);
        self.showWarningMsg(false);
        self.showAdviceBtn(false);
        self.resetPatientDetails();
        self.showNoAdvice(false);
    };
    self.helpMeChooseResetAll = function(data){
        self.setHelpMeChooseOptions();
        self.showNoAdvice(false);
        self.removeClassWarning();
        self.resetAll();
    };
    self.addClassWarning = function(){
        $('.question.active').addClass('warning');
    };
    self.removeClassWarning = function(id){
        if(id !== undefined){
            $('#' + id).parents('.question.active').removeClass('warning');
        }else{
            $('.question.active').removeClass('warning');
        }
    };    
    self.addClassActive = function(id){
            $('#' + id).parents('.question').addClass('active');
    };
    self.removeClassActive = function(id){
        $('#' + id).parents('.question').removeClass('active');
    };
    self.evaluateBenefitGroup = function(question, answer){
        if(question !== ''){
            self.removeClassWarning(question);
            self.addClassActive(question);    
        }
        
        if(self.takeAstatin() === "yes"){
            self.removeClassWarning();
            self.showNoAdvice(false);            
            self.showHelpmeChooseAction(false);            
            if(self.takeAstatin()!=='' && self.ascvd()!=='' && self.baselineLDLC_range()!==''){
                if(self.takeAstatin() === 'yes' && self.ascvd()==='yes' && (self.baselineLDLC_range()==='40to189')){
                    self.showPanel(false, true);
                    if(self.comorbidities() === 'no'){
                        self.calculatedBenefitGroup('group2a');
                    }else if(self.comorbidities() === 'yes'){
                        self.calculatedBenefitGroup('group2b');
                    }else{
                        self.showHelpmeChooseAction(false);
                        self.calculatedBenefitGroup(''); 
                    }
                }
                else if(self.takeAstatin() === 'yes' && self.ascvd()==='yes' && self.baselineLDLC_range()==='gte190'){
                    self.showPanel();
                    self.showHelpmeChooseAction(true);
                    self.calculatedBenefitGroup('group2c');
                }
                else if(self.takeAstatin() === 'yes' && self.ascvd()==='no' && self.baselineLDLC_range()==='70to189'){
                    self.showPanel(true);
                    if(self.ageRange()==='40to75'){
                        self.showPanel(true, false, true);
                        if(self.diabetes()==='yes'){
                            self.showPanel(true, false, true, true);
                            if(self.ascvd10yr() === 'yes'){
                                self.calculatedBenefitGroup('group4_1');
                            }else if(self.ascvd10yr() === 'no'){
                                self.showHelpmeChooseAction(true);
                                self.calculatedBenefitGroup('group4_2');
                            }else{
                                self.calculatedBenefitGroup(''); 
                            }
                        }else if(self.diabetes()==='no'){
                            self.showPanel(true, false, true, true);
                            if(self.ascvd10yr() === 'yes'){
                                self.calculatedBenefitGroup('group5');
                            }else if(self.ascvd10yr() === 'no'){
                                self.calculatedBenefitGroup('');
                                self.addClassWarning();
                                self.showNoAdvice(true);
                                self.helpMeChooseWarningMsg('This app cannot provide advice for the patient profile you have selected.');
                            }
                            else{
                                self.calculatedBenefitGroup('');
                            }    
                        }else{
                            self.showPanel(true, false, true, false);
                            self.calculatedBenefitGroup('');                            
                        }
                    }else if(self.ageRange()!=='' && self.ageRange()!=='40to75'){
                            self.showPanel(true, false, false, false);
                            self.calculatedBenefitGroup('');
                            self.addClassWarning();
                            self.showNoAdvice(true);
                            self.helpMeChooseWarningMsg('This app cannot provide advice for the patient profile you have selected.');
                    }else{
                        self.showPanel(true, false, false);
                        self.calculatedBenefitGroup('');
                    }
                }
                else if(self.takeAstatin() === 'yes' && self.ascvd()==='no' && self.baselineLDLC_range()==='gte190'){
                    self.showPanel();
                    self.calculatedBenefitGroup('group3');
                }
                else{
                    self.showPanel();
                    self.calculatedBenefitGroup('');
                    self.addClassWarning();
                    //self.showNoAdvice(true);
                    self.helpMeChooseWarningMsg('This app cannot provide advice for the patient profile you have selected.');                    
                }
            }else{
                self.showPanel();
                self.showHelpmeChooseAction(false);
            }
        }else if(self.takeAstatin() === "no"){
            self.addClassWarning();
            self.showAdviceBtn(false);
            self.showNoAdvice(true);
            self.showPanel();
            self.showHelpmeChooseAction(false);
            self.helpMeChooseWarningMsg('This tool is for patients who have initiated lipid-lowering therapy. Use the <a class="underline" href="../ascvd_risk_estimator/index.html">ASCVD Risk Estimator</a> to evaluate pretreatment patients.');
            return false;
        }else{
            self.addClassWarning();
            self.showPanel();
            self.showAdviceBtn(false);            
            self.showNoAdvice(false);
            
        }
        
        if(self.isAcceptedTreatment() !== ''){
            self.showAdditionalReduction(false);
            if(self.patientBenefitGroup() === 'group3'){
                self.showAdditionalReduction(false);
                self.showHighRiskMarker(false);
                if(self.isAcceptedTreatment() === 'yes'){
                    self.showWarningMsg(true);
                    self.showAdviceBtn(false);
                }else if(self.isAcceptedTreatment() === 'no'){
                    self.showAdditionalReduction(true);
                    if(self.additionalReduction()!=''){
                        self.showWarningMsg(false);
                        self.showAdviceBtn(true);                            
                    }else{
                        self.showWarningMsg(false);
                        self.showAdviceBtn(false);
                    }
                }else{
                    
                }
            }else if(self.patientBenefitGroup() === 'group5'){
                self.showAdditionalReduction(false);                
                if(self.isAcceptedTreatment() === 'yes'){
                    self.showHighRiskMarker(true);
                    if(self.highRiskMarkers() === 'yes'){
                        self.showWarningMsg(false);
                        self.showAdviceBtn(true);
                    }else if(self.highRiskMarkers() === 'no'){
                        self.showWarningMsg(true);
                        self.showAdviceBtn(false);
                    }else{
                        self.showWarningMsg(false);
                        self.showAdviceBtn(false);
                    }
                }else if(self.isAcceptedTreatment() === 'no'){
                        self.showAdditionalReduction(false);
                        self.showHighRiskMarker(false);
                        self.showWarningMsg(false);
                        self.showAdviceBtn(true);
                }else{
                    
                }
            }else if(self.patientBenefitGroup() === 'group4_1'){
                self.showAdditionalReduction(false);
                self.showHighRiskMarker(false);
                if(self.isAcceptedTreatment() === 'yes'){
                    self.showWarningMsg(true);
                    self.showAdviceBtn(false);
                }else  if(self.isAcceptedTreatment() === 'no'){
                    self.showWarningMsg(false);
                    self.showAdviceBtn(true);
                }else{
                    
                }
            }else if(self.patientBenefitGroup() === 'group4_2'){
                self.showAdditionalReduction(false);                
                if(self.isAcceptedTreatment() === 'yes'){
                    self.showHighRiskMarker(true);
                    if(self.highRiskMarkers() === 'yes'){
                        self.showWarningMsg(false);
                        self.showAdviceBtn(true);
                    }else if(self.highRiskMarkers() === 'no'){
                        self.showWarningMsg(true);
                        self.showAdviceBtn(false);
                    }else{
                        self.showWarningMsg(false);
                        self.showAdviceBtn(false);
                    }
                }else if(self.isAcceptedTreatment() === 'no'){
                    self.showHighRiskMarker(true);
                    if(self.highRiskMarkers() === 'yes'){
                        self.showWarningMsg(false);
                        self.showAdviceBtn(true);
                    }else if(self.highRiskMarkers() === 'no'){
                        self.showWarningMsg(false);
                        self.showAdviceBtn(true);
                    }else{
                        self.showWarningMsg(false);
                        self.showAdviceBtn(false);
                    }
                }else{
                    
                }
            }else if(self.patientBenefitGroup() === 'group2a'){
                self.showAdditionalReduction(false);
                self.showHighRiskMarker(false);
                if(self.isAcceptedTreatment() === 'yes'){
                    self.showWarningMsg(true);
                    self.showAdviceBtn(false);
                }else if(self.isAcceptedTreatment() === 'no'){
                    self.showWarningMsg(false);
                    self.showAdviceBtn(true);
                }else{
                    
                }
            }else if(self.patientBenefitGroup() === 'group2b'){
                    self.showAdditionalReduction(false);
                    self.showHighRiskMarker(false);
                    if(self.isAcceptedTreatment() === 'yes'){
                        self.showWarningMsg(true);
                        self.showAdviceBtn(false);
                    }else if(self.isAcceptedTreatment() === 'no'){
                        self.showWarningMsg(false);
                        self.showAdviceBtn(true);
                    }else{
                        
                    }
            }else if(self.patientBenefitGroup() === 'group2c'){
                    self.showAdditionalReduction(false);
                    self.showHighRiskMarker(false);
                    if(self.isAcceptedTreatment() === 'yes'){
                        self.showWarningMsg(true);
                        self.showAdviceBtn(false);
                    }else if(self.isAcceptedTreatment() === 'no'){
                        self.showAdditionalReduction(true);
                        if(self.additionalReduction()!=''){
                            self.showWarningMsg(false);
                            self.showAdviceBtn(true);                            
                        }else{

                        }
                    }else{
                        
                    }
            }            
        }else{
            self.showAdditionalReduction(false);
            self.showWarningMsg(false);             
        }
    };    
    if (sessionStorage.getItem('UnitOfMeasureType')) {
        isSession = false;
        if(sessionStorage.getItem('UnitOfMeasureType') === 'µmol/L'){
            self.UnitOfMeasure(true);
        }else{
            self.UnitOfMeasure(false);
        }
        if(sessionStorage.getItem('patientGroupType')!='' || sessionStorage.getItem('patientGroupType') === undefined){
            self.patientGroupType(sessionStorage.getItem('patientGroupType'));
        }
        if(sessionStorage.getItem('patientBenefitGroup')!='' || sessionStorage.getItem('patientBenefitGroup') === undefined){
            self.patientBenefitGroup(sessionStorage.getItem('patientBenefitGroup'));   
        }        
        if(sessionStorage.getItem('currentLDLC')!='' || sessionStorage.getItem('currentLDLC') === undefined){
            self.currentLDLC(sessionStorage.getItem('currentLDLC'));
        }
        if(sessionStorage.getItem('nonHDLC')!='' || sessionStorage.getItem('nonHDLC') === undefined){
            self.nonHDLC(sessionStorage.getItem('nonHDLC'));   
        }        
        if(sessionStorage.getItem('statinSelectedValue')!='' || sessionStorage.getItem('statinSelectedValue') === undefined){
            self.statinSelectedValue(sessionStorage.getItem('statinSelectedValue'));
        }
        if(sessionStorage.getItem('doseValueChange') != '' || sessionStorage.getItem('doseValueChange') === undefined){
            self.doseValueChange(sessionStorage.getItem('doseValueChange'));
            self.showLDLTherapyTable(true);
        }        
        if(sessionStorage.getItem('baselineLDLC') != '' || sessionStorage.getItem('baselineLDLC') === undefined){
            self.baselineLDLC(sessionStorage.getItem('baselineLDLC'));
        }        
        isSession = true;
    };
    self.appStorage = function(){
        
    };
}