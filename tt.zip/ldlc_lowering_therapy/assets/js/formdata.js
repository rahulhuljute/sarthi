var appStorage = {'result':'', 'isValidate':false, isWarningOn:true};
var userActivity = {'patientGroupType':'', 'patientBenefitGroup':'', 'questions':[],currentLDLC:'', 'nonHDLC':'', 'statin':'', 'dose':'', 'baselineLDLC':''};
var questions = {'takeAstatin':'', 'baselineLDLC_range':'', 'ascvd':'', 'ageRange':'', 'comorbidities':'', 'diabetes':'', 'ascvd10yr':''};

var formdata = {
    statins:[
        {
            'id': 'atorvastatin',
            'title':'Atorvastatin (Lipitor®)', 
            'dose':[            
                {
                'title': '10 or 20 (moderate)',
                'dose': '10 or 20',
                'intensity': 'moderate'
                },
                {
                'title': '40-80 (high)',
                'dose': '40-80',
                'intensity': 'high'
                }                
            ]
        },
        {
            'id': 'fluvastatin',
            'title':'Fluvastatin (Lescol®)', 
            'dose':[
                {
                'title': '20-40 (low)',
                'dose': '20-40',
                'intensity': 'low'
                },            
                {
                'title': '40 BID (moderate)',
                'dose': '40 BID',
                'intensity': 'moderate'
                }           
            ]
        },
        {
            'id': 'fluvastatinXL',
            'title':'Fluvastatin XL (Lescol XL®)', 
            'dose':[           
                {
                'title': '80 (moderate)',
                'dose': '80',
                'intensity': 'moderate'
                }            
            ]
        },
        {
            'id': 'lovastatin',
            'title':'Lovastatin (Mevacor®)', 
            'dose':[
                {
                'title': '20 (low)',
                'dose': '20',
                'intensity': 'low'
                },            
                {
                'title': '40 (moderate)',
                'dose': '40',
                'intensity': 'moderate'
                }           
            ]
        },
        {
            'id': 'pitivastatin',
            'title':'Pitivastatin (Lovalo®)', 
            'dose':[
                {
                'title': '1 (low)',
                'dose': '1',
                'intensity': 'low'
                },            
                {
                'title': '2-4 (moderate)',
                'dose': '2-4',
                'intensity': 'moderate'
                }            
            ]
        },
        {
            'id': 'pravastatin',
            'title':'Pravastatin (Pravachol®)', 
            'dose':[
                {
                'title': '10-20 (low)',
                'dose': '10-20',
                'intensity': 'low'
                },            
                {
                'title': '40 or 80 (moderate)',
                'dose': '40 or 80',
                'intensity': 'moderate'
                }            
            ]
        },
        {
            'id': 'rosuvastatin',
            'title':'Rosuvastatin (Crestor®)', 
            'dose':[
                {
                'title': '10 (moderate)',
                'dose': '10',
                'intensity': 'moderate'
                },            
                {
                'title': '20 or 40 (high)',
                'dose': '20 or 40',
                'intensity': 'high'
                }            
            ]
        },
        {
            'id': 'simvastatin',
            'title':'Simvastatin (Zocor®)', 
            'dose':[
                {
                'title': '10 (low)',
                'dose': '10',
                'intensity': 'low'
                },            
                {
                'title': '20-40 (moderate)',
                'dose': '20-40',
                'intensity': 'moderate'
                }
            ]
        }
    ],
    LDLTherapyData:[
        {
            'benefitGroup':'group2a',
            'recommended_reduction':'> 50%',
            'recommended_LDL_C_mg':'< 100',
            'recommended_LDL_C_mmol':'< 2.586',
            'recommended_non_HDL_C_mg':'N/A',
            'recommended_non_HDL_C_mmol':'N/A'
        },
        {
            'benefitGroup':'group2b',
            'recommended_reduction':'> 50%',
            'recommended_LDL_C_mg':'< 100',
            'recommended_LDL_C_mmol':'< 2.586',
            'recommended_non_HDL_C_mg':'< 70',           
            'recommended_non_HDL_C_mmol':'< 1.813'           
        },
        {
            'benefitGroup':'group2c',
            'recommended_reduction':'> 50%',
            'recommended_LDL_C_mg':'< 70',
            'recommended_LDL_C_mmol':'< 1.813',
            'recommended_non_HDL_C_mg':'N/A',
            'recommended_non_HDL_C_mmol':'N/A'            
        },
        {
            'benefitGroup':'group3',
            'recommended_reduction':'> 50%',
            'recommended_LDL_C_mg':'< 100',
            'recommended_LDL_C_mmol':'< 2.586',
            'recommended_non_HDL_C_mg':'N/A',
            'recommended_non_HDL_C_mmol':'N/A'           
        },
        {
            'benefitGroup':'group4_1',
            'recommended_reduction':'> 50%',
            'recommended_LDL_C_mg':'< 100',
            'recommended_LDL_C_mmol':'< 2.586',
            'recommended_non_HDL_C_mg':'< 130',
            'recommended_non_HDL_C_mmol':'< 3.367'            
        },
        {
            'benefitGroup':'group4_2',
            'recommended_reduction':'30-49%',
            'recommended_LDL_C_mg':'< 100',
            'recommended_LDL_C_mmol':'< 2.586',
            'recommended_non_HDL_C_mg':'< 130',
            'recommended_non_HDL_C_mmol':'< 3.367'            
        },
        {
            'benefitGroup':'group5', 
            'intensity':{
                'low':{
                    'recommended_reduction':'30-49%',
                    'recommended_LDL_C_mg':'< 100',
                    'recommended_LDL_C_mmol':'< 2.586',
                    'recommended_non_HDL_C_mg':'N/A',
                    'recommended_non_HDL_C_mmol':'N/A',                    
                },                
                'moderate':{
                    'recommended_reduction':'30-49%',
                    'recommended_LDL_C_mg':'< 100',
                    'recommended_LDL_C_mmol':'< 2.586',
                    'recommended_non_HDL_C_mg':'N/A',
                    'recommended_non_HDL_C_mmol':'N/A',                    
                },
                'high':{
                    'recommended_reduction':'>50%',
                    'recommended_LDL_C_mg':'< 100',
                    'recommended_LDL_C_mmol':'< 2.586',
                    'recommended_non_HDL_C_mg':'N/A',
                    'recommended_non_HDL_C_mmol':'N/A',                    
                }               
            }
        }
    ],
    warningtext :{
        currentLDLCWarningTextSI: 'Please enter a value between 8.8 and 13260',
        currentLDLCWarningFormatSI: 'Enter values in the format x.x OR xx.x OR xxx.x OR x,x OR xx,x OR xxx,x OR xxxx,x OR xxxxx,x' ,
        currentLDLCWarningTextUS: 'Please enter a value between 0.1 and 150',
        currentLDLCWarningFormatUS: 'Enter values in the format x.x OR xx.x OR xxx.x OR x,x OR xx,x OR xxx,x'
    },
    emailTemplate: {
        subjectLine: 'LDL-C Lowering Therapy Advice for #groupType# (generated on #timestamp#)',
        
        headLine:'Generated on #timestamp# %0D%0AThis email contains a summary of the advice from the ACC LDL-C Reduction Therapy tool. %0D%0A%0D%0AYou have indicated that patient has had insufficient response to current statin therapy.%0D%0A',
        currentStatin:'CURRENT STATIN: #statin# #dose# mg (#intensity# intensity)%0D%0A%0D%0A',
        patientGroup:'PATIENT GROUP %0D%0A#groupType# %0D%0A',
        patientNumbers:'PATIENT NUMBERS %0D%0ALDL-C Reduction: #LDLCReduction# %0D%0ACurrent LDL-C: #CurrentLDLC# %0D%0ABaseline LDL-C: #BaselineLDLC#',
        accSuggestedNumbers:'ACC SUGGESTED NUMBERS %0D%0ALDL-C Reduction: #AccSuggestedLDLReduction# %0D%0ALDL-C: #AccSuggestedLDLC# %0D%0AHDL-C: #AccSuggestedHDLC#',
        disclaimer:'This email contains a summary of the advice from the ACC LDL-C Reduction Therapy tool. %0D%0AEmail content generated by the app does not contain Protected Health Information. %0D%0AUsers are advised to refrain from sharing personally identifiable patient information via unsecured email or other sources.'
    },
   emailGroupAdvice:{
        'group2a':'With ASCVD %0D%0A No Comorbidities %0D%0A %0D%0A#patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0A%0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----FIRST: Consider ezetimibe %0D%0A If response still insufficient %0D%0A ----SECOND: Consider adding or replacing with PCSK9',
        'group2b':'With ASCVD %0D%0AWith Comorbidities %0D%0A %0D%0A #patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0A%0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----FIRST: Consider ezetimibe %0D%0A If response still insufficient %0D%0A ----SECOND: Consider adding or replacing with PCSK9',
        'group2c_ezetimibe':'With ASCVD %0D%0A %0D%0ABaseline LDL-C #groupBaselineLDLC# %0D%0A %0D%0A #patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0A%0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Refer to lipid specialist and RDN %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----FIRST: Consider ezetimibe %0D%0A If response still insufficient %0D%0A ----SECOND: Consider adding or replacing with PCSK9',
        'group2c_pcsk9':'With ASCVD %0D%0A %0D%0ABaseline LDL-C #groupBaselineLDLC# %0D%0A %0D%0A #patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0A%0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Refer to lipid specialist and RDN %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----FIRST: Consider PCSK9 %0D%0A If response still insufficient %0D%0A ----SECOND: Consider adding ezetimibe',        
        'group3_ezetimibe':'No ASCVD %0D%0ABaseline LDL-C #groupBaselineLDLC# %0D%0A %0D%0A #patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0A%0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Refer to lipid specialist and RDN %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----FIRST: Consider ezetimibe %0D%0A If response still insufficient %0D%0A ----SECOND: Consider adding or replacing with PCSK9',
        'group3_pcsk9':'No ASCVD %0D%0ABaseline LDL-C #groupBaselineLDLC# %0D%0A %0D%0A #patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0A%0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Refer to lipid specialist and RDN %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----FIRST: Consider PCSK9 %0D%0A If response still insufficient %0D%0A ----SECOND: Consider adding ezetimibe',
        'group4_1':'With Diabetes %0D%0ANo ASCVD %0D%0AAge 40-75 %0D%0AASCVD 10yr Risk > 7.5%25  %0D%0ABaseline LDL-C #groupBaselineLDLC# %0D%0A %0D%0A #patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----Consider ezetimibe %0D%0A ----Consider BAS if ezetimibe intolerant and triglycerides < 300 mg/dL',
        'group4_2':'With Diabetes %0D%0ANo ASCVD %0D%0AAge 40-75 %0D%0AASCVD 10yr Risk < 7.5%25  %0D%0ABaseline LDL-C #groupBaselineLDLC# %0D%0A%0D%0A#patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Consider increasing to high intensity statin %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----Consider ezetimibe %0D%0A ----Consider BAS if ezetimibe intolerant and triglycerides < 300 mg/dL',
        'group5':'No Diabetes %0D%0ANo ASCVD %0D%0AAge 40-75 %0D%0AASCVD 10yr Risk ≥ 7.5%25  %0D%0ABaseline LDL-C #groupBaselineLDLC# %0D%0A%0D%0A#patientNumbers# %0D%0A%0D%0A#accSuggestedNumbers# %0D%0A%0D%0AACC ADVICE %0D%0A -Optimize current therapy %0D%0A -Discuss any new therapy with patient %0D%0A -Consider increasing to high intensity statin %0D%0A -Consider additional non-statin therapy if statin response insufficient %0D%0A ----Consider ezetimibe %0D%0A ----Consider BAS if ezetimibe intolerant and triglycerides < 300 mg/dL'        
    }    
}