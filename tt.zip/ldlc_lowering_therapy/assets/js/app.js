$(function() {
  $( "#accordion" ).accordion();
  $( "#accordion2" ).accordion();
  $("#chosen").chosen({width: "100%"});
  $("#chosenSingle").chosen({width: "100%"});

// to render html in an auto complete you must extend it. 
// https://api.jqueryui.com/autocomplete/#method-_renderItem

});
  $(function() {
    $( "#slider" ).slider({
      value:100,
      min: 0,
      max: 500,
      step: 50,
      slide: function( event, ui ) {
        $( "#amount" ).val( "$" + ui.value );
      }
    });
    $( "#amount" ).val( "$" + $( "#slider" ).slider( "value" ) );
  });
    $(function() {
    $( "#datepicker" ).datepicker();
  });
  $(function() {
   $( "#spinner" ).spinner();
 });
  $(document).ready(function() {
    // http://anovi.github.io/selectonic/
    $("#ButtonGroup").selectonic(
      {
              multi:false,
      mouseMode: "standard",
        keyboard: false,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
      }
    );
    $("#Toggle").selectonic(
      {
              multi:false,
      mouseMode: "standard",
        keyboard: false,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
      }
    );
    var $holder = $("#PanelSelector"),panels = $holder.find('.panel-selector'), parent_panel = $holder.find('.parent ul'), child_panel = $holder.find('.child ul');
    parent_panel.selectonic({
      multi:false,
      mouseMode: "standard",
        keyboard: true,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
        create:function(){
           this.selectonic('disable')
        },
        unselect:function(event,ui){

        },  
        select: function(event, ui) {

        },
    });
    parent_panel.mouseenter(function(){
        parent_panel.selectonic('enable');
       
    });
    parent_panel.mouseleave(function(){
        parent_panel.selectonic('disable');
    });
    child_panel.selectonic({
        multi:false,
        mouseMode: "standard",
        keyboard: true,
        focusBlur: true,
        keyboardMode:"toggle",
        focusOnHover:true,
        create:function(){
            this.selectonic('disable')
        },
        unselect:function(event,ui){

        },  
        select: function(event, ui) {

        },
    });
    child_panel.mouseenter(function(){
        child_panel.selectonic('enable');
        
    });
    child_panel.mouseleave(function(){
        child_panel.selectonic('disable');
    });
    panels.mouseenter(function(){
        panels.removeClass('active-focus');
        $(this).addClass('active-focus');
    });

    panels.mouseleave(function(){
        panels.removeClass('active-focus');

    });
    
    if (document.URL.indexOf('http://') === -1 && document.URL.indexOf('https://') === -1)
    {
      //if mobile device detected
      //Load mobile-app.js dynamically
      var mobileScript = document.createElement('script');
      mobileScript.setAttribute('src', 'assets/js/mobile-app.js');
      document.body.appendChild(mobileScript);
      
      var cordovaScript = document.createElement('script');
      cordovaScript.setAttribute('src', 'cordova.js');
      document.head.appendChild(cordovaScript);
      
      $('body').addClass('noselect');
    }
    
});


  ko.bindingHandlers.toggle = {
      'after': ['value', 'attr'],
      'init': function (element, valueAccessor, allBindings, viewModel, bindingContext) {
          // This updates the model selection array when the DOM element is clicked
          function updateModel() {
              
              //supporting both binding to boolean property and arrays
              if (isValueArray) {
                  var index = ko.utils.arrayIndexOf(underlyingValue, viewModel);
                  if(index > -1){
                      underlyingValue.splice(index, 1);
                  }else{
                      underlyingValue.push(viewModel);
                  }                
                  if(isObservable){
                      modelProperty.valueHasMutated();
                  }
              } else {
                  if(isObservable && isWritable){
                      //flip the true/false value of an observable
                      modelProperty(!modelProperty());
                  }else{
                      //flip the true/false value of a property
                      viewModel[modelProperty] = !viewModel[modelProperty];
                  }
              }
          };

          var modelProperty = valueAccessor();
          var underlyingValue = ko.utils.unwrapObservable(modelProperty);
          var isValueArray = underlyingValue instanceof Array;
          var isObservable = ko.isObservable(modelProperty);
          var isWritable = ko.isWriteableObservable(modelProperty);

          // Set up a computed to update the binding:
          ko.utils.registerEventHandler(element, "click", updateModel);
      }
  };

 var panelScrollTop = function(data, event){
    var offset = $(event.currentTarget).parent().parent().offset().top -50;
    var winOffset = $(window).scrollTop(); 
    var newScroll = ( offset <= winOffset)? offset : 0;
    $(window).scrollTop(newScroll);
    };
  var pageScrollTop = function(data, event){
    $(window).scrollTop(0);
    } 
  var panelVisibleToggle = function(data,event){
    if($('.accordion ' + data).hasClass('selected')){
        $('.accordion ' + data).removeClass('selected');
    }else{
        $('.accordion ' + data).addClass('selected');
    }
    var target = '.accordion ' + data + ' .collapsable-panel';
    $(target).slideToggle();
  };  
  var panelHide = function(data, event){
    $(event.currentTarget).parents('.collapsable-panel').hide();
    $(event.currentTarget).parents('.selected').removeClass('selected');
  };
  var panelShow = function(data,event){
    var target = data + ' .collapsable-panel'
    $(target).show();
  };

  var listchange = function(data, event){
    var hash = location.hash;
    $('.split-sidebar .nav-list li').each(function(){
      var that = $(this);
      that[ $('a', this).attr( 'href' ) === hash ? 'addClass' : 'removeClass' ]( 'selected' );
      }
    );
  };


 var PanelSelectorKO = function(){
      var self = this;
      self.repeatedItems  = [
          {name:'Freckle', selected: ko.observable(false)},
          {name:'Beanstalk', selected: ko.observable(false)},
          {name:'DropBox', selected: ko.observable(false)},
          {name:'Postmark', selected: ko.observable(false)}
      ];
          self.repeatedItems2  = [
          {name:'IOS', selected: ko.observable(false)},
          {name:'Window Mobile', selected: ko.observable(false)},
          {name:'Andriod', selected: ko.observable(false)},
          {name:'RIM', selected: ko.observable(false)}
      ];
      self.hasAPI = ko.observableArray([]);
      self.hasFreePlan = ko.observableArray([]);
  };
  //var appmodel = new PanelSelectorKO();
 // ko.applyBindings(appmodel);

function viewHeight() {
    var viewportheight;

    // the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerWidth and window.innerHeight
    if (typeof window.innerWidth !== 'undefined') {
        viewportheight = window.innerHeight;
    }

        //	 IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
    else if (typeof document.documentElement !== 'undefined' && typeof document.documentElement.clientWidth !== 'undefined' && document.documentElement.clientWidth !== 0) {
        viewportheight = document.documentElement.clientHeight;
    }

        //	 older versions of IE
    else {
        viewportheight = document.getElementsByTagName('body')[0].clientHeight;
    }
    return viewportheight;
}


function HideAccordion(id) {
  $('#'+id).find('.accordion').find('div.collapsable-panel').hide();
  $('#'+id).find('.accordion').find('div').removeClass('selected');
}



var tabchange = function (data) {
    var hash = location.hash;
    $('.header .tabs li').removeClass('selected');
    $('.footer .tabs li').removeClass('selected');
    var string = '#' + data.page.currentId + '-Tab';
    $(string).addClass('selected active');
    
    if (hash.indexOf('statin') > -1 || hash.indexOf('clinician') > -1 || hash.indexOf('nonstatinagent') > -1) {
        var string = '#advice-Tab';
        $(string).addClass('selected active');        
    }

    if(hash.indexOf('disclaimer') > -1)
        window.location.replace('../index.html#!/content/disclaimer/');
    else if(hash.indexOf('resources') > -1){
        window.location.replace('../index.html#!/content/resources/');
    }else if(hash.indexOf('about') > -1){
        window.location.replace('../index.html#!/content/about/');
    }    
   
    var view = viewHeight();
    var mh;
    if (hash.indexOf('disclaimer') > -1 || hash.indexOf('resources') > -1) {
        mh = (view - 110);
    } else {
        mh = (view - 169);
    }

    $(".fullscreen-spacer").css("min-height", mh);
};


var pageScrollTop = function () {
    $(window).scrollTop(0);
};

dateFormatter = function(i){
    if (i < 10) {
        i = '0' + i;
    }else{
        i = i;
    }
    return i;
};

window.addEventListener('popstate', function(event) {
        /*var hash = location.hash;
		$(window).scrollTop($('body').offset().top);
        if(hash.indexOf('advice')  > -1){  
            if(appmodel.Form().showAdviceBtn()){
                window.location.href = '#!/content/advice/';
                $('#calculator-Tab, #disclaimer-Tab, #about-Tab, #resources-Tab').removeClass('selected');
                $('#recommendation-Tab').addClass('selected');
            }else{
                window.location.href = '#!/content/calculator/';
                $('#recommendation-Tab, #disclaimer-Tab, #about-Tab, #resources-Tab').removeClass('selected');
                $('#calculator-Tab').addClass('selected');                        
            }
		} */ 
    // The popstate event is fired each time when the current history entry changes.

    /*var r = confirm("You pressed a Back button! Are you sure?!");

    if (r == true) {
        // Call Back button programmatically as per user confirmation.
        history.back();
        // Uncomment below line to redirect to the previous page instead.
        // window.location = document.referrer // Note: IE11 is not supporting this.
    } else {
        // Stay on the current page.
        history.pushState(null, null, window.location.pathname);
    }

    history.pushState(null, null, window.location.pathname);
*/
}, false);