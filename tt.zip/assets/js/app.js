var footerChange = function () {
var hash = location.hash;
$('.footer li').removeClass('selected');
$('#footerLinks li').each(function () {
                    var that = $(this);
                    if($('a', this).attr('href') === hash){
                            that.addClass('selected');
                    }
                    else{
                            that.removeClass('selected');
                    }
            }
    );
    var view = viewHeight();
    var mh;
    if (hash.indexOf('disclaimer') > -1 || hash.indexOf('resources') > -1) {
        mh = (view - 110);
    } else {
        mh = (view - 169);
    }

    $(".fullscreen-spacer").css("min-height", mh);
};
//window.onresize = function(event) {
//   var view = viewHeight();
//    var mh;
//    if (hash.indexOf('disclaimer') > -1 || hash.indexOf('resources') > -1) {
//        mh = (view - 110);
//    } else {
//        mh = (view - 169);
//    }
//
//    $(".fullscreen-spacer").css("min-height", mh);
//    
//};

function viewHeight() {
    var viewportheight;

    // the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerWidth and window.innerHeight
    if (typeof window.innerWidth !== 'undefined') {
        viewportheight = window.innerHeight;
    }

        //	 IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
    else if (typeof document.documentElement !== 'undefined' && typeof document.documentElement.clientWidth !== 'undefined' && document.documentElement.clientWidth !== 0) {
        viewportheight = document.documentElement.clientHeight;
    }

        //	 older versions of IE
    else {
        viewportheight = document.getElementsByTagName('body')[0].clientHeight;
    }
    return viewportheight;
}






