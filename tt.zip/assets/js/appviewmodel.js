function viewModel(){
	var self = this;
}
var appmodel = new viewModel();
// ko.applyBindings(appmodel);
// This is a simple *viewmodel* - JavaScript that defines the data and behavior of your UI
// var viewModel = {
// };
// extend viewModel with a $__page__ that points to pager.page that points to a new Page
pager.Href.hash = '#!/';
pager.extendWithPage(appmodel);

// apply your bindings
ko.applyBindings(appmodel);
// run this method - listening to hashchange
var hash = location.hash;
pager.start();
var path = '#!/content/calculator/';
if (hash.indexOf('disclaimer') > -1 || hash.indexOf('resources') > -1 || hash.indexOf('about') > -1) {
        path = hash;        
    }
pager.navigate(path);
//$('#calculator-Tab').addClass('selected active');